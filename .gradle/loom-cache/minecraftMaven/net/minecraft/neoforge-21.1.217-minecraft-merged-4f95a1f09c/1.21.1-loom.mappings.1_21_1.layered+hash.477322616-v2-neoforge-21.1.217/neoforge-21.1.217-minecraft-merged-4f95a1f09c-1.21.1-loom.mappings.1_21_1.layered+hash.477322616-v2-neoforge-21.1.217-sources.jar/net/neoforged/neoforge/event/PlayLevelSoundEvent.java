/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event;

import java.util.Objects;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.Nullable;

/**
 * PlayLevelSoundEvent is fired when a sound is played on a {@link World}.
 * This event is fired from {@link World#playSound}, {@link World#playSoundFromEntity}, and {@link ClientPlayerEntity#playSoundIfNotSilent}.
 * <p>
 * {@link #getLevel()} contains the level the sound is being played in.
 * {@link #getSound()} contains the sound event to be played.
 * {@link #getOriginalVolume()} contains the original volume for the sound to be played at.
 * {@link #getOriginalPitch()} contains the original pitch for the sound to be played at.
 * {@link #getNewVolume()} contains the volume the sound will be played at.
 * {@link #getNewPitch()} contains the pitch the sound will be played at.
 * <p>
 * This event is {@link ICancellableEvent cancelable}.
 * If this event is canceled, the sound is not played.
 * <p>
 * This event does not have a result.
 * <p>
 * This event is fired on the {@link NeoForge#EVENT_BUS}.
 */
public class PlayLevelSoundEvent extends Event implements ICancellableEvent {
    private final World level;
    private final float originalVolume;
    private final float originalPitch;
    private RegistryEntry<SoundEvent> sound;
    private SoundCategory source;
    private float newVolume;
    private float newPitch;

    public PlayLevelSoundEvent(World level, RegistryEntry<SoundEvent> sound, SoundCategory source, float volume, float pitch) {
        this.level = level;
        this.sound = sound;
        this.source = source;
        this.originalVolume = volume;
        this.originalPitch = pitch;
        this.newVolume = volume;
        this.newPitch = pitch;
    }

    /**
     * {@return the level the sound is being played in}
     */
    public World getLevel() {
        return this.level;
    }

    /**
     * {@return the sound event to be played}
     */
    @Nullable
    public RegistryEntry<SoundEvent> getSound() {
        return this.sound;
    }

    /**
     * Sets the sound event to be played.
     */
    public void setSound(@Nullable RegistryEntry<SoundEvent> sound) {
        this.sound = sound;
    }

    /**
     * {@return the sound source}
     */
    public SoundCategory getSource() {
        return this.source;
    }

    /**
     * Sets the sound source.
     */
    public void setSource(SoundCategory source) {
        Objects.requireNonNull(source, "Sound source cannot be null");
        this.source = source;
    }

    /**
     * {@return the original volume for the sound to be played at}
     */
    public float getOriginalVolume() {
        return this.originalVolume;
    }

    /**
     * {@return the original pitch for the sound to be played at}
     */
    public float getOriginalPitch() {
        return this.originalPitch;
    }

    /**
     * {@return the volume the sound will be played at}
     */
    public float getNewVolume() {
        return this.newVolume;
    }

    /**
     * Sets the volume the sound will be played at.
     */
    public void setNewVolume(float newVolume) {
        this.newVolume = newVolume;
    }

    /**
     * {@return the pitch the sound will be played at}
     */
    public float getNewPitch() {
        return this.newPitch;
    }

    /**
     * Sets the pitch the sound will be played at.
     */
    public void setNewPitch(float newPitch) {
        this.newPitch = newPitch;
    }

    /**
     * PlayLevelSoundEvent.AtEntity is fired when a sound is played on the {@link World} at an {@link Entity Entity}'s position.
     * This event is fired from {@link World#playSound}, {@link World#playSoundFromEntity}, and {@link ClientPlayerEntity#playSoundIfNotSilent}.
     * <p>
     * This event is {@link ICancellableEvent cancelable}.
     * If this event is canceled, the sound is not played.
     * <p>
     * This event does not have a result.
     * <p>
     * This event is fired on the {@link NeoForge#EVENT_BUS}.
     */
    public static class AtEntity extends PlayLevelSoundEvent {
        private final Entity entity;

        public AtEntity(Entity entity, RegistryEntry<SoundEvent> sound, SoundCategory source, float volume, float pitch) {
            super(entity.getWorld(), sound, source, volume, pitch);
            this.entity = entity;
        }

        /**
         * {@return the entity the sound is being played on}
         */
        public Entity getEntity() {
            return this.entity;
        }
    }

    /**
     * PlayLevelSoundEvent.AtPosition is fired when a sound is played on the {@link World} at a specific position.
     * This event is fired from {@link World#playSound} and {@link World#playSoundFromEntity}.
     * <p>
     * This event is {@link ICancellableEvent cancelable}.
     * If this event is canceled, the sound is not played.
     * <p>
     * This event does not have a result.
     * <p>
     * This event is fired on the {@link NeoForge#EVENT_BUS}.
     */
    public static class AtPosition extends PlayLevelSoundEvent {
        private final Vec3d position;

        public AtPosition(World level, Vec3d position, RegistryEntry<SoundEvent> sound, SoundCategory source, float volume, float pitch) {
            super(level, sound, source, volume, pitch);
            this.position = position;
        }

        /**
         * {@return the position the sound is being played at}
         */
        public Vec3d getPosition() {
            return this.position;
        }
    }
}
