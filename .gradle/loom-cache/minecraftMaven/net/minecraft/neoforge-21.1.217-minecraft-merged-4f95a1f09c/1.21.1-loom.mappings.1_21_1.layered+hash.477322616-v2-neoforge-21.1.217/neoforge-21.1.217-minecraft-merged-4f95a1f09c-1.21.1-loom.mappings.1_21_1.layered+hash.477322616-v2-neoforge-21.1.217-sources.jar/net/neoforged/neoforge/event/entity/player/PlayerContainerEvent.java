/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.ScreenHandler;

public class PlayerContainerEvent extends PlayerEvent {
    private final ScreenHandler container;

    public PlayerContainerEvent(PlayerEntity player, ScreenHandler container) {
        super(player);
        this.container = container;
    }

    public static class Open extends PlayerContainerEvent {
        public Open(PlayerEntity player, ScreenHandler container) {
            super(player, container);
        }
    }

    public static class Close extends PlayerContainerEvent {
        public Close(PlayerEntity player, ScreenHandler container) {
            super(player, container);
        }
    }

    public ScreenHandler getContainer() {
        return container;
    }
}
