/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries.holdersets;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.entry.RegistryEntryListCodec;
import net.neoforged.neoforge.common.NeoForgeMod;

/**
 * <p>Holderset that represents an intersection of other holdersets. Json format:</p>
 * 
 * <pre>
 * {
 *   "type": "neoforge:and",
 *   "values":
 *   [
 *      // list of sub-holdersets (strings, lists, or objects)
 *   ]
 * }
 * </pre>
 */
public class AndHolderSet<T> extends CompositeHolderSet<T> {
    public AndHolderSet(List<RegistryEntryList<T>> values) {
        super(values);
    }

    @SafeVarargs
    public AndHolderSet(RegistryEntryList<T>... values) {
        this(List.of(values));
    }

    @Override
    public HolderSetType type() {
        return NeoForgeMod.AND_HOLDER_SET.value();
    }

    @Override
    protected Set<RegistryEntry<T>> createSet() {
        List<RegistryEntryList<T>> components = this.getComponents();
        if (components.size() < 1) {
            return Set.of();
        }
        if (components.size() == 1) {
            return components.get(0).stream().collect(Collectors.toSet());
        }

        List<RegistryEntryList<T>> remainingComponents = components.subList(1, components.size());
        return components.get(0)
                .stream()
                .filter(holder -> remainingComponents.stream().allMatch(holderset -> holderset.contains(holder)))
                .collect(Collectors.toSet());
    }

    @Override
    public String toString() {
        return "AndSet[" + this.getComponents() + "]";
    }

    public static class Type implements HolderSetType {
        @Override
        public <T> MapCodec<? extends ICustomHolderSet<T>> makeCodec(RegistryKey<? extends Registry<T>> registryKey, Codec<RegistryEntry<T>> holderCodec, boolean forceList) {
            return RegistryEntryListCodec.create(registryKey, holderCodec, forceList)
                    .listOf()
                    .xmap(AndHolderSet::new, CompositeHolderSet::homogenize)
                    .fieldOf("values");
        }

        @Override
        public <T> PacketCodec<RegistryByteBuf, ? extends ICustomHolderSet<T>> makeStreamCodec(RegistryKey<? extends Registry<T>> registryKey) {
            return PacketCodecs.<RegistryByteBuf, RegistryEntryList<T>>toList()
                    .apply(PacketCodecs.registryEntryList(registryKey))
                    .xmap(AndHolderSet::new, CompositeHolderSet::getComponents);
        }
    }
}
