/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.resource;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.resource.SinglePreparationResourceReloader;
import net.neoforged.neoforge.common.conditions.ConditionalOps;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.conditions.ICondition.IContext;
import org.jetbrains.annotations.ApiStatus;

/**
 * Reload listeners that descend from this class will have the reload context automatically populated when it is available.
 * <p>
 * The context is guaranteed to be available for the duration of {@link ResourceReloader#reload}.
 * <p>
 * For children of {@link SinglePreparationResourceReloader}, it will be available during both {@link SinglePreparationResourceReloader#prepare} prepare()} and {@link SinglePreparationResourceReloader#apply apply()}.
 */
public abstract class ContextAwareReloadListener implements ResourceReloader {
    private ICondition.IContext conditionContext = ICondition.IContext.EMPTY;

    private RegistryWrapper.WrapperLookup registryLookup = DynamicRegistryManager.EMPTY;

    @ApiStatus.Internal
    public void injectContext(ICondition.IContext context, RegistryWrapper.WrapperLookup registryLookup) {
        this.conditionContext = context;
        this.registryLookup = registryLookup;
    }

    /**
     * Returns the condition context held by this listener, or {@link IContext#EMPTY} if it is unavailable.
     */
    protected final ICondition.IContext getContext() {
        return this.conditionContext;
    }

    /**
     * Returns the registry access held by this listener, or {@link DynamicRegistryManager#EMPTY} if it is unavailable.
     */
    protected final RegistryWrapper.WrapperLookup getRegistryLookup() {
        return this.registryLookup;
    }

    /**
     * Creates a new {@link ConditionalOps} using {@link #getContext()} and {@link #getRegistryLookup()} ()}.
     */
    protected final ConditionalOps<JsonElement> makeConditionalOps() {
        return new ConditionalOps<>(getRegistryLookup().getOps(JsonOps.INSTANCE), getContext());
    }
}
