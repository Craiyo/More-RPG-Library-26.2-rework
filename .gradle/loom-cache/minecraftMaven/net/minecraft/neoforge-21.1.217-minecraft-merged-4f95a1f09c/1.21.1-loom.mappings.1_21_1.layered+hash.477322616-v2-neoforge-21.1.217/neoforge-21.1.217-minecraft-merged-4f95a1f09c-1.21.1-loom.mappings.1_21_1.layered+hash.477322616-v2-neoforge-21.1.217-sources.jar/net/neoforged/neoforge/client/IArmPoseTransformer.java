/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;

/**
 * An ArmPose that can be defined by the user.
 * Register one by creating a custom {@link net.minecraft.client.render.entity.model.BipedEntityModel.ArmPose}
 * and returning it in {@link IClientItemExtensions#getArmPose(LivingEntity, Hand, ItemStack)}.
 */
@FunctionalInterface
public interface IArmPoseTransformer {
    /**
     * This method should be used to apply all wanted transformations to the player when the ArmPose is active.
     * You can use {@link LivingEntity#getItemUseTime()} and {@link LivingEntity#getItemUseTimeLeft()} for moving animations.
     *
     * @param model  The humanoid model
     * @param entity The humanoid entity
     * @param arm    Arm to pose
     */
    void applyTransform(BipedEntityModel<?> model, LivingEntity entity, Arm arm);
}
