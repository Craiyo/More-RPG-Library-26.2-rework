/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.village;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.village.ZombieSiegeManager;
import net.minecraft.world.World;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * VillageSiegeEvent is fired just before a zombie siege finds a successful location in
 * {@code VillageSiege#tryToSetupSiege(ServerLevel)}, to give mods the chance to stop the siege.<br>
 * <br>
 * This event is {@link ICancellableEvent}; canceling stops the siege.<br>
 * <br>
 * This event does not have a result. {@link HasResult}<br>
 * <br>
 * This event is fired on the {@link NeoForge#EVENT_BUS}.
 */
public class VillageSiegeEvent extends Event implements ICancellableEvent {
    private final ZombieSiegeManager siege;
    private final World level;
    private final PlayerEntity player;
    private final Vec3d attemptedSpawnPos;

    public VillageSiegeEvent(ZombieSiegeManager siege, World level, PlayerEntity player, Vec3d attemptedSpawnPos) {
        this.siege = siege;
        this.level = level;
        this.player = player;
        this.attemptedSpawnPos = attemptedSpawnPos;
    }

    public ZombieSiegeManager getSiege() {
        return siege;
    }

    public World getLevel() {
        return level;
    }

    public PlayerEntity getPlayer() {
        return player;
    }

    public Vec3d getAttemptedSpawnPos() {
        return attemptedSpawnPos;
    }
}
