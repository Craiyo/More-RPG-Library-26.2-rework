/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import java.util.Set;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.neoforged.neoforge.common.EffectCure;
import net.neoforged.neoforge.common.EffectCures;

public interface IMobEffectExtension {
    private StatusEffect self() {
        return (StatusEffect) this;
    }

    /***
     * Fill the given set with the {@link EffectCure}s this effect should be curable with by default
     */
    default void fillEffectCures(Set<EffectCure> cures, StatusEffectInstance effectInstance) {
        cures.addAll(EffectCures.DEFAULT_CURES);
        if (self() == StatusEffects.POISON.value()) {
            cures.add(EffectCures.HONEY);
        }
    }

    /**
     * Used for determining {@link StatusEffect} sort order in GUIs.
     * Defaults to the {@link StatusEffect}'s liquid color.
     * 
     * @param effectInstance the {@link StatusEffectInstance} containing this {@link StatusEffect}
     * @return a value used to sort {@link StatusEffect}s in GUIs
     */
    default int getSortOrder(StatusEffectInstance effectInstance) {
        return self().getColor();
    }
}
