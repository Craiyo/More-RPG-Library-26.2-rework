/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui.widget;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Language;

/**
 * This class provides a button that fixes several bugs present in the vanilla GuiButton drawing code.
 * The gist of it is that it allows buttons of any size without gaps in the graphics and with the
 * borders drawn properly. It also prevents button text from extending out of the sides of the button by
 * trimming the end of the string and adding an ellipsis.<br/><br/>
 *
 * The code that handles drawing the button is in GuiUtils.
 *
 * @author bspkrs
 */
public class ExtendedButton extends ButtonWidget {
    public ExtendedButton(int xPos, int yPos, int width, int height, Text displayString, PressAction handler) {
        this(xPos, yPos, width, height, displayString, handler, DEFAULT_NARRATION_SUPPLIER);
    }

    public ExtendedButton(int xPos, int yPos, int width, int height, Text displayString, PressAction handler, NarrationSupplier createNarration) {
        super(xPos, yPos, width, height, displayString, handler, createNarration);
    }

    public ExtendedButton(ButtonWidget.Builder builder) {
        super(builder);
    }

    /**
     * Draws this button to the screen.
     */
    @Override
    public void renderWidget(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        guiGraphics.drawGuiTexture(TEXTURES.get(this.active, this.isSelected()), this.getX(), this.getY(), this.getWidth(), this.getHeight());

        final StringVisitable buttonText = mc.textRenderer.ellipsize(this.getMessage(), this.width - 6); // Remove 6 pixels so that the text is always contained within the button's borders
        guiGraphics.drawCenteredTextWithShadow(mc.textRenderer, Language.getInstance().reorder(buttonText), this.getX() + this.width / 2, this.getY() + (this.height - 8) / 2, getFGColor());
    }
}
