/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.configuration;

import java.util.function.Consumer;
import net.minecraft.network.NetworkPhase;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.payload.CommonRegisterPayload;
import net.neoforged.neoforge.network.registration.NetworkRegistry;
import org.jetbrains.annotations.ApiStatus;

/**
 * Common Register configuration task. After completion of {@link CommonVersionTask}, sends a {@link CommonRegisterPayload} to the client
 * containing all known serverbound channels, and awaits a response containing the client's known clientbound channels.
 */
@ApiStatus.Internal
public record CommonRegisterTask() implements ICustomConfigurationTask {
    public static final Key TYPE = new Key(Identifier.of(NeoForgeVersion.MOD_ID, "common_register"));

    @Override
    public Key getKey() {
        return TYPE;
    }

    @Override
    public void run(Consumer<CustomPayload> sender) {
        // There is currently no implementation for a version handshake, and the only existing version is 1, so we only send 1.
        // Version negotiation will have to be implemented properly if a version 2 is ever added.
        sender.accept(new CommonRegisterPayload(1, NetworkPhase.PLAY, NetworkRegistry.getCommonPlayChannels(NetworkSide.SERVERBOUND)));
    }
}
