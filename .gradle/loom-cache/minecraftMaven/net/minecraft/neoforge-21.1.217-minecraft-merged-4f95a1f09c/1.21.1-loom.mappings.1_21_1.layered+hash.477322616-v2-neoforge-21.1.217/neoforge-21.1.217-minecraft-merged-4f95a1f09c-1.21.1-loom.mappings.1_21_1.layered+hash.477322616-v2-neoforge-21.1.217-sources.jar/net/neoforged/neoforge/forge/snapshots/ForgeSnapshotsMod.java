/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.forge.snapshots;

import net.minecraft.client.option.GameOptions;
import net.minecraft.util.crash.CrashReport;

public class ForgeSnapshotsMod {
    public static final String BRANDING_NAME = "NeoForge";
    public static final String BRANDING_ID = "neoforge";

    public static void processOptions(GameOptions.Visitor fieldAccess) {}

    public static void logStartupWarning() {}

    public static void addCrashReportHeader(StringBuilder builder, CrashReport crashReport) {}
}
