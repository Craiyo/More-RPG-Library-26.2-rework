/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.registries.callback.AddCallback;
import net.neoforged.neoforge.registries.callback.BakeCallback;
import net.neoforged.neoforge.registries.callback.ClearCallback;
import net.neoforged.neoforge.registries.callback.RegistryCallback;
import net.neoforged.neoforge.registries.datamaps.DataMapType;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Internal
public abstract class BaseMappedRegistry<T> implements Registry<T> {
    protected final List<AddCallback<T>> addCallbacks = new ArrayList<>();
    protected final List<BakeCallback<T>> bakeCallbacks = new ArrayList<>();
    protected final List<ClearCallback<T>> clearCallbacks = new ArrayList<>();
    final Map<Identifier, Identifier> aliases = new HashMap<>();
    final Map<DataMapType<T, ?>, Map<RegistryKey<T>, ?>> dataMaps = new IdentityHashMap<>();

    private int maxId = Integer.MAX_VALUE - 1;
    private boolean sync;

    void setSync(boolean sync) {
        this.sync = sync;
    }

    @Override
    public boolean doesSync() {
        return this.sync;
    }

    void setMaxId(int maxId) {
        this.maxId = maxId;
    }

    @Override
    public int getMaxId() {
        return this.maxId;
    }

    @Override
    public void addCallback(RegistryCallback<T> callback) {
        if (callback instanceof AddCallback<T> addCallback)
            this.addCallbacks.add(addCallback);
        if (callback instanceof BakeCallback<T> bakeCallback)
            this.bakeCallbacks.add(bakeCallback);
        if (callback instanceof ClearCallback<T> clearCallback)
            this.clearCallbacks.add(clearCallback);
    }

    @Override
    public void addAlias(Identifier from, Identifier to) {
        if (from.equals(to))
            return;
        if (this.aliases.containsKey(from)) {
            Identifier old = this.aliases.get(from);
            if (!old.equals(to))
                throw new IllegalStateException("Duplicate alias with key \"" + from + "\" attempting to map to \"" + to + "\", found existing mapping \"" + old + "\"");
        }
        if (resolve(from).equals(to))
            throw new IllegalStateException("Infinite alias loop detected: from " + from + " to " + to);
        this.aliases.put(from, to);
    }

    @Override
    public Identifier resolve(Identifier name) {
        if (this.containsId(name))
            return name;

        Identifier alias = this.aliases.get(name);
        if (alias == null)
            return name;

        return resolve(alias);
    }

    @Override
    public RegistryKey<T> resolve(RegistryKey<T> key) {
        Identifier resolvedName = resolve(key.getValue());
        // Try to reuse the key if possible
        return resolvedName == key.getValue() ? key : RegistryKey.of(this.getKey(), resolvedName);
    }

    @Override
    public int getId(RegistryKey<T> key) {
        T value = this.get(key);
        return value == null ? -1 : this.getRawId(value);
    }

    @Override
    public int getId(Identifier name) {
        T value = this.get(name);
        return value == null ? -1 : this.getRawId(value);
    }

    protected void clear(boolean full) {
        this.aliases.clear();
        if (full) {
            this.dataMaps.clear();
        }
    }

    /**
     * Register a key <-> ID mapping.
     * <b>The IDs must be registered in increasing order.</b>
     */
    protected abstract void registerIdMapping(RegistryKey<T> key, int id);

    protected abstract void unfreeze();

    @Override
    public <A> @Nullable A getData(DataMapType<T, A> type, RegistryKey<T> key) {
        final var innerMap = dataMaps.get(type);
        return innerMap == null ? null : (A) innerMap.get(key);
    }

    @Override
    public <A> Map<RegistryKey<T>, A> getDataMap(DataMapType<T, A> type) {
        return (Map<RegistryKey<T>, A>) dataMaps.getOrDefault(type, Map.of());
    }
}
