/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.stream.Collectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryInfo;
import net.minecraft.server.MinecraftServer;
import net.minecraft.test.TestServer;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.SpawnSettings;
import net.neoforged.fml.config.ConfigTracker;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.LogicalSidedProvider;
import net.neoforged.neoforge.common.world.BiomeModifier;
import net.neoforged.neoforge.common.world.StructureModifier;
import net.neoforged.neoforge.event.server.ServerAboutToStartEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.gametest.GameTestHooks;
import net.neoforged.neoforge.mixins.MappedRegistryAccessor;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.NeoForgeRegistries.Keys;
import net.neoforged.neoforge.server.permission.PermissionAPI;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Marker;
import org.apache.logging.log4j.MarkerManager;
import org.jetbrains.annotations.Nullable;

public class ServerLifecycleHooks {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final Marker SERVERHOOKS = MarkerManager.getMarker("SERVERHOOKS");
    private static final WorldSavePath SERVERCONFIG = new WorldSavePath("serverconfig");
    @Nullable
    private static volatile CountDownLatch exitLatch = null;
    @Nullable
    private static MinecraftServer currentServer;

    private static Path getServerConfigPath(final MinecraftServer server) {
        final Path serverConfig = server.getSavePath(SERVERCONFIG);
        if (!Files.isDirectory(serverConfig)) {
            try {
                Files.createDirectories(serverConfig);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        final Path explanation = serverConfig.resolve("readme.txt");
        if (!Files.exists(explanation)) {
            try {
                Files.writeString(explanation, """
                        Any server configs put in this folder will override the corresponding server config from <instance path>/config/<config path>.
                        If the config being transferred is in a subfolder of the base config folder make sure to include that folder here in the path to the file you are overwriting.
                        For example if you are overwriting a config with the path <instance path>/config/ExampleMod/config-server.toml, you would need to put it in serverconfig/ExampleMod/config-server.toml
                        """, StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return serverConfig;
    }

    public static void handleServerAboutToStart(final MinecraftServer server) {
        currentServer = server;
        // on the dedi server we need to force the stuff to setup properly
        LogicalSidedProvider.setServer(() -> server);
        ConfigTracker.INSTANCE.loadConfigs(ModConfig.Type.SERVER, FMLPaths.CONFIGDIR.get(), getServerConfigPath(server));
        runModifiers(server);
        NeoForge.EVENT_BUS.post(new ServerAboutToStartEvent(server));
    }

    public static void handleServerStarting(final MinecraftServer server) {
        if (FMLEnvironment.dist.isDedicatedServer()) {
            LanguageHook.loadModLanguages(server);
            // GameTestServer requires the gametests to be registered earlier, so it is done in main and should not be done twice.
            if (!(server instanceof TestServer))
                GameTestHooks.registerGametests();
        }
        PermissionAPI.initializePermissionAPI();
        NeoForge.EVENT_BUS.post(new ServerStartingEvent(server));
    }

    public static void handleServerStarted(final MinecraftServer server) {
        NeoForge.EVENT_BUS.post(new ServerStartedEvent(server));
    }

    public static void handleServerStopping(final MinecraftServer server) {
        NeoForge.EVENT_BUS.post(new ServerStoppingEvent(server));
    }

    public static void expectServerStopped() {
        exitLatch = new CountDownLatch(1);
    }

    public static void handleServerStopped(final MinecraftServer server) {
        NeoForge.EVENT_BUS.post(new ServerStoppedEvent(server));
        currentServer = null;
        LogicalSidedProvider.setServer(null);
        CountDownLatch latch = exitLatch;

        if (latch != null) {
            latch.countDown();
            exitLatch = null;
        }
        ConfigTracker.INSTANCE.unloadConfigs(ModConfig.Type.SERVER);
    }

    @Nullable
    public static MinecraftServer getCurrentServer() {
        return currentServer;
    }

    public static void handleExit(int retVal) {
        System.exit(retVal);
    }

    private static <T> void ensureProperSync(boolean modified, RegistryEntry.Reference<T> holder, Registry<T> registry) {
        if (modified) {
            // If the object's networked data has been modified, we force it to sync by removing its original KnownPack info.
            Optional<RegistryEntryInfo> originalInfo = registry.getEntryInfo(holder.registryKey());
            originalInfo.ifPresent(info -> {
                RegistryEntryInfo newInfo = new RegistryEntryInfo(Optional.empty(), info.lifecycle());
                //noinspection unchecked
                ((MappedRegistryAccessor<T>) registry).neoforge$getRegistrationInfos().put(holder.registryKey(), newInfo);
            });
        }
    }

    private static void runModifiers(final MinecraftServer server) {
        final DynamicRegistryManager registries = server.getRegistryManager();

        // The order of holders() is the order modifiers were loaded in.
        final List<BiomeModifier> biomeModifiers = registries.get(NeoForgeRegistries.Keys.BIOME_MODIFIERS)
                .streamEntries()
                .map(RegistryEntry::value)
                .toList();
        final List<StructureModifier> structureModifiers = registries.get(Keys.STRUCTURE_MODIFIERS)
                .streamEntries()
                .map(RegistryEntry::value)
                .toList();

        final Set<EntityType<?>> entitiesWithoutPlacements = new HashSet<>();

        // Apply sorted biome modifiers to each biome.
        final var biomeRegistry = registries.get(RegistryKeys.BIOME);
        biomeRegistry.streamEntries().forEach(biomeHolder -> {
            final Biome biome = biomeHolder.value();
            ensureProperSync(
                    biome.modifiableBiomeInfo()
                            .applyBiomeModifiers(biomeHolder, biomeModifiers, registries),
                    biomeHolder,
                    biomeRegistry);

            final SpawnSettings mobSettings = biome.getSpawnSettings();
            mobSettings.getSpawnerTypes().forEach(category -> {
                mobSettings.getSpawnEntries(category).getEntries().forEach(data -> {
                    if (SpawnRestriction.hasPlacement(data.type)) return;
                    entitiesWithoutPlacements.add(data.type);
                });
            });

            for (SpawnGroup mobCategory : mobSettings.getSpawnerTypes()) {
                for (SpawnSettings.SpawnEntry spawnerData : mobSettings.getSpawnEntries(mobCategory).getEntries()) {
                    if (spawnerData.type.getSpawnGroup() != mobCategory) {
                        // Ignore vanilla bugged entries to reduce unneeded logging. See https://bugs.mojang.com/browse/MC-1788 for the Ocelot/Jungle vanilla bug.
                        boolean isVanillaBug = spawnerData.type == EntityType.OCELOT && (biomeHolder.matchesKey(BiomeKeys.JUNGLE) || biomeHolder.matchesKey(BiomeKeys.BAMBOO_JUNGLE));
                        if (!isVanillaBug) {
                            LOGGER.warn("Detected {} that was registered with {} mob category but was added under {} mob category for {} biome! " +
                                    "Mobs should be added to biomes under the same mob category that the mob was registered as to prevent mob cap spawning issues.",
                                    Registries.ENTITY_TYPE.getId(spawnerData.type),
                                    spawnerData.type.getSpawnGroup(),
                                    mobCategory,
                                    biomeHolder.getKey().getValue());
                        }
                    }
                }
            }
        });
        // Rebuild the indexed feature list
        registries.get(RegistryKeys.DIMENSION).forEach(levelStem -> {
            levelStem.chunkGenerator().refreshFeaturesPerStep();
        });

        // Apply sorted structure modifiers to each structure.
        registries.get(RegistryKeys.STRUCTURE).streamEntries().forEach(structureHolder -> {
            structureHolder.value().modifiableStructureInfo().applyStructureModifiers(structureHolder, structureModifiers);
        });

        if (!entitiesWithoutPlacements.isEmpty() && !FMLLoader.isProduction()) {
            LOGGER.error("The following entities have not registered to the RegisterSpawnPlacementsEvent, but a spawn entry was found. This will mean that the entity doesn't have restrictions on its spawn location, please register a spawn placement for the entity, you can register with NO_RESTRICTIONS if you don't want any restrictions."
                    + entitiesWithoutPlacements.stream().map(EntityType::getId).map(Identifier::toString).collect(Collectors.joining("\n\t - ", "\n\t - ", "")));
        }
    }
}
