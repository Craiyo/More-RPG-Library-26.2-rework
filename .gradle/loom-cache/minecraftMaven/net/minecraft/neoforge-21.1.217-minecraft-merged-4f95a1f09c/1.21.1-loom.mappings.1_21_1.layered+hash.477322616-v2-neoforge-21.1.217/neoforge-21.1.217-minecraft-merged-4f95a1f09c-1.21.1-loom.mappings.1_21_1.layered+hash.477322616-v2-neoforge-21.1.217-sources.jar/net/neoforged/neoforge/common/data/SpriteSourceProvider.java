/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.texture.atlas.AtlasSource;
import net.minecraft.client.texture.atlas.AtlasSourceManager;
import net.minecraft.data.DataOutput;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

/**
 * <p>Data provider for atlas configuration files.<br>
 * An atlas configuration is bound to a specific texture atlas such as the {@code minecraft:blocks} atlas and
 * allows adding additional textures to the atlas by adding {@link AtlasSource}s to the configuration.</p>
 * <p>See {@link AtlasSourceManager} for the available sources and the constants in this class for the
 * atlases used in vanilla Minecraft</p>
 */
public abstract class SpriteSourceProvider extends JsonCodecProvider<List<AtlasSource>> {
    protected static final Identifier BLOCKS_ATLAS = Identifier.ofVanilla("blocks");
    protected static final Identifier BANNER_PATTERNS_ATLAS = Identifier.ofVanilla("banner_patterns");
    protected static final Identifier BEDS_ATLAS = Identifier.ofVanilla("beds");
    protected static final Identifier CHESTS_ATLAS = Identifier.ofVanilla("chests");
    protected static final Identifier SHIELD_PATTERNS_ATLAS = Identifier.ofVanilla("shield_patterns");
    protected static final Identifier SHULKER_BOXES_ATLAS = Identifier.ofVanilla("shulker_boxes");
    protected static final Identifier SIGNS_ATLAS = Identifier.ofVanilla("signs");
    protected static final Identifier MOB_EFFECTS_ATLAS = Identifier.ofVanilla("mob_effects");
    protected static final Identifier PAINTINGS_ATLAS = Identifier.ofVanilla("paintings");
    protected static final Identifier PARTICLES_ATLAS = Identifier.ofVanilla("particles");

    private final Map<Identifier, SourceList> atlases = new HashMap<>();

    public SpriteSourceProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider, String modId, ExistingFileHelper existingFileHelper) {
        super(output, DataOutput.OutputType.RESOURCE_PACK, "atlases", ResourceType.CLIENT_RESOURCES, AtlasSourceManager.LIST_CODEC, lookupProvider, modId, existingFileHelper);
    }

    /**
     * Get or create a {@link SourceList} for the given atlas
     * 
     * @param id The texture atlas the sources should be added to, see constants at the top for the format
     *           and the vanilla atlases
     * @return an existing {@code SourceList} for the given atlas or a new one if not present yet
     */
    protected final SourceList atlas(Identifier id) {
        return atlases.computeIfAbsent(id, i -> {
            final SourceList newAtlas = new SourceList(new ArrayList<>());
            unconditional(i, newAtlas.sources());
            return newAtlas;
        });
    }

    protected record SourceList(List<AtlasSource> sources) {
        /**
         * Add the given {@link AtlasSource} to this atlas configuration
         * 
         * @param source The {@code SpriteSource} to be added
         */
        public SourceList addSource(AtlasSource source) {
            sources.add(source);
            return this;
        }
    }
}
