/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.network.configuration.CheckExtensibleEnums;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record ExtensibleEnumDataPayload(Map<String, CheckExtensibleEnums.EnumEntry> enumEntries) implements CustomPayload {
    public static final Id<ExtensibleEnumDataPayload> TYPE = new Id<>(Identifier.of("neoforge", "extensible_enum_data"));
    public static final PacketCodec<ByteBuf, ExtensibleEnumDataPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.collection(ArrayList::new, CheckExtensibleEnums.EnumEntry.STREAM_CODEC),
            ExtensibleEnumDataPayload::entries,
            ExtensibleEnumDataPayload::new);

    private ExtensibleEnumDataPayload(Collection<CheckExtensibleEnums.EnumEntry> entries) {
        this(entries.stream().collect(Collectors.toMap(CheckExtensibleEnums.EnumEntry::className, Function.identity())));
    }

    private Collection<CheckExtensibleEnums.EnumEntry> entries() {
        return enumEntries.values();
    }

    @Override
    public Id<ExtensibleEnumDataPayload> getId() {
        return TYPE;
    }
}
