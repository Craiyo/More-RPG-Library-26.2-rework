/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command.generation;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtString;
import net.minecraft.nbt.scanner.NbtScanQuery;
import net.minecraft.nbt.scanner.SelectiveNbtCollector;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ChunkHolder;
import net.minecraft.server.world.ChunkTaskPrioritySystem;
import net.minecraft.server.world.ChunkTicketType;
import net.minecraft.server.world.OptionalChunk;
import net.minecraft.server.world.ServerChunkLoadingManager;
import net.minecraft.server.world.ServerChunkManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Util;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Special thanks to Jasmine and Gegy for allowing us to use their pregenerator mod as a model to use in NeoForge!
 * Original code: <a href="https://github.com/jaskarth/fabric-chunkpregenerator">https://github.com/jaskarth/fabric-chunkpregenerator</a>
 */
public class GenerationTask {
    private static final Logger LOGGER = LogManager.getLogger();
    private static final int BATCH_SIZE = 32;
    private static final int QUEUE_THRESHOLD = 8;
    private static final int COARSE_CELL_SIZE = 4;

    private final MinecraftServer server;
    private final ServerChunkManager chunkSource;
    private final ServerWorld serverLevel;

    private final Iterator<ChunkPos> iterator;
    private final int x;
    private final int z;
    private final int radius;

    private final int totalCount;

    private final Object queueLock = new Object();

    private final AtomicInteger queuedCount = new AtomicInteger();
    private final AtomicInteger okCount = new AtomicInteger();
    private final AtomicInteger errorCount = new AtomicInteger();
    private final AtomicInteger skippedCount = new AtomicInteger();

    private volatile Listener listener;
    private volatile boolean stopped;

    public static final ChunkTicketType<ChunkPos> NEOFORGE_GENERATE_FORCED = ChunkTicketType.create("neoforge_generate_forced", Comparator.comparingLong(ChunkPos::toLong));

    public GenerationTask(ServerWorld serverLevel, int x, int z, int radius) {
        this.server = serverLevel.getServer();
        this.chunkSource = serverLevel.getChunkManager();
        this.serverLevel = serverLevel;

        this.iterator = new CoarseOnionIterator(radius, COARSE_CELL_SIZE);
        this.x = x;
        this.z = z;
        this.radius = radius;

        int diameter = radius * 2 + 1;
        this.totalCount = diameter * diameter;
    }

    public int getOkCount() {
        return this.okCount.get();
    }

    public int getErrorCount() {
        return this.errorCount.get();
    }

    public int getSkippedCount() {
        return this.skippedCount.get();
    }

    public int getTotalCount() {
        return this.totalCount;
    }

    public void run(Listener listener) {
        if (this.listener != null) {
            throw new IllegalStateException("already running!");
        }

        this.listener = listener;

        // Off thread chunk scanning to skip already generated chunks
        CompletableFuture.runAsync(this::tryEnqueueTasks, Util.getMainWorkerExecutor());
    }

    public void stop() {
        synchronized (this.queueLock) {
            this.stopped = true;
            this.listener = null;
        }
    }

    private void tryEnqueueTasks() {
        synchronized (this.queueLock) {
            if (this.stopped) {
                return;
            }

            int enqueueCount = BATCH_SIZE - this.queuedCount.get();
            if (enqueueCount <= 0) {
                return;
            }

            LongList chunks = this.collectChunks(enqueueCount);
            if (chunks.isEmpty()) {
                this.listener.complete(this.errorCount.get());
                this.stopped = true;
                return;
            }

            this.queuedCount.getAndAdd(chunks.size());

            // Keep on server thread as chunk acquiring and releasing (tickets) is not thread safe.
            this.server.submit(() -> this.enqueueChunks(chunks));
        }
    }

    private void enqueueChunks(LongList chunks) {
        for (int i = 0; i < chunks.size(); i++) {
            long chunk = chunks.getLong(i);
            this.acquireChunk(chunk);
        }

        // tick the chunk manager to force the ChunkHolders to be created
        this.chunkSource.tick(() -> false, true);

        ServerChunkLoadingManager chunkMap = this.chunkSource.chunkLoadingManager;

        for (int i = 0; i < chunks.size(); i++) {
            long chunkLongPos = chunks.getLong(i);

            ChunkHolder holder = chunkMap.getChunkHolder(chunkLongPos);
            if (holder == null) {
                LOGGER.warn("Added ticket for chunk but it was not added! ({}; {})", ChunkPos.getPackedX(chunkLongPos), ChunkPos.getPackedZ(chunkLongPos));
                this.acceptChunkResult(chunkLongPos, ChunkHolder.UNLOADED);
                continue;
            }

            holder.load(ChunkStatus.FULL, chunkMap).whenCompleteAsync((result, throwable) -> {
                if (throwable == null) {
                    this.acceptChunkResult(chunkLongPos, result);
                } else {
                    LOGGER.warn("Encountered unexpected error while generating chunk", throwable);
                    this.acceptChunkResult(chunkLongPos, ChunkHolder.UNLOADED);
                }
            }, runnable -> chunkMap.scheduleOnMainThreadMailbox(ChunkTaskPrioritySystem.createMessage(holder, runnable)));
        }
    }

    private void acceptChunkResult(long chunk, OptionalChunk<Chunk> result) {
        this.server.submit(() -> this.releaseChunk(chunk));

        if (result.isPresent()) {
            this.okCount.getAndIncrement();
        } else {
            this.errorCount.getAndIncrement();
        }

        this.listener.update(this.okCount.get(), this.errorCount.get(), this.skippedCount.get(), this.totalCount);

        int queuedCount = this.queuedCount.decrementAndGet();
        if (queuedCount <= QUEUE_THRESHOLD) {
            this.tryEnqueueTasks();
        }

        // Help make sure pregen progress does not get completely lost if game crashes/shuts down before pregen is finished.
        if (((this.okCount.get() + this.errorCount.get()) % 1000) == 999) {
            this.server.submit(() -> {
                this.serverLevel.save(null, false, true);
            });
        }
    }

    private LongList collectChunks(int count) {
        LongList chunks = new LongArrayList(count);

        Iterator<ChunkPos> iterator = this.iterator;
        int i = 0;
        while (i < count && iterator.hasNext()) {
            ChunkPos chunkPosInLocalSpace = iterator.next();
            if (isChunkFullyGenerated(chunkPosInLocalSpace)) {
                this.skippedCount.incrementAndGet();
                this.listener.update(this.okCount.get(), this.errorCount.get(), this.skippedCount.get(), this.totalCount);
                continue;
            }

            chunks.add(ChunkPos.toLong(chunkPosInLocalSpace.x + this.x, chunkPosInLocalSpace.z + this.z));
            i++;
        }

        return chunks;
    }

    private void acquireChunk(long chunk) {
        ChunkPos pos = new ChunkPos(chunk);
        this.chunkSource.addTicket(NEOFORGE_GENERATE_FORCED, pos, 0, pos);
    }

    private void releaseChunk(long chunk) {
        ChunkPos pos = new ChunkPos(chunk);
        this.chunkSource.removeTicket(NEOFORGE_GENERATE_FORCED, pos, 0, pos);
    }

    private boolean isChunkFullyGenerated(ChunkPos chunkPosInLocalSpace) {
        ChunkPos chunkPosInWorldSpace = new ChunkPos(chunkPosInLocalSpace.x + this.x, chunkPosInLocalSpace.z + this.z);
        SelectiveNbtCollector collectFields = new SelectiveNbtCollector(new NbtScanQuery(NbtString.TYPE, "Status"));
        this.chunkSource.chunkLoadingManager.getWorker().scanChunk(chunkPosInWorldSpace, collectFields).join();

        if (collectFields.getRoot() instanceof NbtCompound compoundTag) {
            return compoundTag.getString("Status").equals("minecraft:full");
        }

        return false;
    }

    public interface Listener {
        void update(int ok, int error, int skipped, int total);

        void complete(int error);
    }
}
