/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common;

import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.AbstractMap;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public final class TagConventionLogWarning {
    private TagConventionLogWarning() {}

    public enum LogWarningMode {
        SILENCED,
        DEV_SHORT,
        DEV_VERBOSE,
        PROD_SHORT,
        PROD_VERBOSE
    }

    private static final Logger LOGGER = LogManager.getLogger();

    /**
     * Old `forge` tags that we migrated to a new tag under a new convention.
     * May also contain commonly used `forge` tags that are not following convention.
     */
    private static final Map<TagKey<?>, String> LEGACY_FORGE_TAGS = Map.<TagKey<?>, String>ofEntries(
            createForgeMapEntry(RegistryKeys.BLOCK, "enderman_place_on_blacklist", Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST),
            createForgeMapEntry(RegistryKeys.BLOCK, "needs_wood_tool", Tags.Blocks.NEEDS_WOOD_TOOL),
            createForgeMapEntry(RegistryKeys.BLOCK, "needs_gold_tool", Tags.Blocks.NEEDS_GOLD_TOOL),
            createForgeMapEntry(RegistryKeys.BLOCK, "needs_netherite_tool", Tags.Blocks.NEEDS_NETHERITE_TOOL),

            createForgeMapEntry(RegistryKeys.BLOCK, "barrels", Tags.Blocks.BARRELS),
            createForgeMapEntry(RegistryKeys.BLOCK, "barrels/wooden", Tags.Blocks.BARRELS_WOODEN),
            createForgeMapEntry(RegistryKeys.BLOCK, "bookshelves", Tags.Blocks.BOOKSHELVES),
            createForgeMapEntry(RegistryKeys.BLOCK, "chests", Tags.Blocks.CHESTS),
            createForgeMapEntry(RegistryKeys.BLOCK, "chests/ender", Tags.Blocks.CHESTS_ENDER),
            createForgeMapEntry(RegistryKeys.BLOCK, "chests/trapped", Tags.Blocks.CHESTS_TRAPPED),
            createForgeMapEntry(RegistryKeys.BLOCK, "chests/wooden", Tags.Blocks.CHESTS_WOODEN),
            createForgeMapEntry(RegistryKeys.BLOCK, "cobblestone", Tags.Blocks.COBBLESTONES),
            createForgeMapEntry(RegistryKeys.BLOCK, "cobblestone/normal", Tags.Blocks.COBBLESTONES_NORMAL),
            createForgeMapEntry(RegistryKeys.BLOCK, "cobblestone/infested", Tags.Blocks.COBBLESTONES_INFESTED),
            createForgeMapEntry(RegistryKeys.BLOCK, "cobblestone/mossy", Tags.Blocks.COBBLESTONES_MOSSY),
            createForgeMapEntry(RegistryKeys.BLOCK, "cobblestone/deepslate", Tags.Blocks.COBBLESTONES_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.BLOCK, "crafting_table", Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.BLOCK, "crafting_tables", Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.BLOCK, "workbench", Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.BLOCK, "workbenches", Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.BLOCK, "end_stones", Tags.Blocks.END_STONES),
            createForgeMapEntry(RegistryKeys.BLOCK, "fence_gates", Tags.Blocks.FENCE_GATES),
            createForgeMapEntry(RegistryKeys.BLOCK, "fence_gates/wooden", Tags.Blocks.FENCE_GATES_WOODEN),
            createForgeMapEntry(RegistryKeys.BLOCK, "fences", Tags.Blocks.FENCES),
            createForgeMapEntry(RegistryKeys.BLOCK, "fences/nether_brick", Tags.Blocks.FENCES_NETHER_BRICK),
            createForgeMapEntry(RegistryKeys.BLOCK, "fences/wooden", Tags.Blocks.FENCES_WOODEN),
            createForgeMapEntry(RegistryKeys.BLOCK, "furnace", Tags.Blocks.PLAYER_WORKSTATIONS_FURNACES),
            createForgeMapEntry(RegistryKeys.BLOCK, "furnaces", Tags.Blocks.PLAYER_WORKSTATIONS_FURNACES),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass", Tags.Blocks.GLASS_BLOCKS),
            createMapEntry(RegistryKeys.BLOCK, "forge", "stained_glass", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/black", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_BLACK),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/blue", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_BLUE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/brown", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_BROWN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/cyan", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_CYAN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/gray", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_GRAY),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/green", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_GREEN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/light_blue", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_LIGHT_BLUE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/light_gray", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_LIGHT_GRAY),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/lime", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_LIME),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/magenta", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_MAGENTA),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/orange", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_ORANGE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/pink", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_PINK),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/purple", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_PURPLE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/red", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_RED),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/white", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_WHITE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass/yellow", Tags.Blocks.GLASS_BLOCKS, Tags.Blocks.DYED_YELLOW),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass/colorless", Tags.Blocks.GLASS_BLOCKS_COLORLESS),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass/silica", Tags.Blocks.GLASS_BLOCKS_CHEAP),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass/tinted", Tags.Blocks.GLASS_BLOCKS_TINTED),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass_panes", Tags.Blocks.GLASS_PANES),
            createMapEntry(RegistryKeys.BLOCK, "forge", "stained_glass_panes", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/black", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_BLACK),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/blue", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_BLUE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/brown", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_BROWN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/cyan", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_CYAN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/gray", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_GRAY),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/green", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_GREEN),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/light_blue", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_LIGHT_BLUE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/light_gray", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_LIGHT_GRAY),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/lime", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_LIME),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/magenta", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_MAGENTA),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/orange", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_ORANGE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/pink", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_PINK),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/purple", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_PURPLE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/red", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_RED),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/white", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_WHITE),
            createMapEntry(RegistryKeys.BLOCK, "forge", "glass_panes/yellow", Tags.Blocks.GLASS_PANES, Tags.Blocks.DYED_YELLOW),
            createForgeMapEntry(RegistryKeys.BLOCK, "glass_panes/colorless", Tags.Blocks.GLASS_PANES_COLORLESS),
            createForgeMapEntry(RegistryKeys.BLOCK, "gravel", Tags.Blocks.GRAVELS),
            createMapEntry(RegistryKeys.BLOCK, "c", "gravel", Tags.Blocks.GRAVELS),
            createForgeMapEntry(RegistryKeys.BLOCK, "heads", Tags.Blocks.SKULLS),
            createForgeMapEntry(RegistryKeys.BLOCK, "skulls", Tags.Blocks.SKULLS),
            createForgeMapEntry(RegistryKeys.BLOCK, "netherrack", Tags.Blocks.NETHERRACKS),
            createMapEntry(RegistryKeys.BLOCK, "c", "netherrack", Tags.Blocks.NETHERRACKS),
            createForgeMapEntry(RegistryKeys.BLOCK, "obsidian", Tags.Blocks.OBSIDIANS),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_bearing_ground/deepslate", Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_bearing_ground/netherrack", Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_bearing_ground/stone", Tags.Blocks.ORE_BEARING_GROUND_STONE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_rates/dense", Tags.Blocks.ORE_RATES_DENSE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_rates/singular", Tags.Blocks.ORE_RATES_SINGULAR),
            createForgeMapEntry(RegistryKeys.BLOCK, "ore_rates/sparse", Tags.Blocks.ORE_RATES_SPARSE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores", Tags.Blocks.ORES),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/coal", Tags.Blocks.ORES_COAL),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/copper", Tags.Blocks.ORES_COPPER),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/diamond", Tags.Blocks.ORES_DIAMOND),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/emerald", Tags.Blocks.ORES_EMERALD),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/gold", Tags.Blocks.ORES_GOLD),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/iron", Tags.Blocks.ORES_IRON),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/lapis", Tags.Blocks.ORES_LAPIS),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/netherite_scrap", Tags.Blocks.ORES_NETHERITE_SCRAP),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/quartz", Tags.Blocks.ORES_QUARTZ),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores/redstone", Tags.Blocks.ORES_REDSTONE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores_in_ground/deepslate", Tags.Blocks.ORES_IN_GROUND_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores_in_ground/netherrack", Tags.Blocks.ORES_IN_GROUND_NETHERRACK),
            createForgeMapEntry(RegistryKeys.BLOCK, "ores_in_ground/stone", Tags.Blocks.ORES_IN_GROUND_STONE),
            createForgeMapEntry(RegistryKeys.BLOCK, "sand", Tags.Blocks.SANDS),
            createForgeMapEntry(RegistryKeys.BLOCK, "sand/colorless", Tags.Blocks.SANDS_COLORLESS),
            createForgeMapEntry(RegistryKeys.BLOCK, "sand/red", Tags.Blocks.SANDS_RED),
            createForgeMapEntry(RegistryKeys.BLOCK, "sandstone", Tags.Blocks.SANDSTONE_BLOCKS),
            createForgeMapEntry(RegistryKeys.BLOCK, "stone", Tags.Blocks.STONES),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks", Tags.Blocks.STORAGE_BLOCKS),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/amethyst", "storage_blocks/amethyst"),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/coal", Tags.Blocks.STORAGE_BLOCKS_COAL),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/copper", Tags.Blocks.STORAGE_BLOCKS_COPPER),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/diamond", Tags.Blocks.STORAGE_BLOCKS_DIAMOND),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/emerald", Tags.Blocks.STORAGE_BLOCKS_EMERALD),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/gold", Tags.Blocks.STORAGE_BLOCKS_GOLD),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/iron", Tags.Blocks.STORAGE_BLOCKS_IRON),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/lapis", Tags.Blocks.STORAGE_BLOCKS_LAPIS),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/netherite", Tags.Blocks.STORAGE_BLOCKS_NETHERITE),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/quartz", "storage_blocks/quartz"),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/raw_copper", Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/raw_gold", Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/raw_iron", Tags.Blocks.STORAGE_BLOCKS_RAW_IRON),
            createForgeMapEntry(RegistryKeys.BLOCK, "storage_blocks/redstone", Tags.Blocks.STORAGE_BLOCKS_REDSTONE),

            createForgeMapEntry(RegistryKeys.BLOCK, "relocation_not_supported", Tags.Blocks.RELOCATION_NOT_SUPPORTED),
            createForgeMapEntry(RegistryKeys.BLOCK, "immovable", Tags.Blocks.RELOCATION_NOT_SUPPORTED),
            createForgeMapEntry(RegistryKeys.BLOCK_PREDICATE_TYPE, "relocation_not_supported", Tags.Blocks.RELOCATION_NOT_SUPPORTED),
            createForgeMapEntry(RegistryKeys.BLOCK_PREDICATE_TYPE, "immovable", Tags.Blocks.RELOCATION_NOT_SUPPORTED),

            createForgeMapEntry(RegistryKeys.ENTITY_TYPE, "bosses", Tags.EntityTypes.BOSSES),

            createForgeMapEntry(RegistryKeys.ITEM, "barrels", Tags.Items.BARRELS),
            createForgeMapEntry(RegistryKeys.ITEM, "barrels/wooden", Tags.Items.BARRELS_WOODEN),
            createForgeMapEntry(RegistryKeys.ITEM, "bones", Tags.Items.BONES),
            createForgeMapEntry(RegistryKeys.ITEM, "bookshelves", Tags.Items.BOOKSHELVES),
            createForgeMapEntry(RegistryKeys.ITEM, "bucket", Tags.Items.BUCKETS),
            createForgeMapEntry(RegistryKeys.ITEM, "chests", Tags.Items.CHESTS),
            createForgeMapEntry(RegistryKeys.ITEM, "chests/ender", Tags.Items.CHESTS_ENDER),
            createForgeMapEntry(RegistryKeys.ITEM, "chests/trapped", Tags.Items.CHESTS_TRAPPED),
            createForgeMapEntry(RegistryKeys.ITEM, "chests/wooden", Tags.Items.CHESTS_WOODEN),
            createForgeMapEntry(RegistryKeys.ITEM, "cobblestone", Tags.Items.COBBLESTONES),
            createForgeMapEntry(RegistryKeys.ITEM, "cobblestone/normal", Tags.Items.COBBLESTONES_NORMAL),
            createForgeMapEntry(RegistryKeys.ITEM, "cobblestone/infested", Tags.Items.COBBLESTONES_INFESTED),
            createForgeMapEntry(RegistryKeys.ITEM, "cobblestone/mossy", Tags.Items.COBBLESTONES_MOSSY),
            createForgeMapEntry(RegistryKeys.ITEM, "cobblestone/deepslate", Tags.Items.COBBLESTONES_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.ITEM, "crafting_table", Tags.Items.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.ITEM, "crafting_tables", Tags.Items.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.ITEM, "workbench", Tags.Items.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.ITEM, "workbenches", Tags.Items.PLAYER_WORKSTATIONS_CRAFTING_TABLES),
            createForgeMapEntry(RegistryKeys.ITEM, "crops", Tags.Items.CROPS),
            createForgeMapEntry(RegistryKeys.ITEM, "crops/beetroot", Tags.Items.CROPS_BEETROOT),
            createForgeMapEntry(RegistryKeys.ITEM, "crops/carrot", Tags.Items.CROPS_CARROT),
            createForgeMapEntry(RegistryKeys.ITEM, "crops/nether_wart", Tags.Items.CROPS_NETHER_WART),
            createForgeMapEntry(RegistryKeys.ITEM, "crops/potato", Tags.Items.CROPS_POTATO),
            createForgeMapEntry(RegistryKeys.ITEM, "crops/wheat", Tags.Items.CROPS_WHEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "dusts", Tags.Items.DUSTS),
            createForgeMapEntry(RegistryKeys.ITEM, "dusts/redstone", Tags.Items.DUSTS_REDSTONE),
            createForgeMapEntry(RegistryKeys.ITEM, "dusts/glowstone", Tags.Items.DUSTS_GLOWSTONE),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes", Tags.Items.DYES),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/black", Tags.Items.DYES_BLACK),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/red", Tags.Items.DYES_RED),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/green", Tags.Items.DYES_GREEN),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/brown", Tags.Items.DYES_BROWN),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/blue", Tags.Items.DYES_BLUE),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/purple", Tags.Items.DYES_PURPLE),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/cyan", Tags.Items.DYES_CYAN),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/light_gray", Tags.Items.DYES_LIGHT_GRAY),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/gray", Tags.Items.DYES_GRAY),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/pink", Tags.Items.DYES_PINK),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/lime", Tags.Items.DYES_LIME),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/yellow", Tags.Items.DYES_YELLOW),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/light_blue", Tags.Items.DYES_LIGHT_BLUE),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/magenta", Tags.Items.DYES_MAGENTA),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/orange", Tags.Items.DYES_ORANGE),
            createForgeMapEntry(RegistryKeys.ITEM, "dyes/white", Tags.Items.DYES_WHITE),
            createForgeMapEntry(RegistryKeys.ITEM, "eggs", Tags.Items.EGGS),
            createForgeMapEntry(RegistryKeys.ITEM, "enchanting_fuels", Tags.Items.ENCHANTING_FUELS),
            createForgeMapEntry(RegistryKeys.ITEM, "end_stones", Tags.Items.END_STONES),
            createForgeMapEntry(RegistryKeys.ITEM, "ender_pearls", Tags.Items.ENDER_PEARLS),
            createForgeMapEntry(RegistryKeys.ITEM, "feathers", Tags.Items.FEATHERS),
            createForgeMapEntry(RegistryKeys.ITEM, "fence_gates", Tags.Items.FENCE_GATES),
            createForgeMapEntry(RegistryKeys.ITEM, "fence_gates/wooden", Tags.Items.FENCE_GATES_WOODEN),
            createForgeMapEntry(RegistryKeys.ITEM, "fences", Tags.Items.FENCES),
            createForgeMapEntry(RegistryKeys.ITEM, "fences/nether_brick", Tags.Items.FENCES_NETHER_BRICK),
            createForgeMapEntry(RegistryKeys.ITEM, "fences/wooden", Tags.Items.FENCES_WOODEN),
            createForgeMapEntry(RegistryKeys.ITEM, "furnace", Tags.Items.PLAYER_WORKSTATIONS_FURNACES),
            createForgeMapEntry(RegistryKeys.ITEM, "furnaces", Tags.Items.PLAYER_WORKSTATIONS_FURNACES),
            createForgeMapEntry(RegistryKeys.ITEM, "gems", Tags.Items.GEMS),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/diamond", Tags.Items.GEMS_DIAMOND),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/emerald", Tags.Items.GEMS_EMERALD),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/amethyst", Tags.Items.GEMS_AMETHYST),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/lapis", Tags.Items.GEMS_LAPIS),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/prismarine", Tags.Items.GEMS_PRISMARINE),
            createForgeMapEntry(RegistryKeys.ITEM, "gems/quartz", Tags.Items.GEMS_QUARTZ),
            createForgeMapEntry(RegistryKeys.ITEM, "glass", Tags.Items.GLASS_BLOCKS),
            createMapEntry(RegistryKeys.ITEM, "forge", "stained_glass", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/black", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_BLACK),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/blue", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_BLUE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/brown", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_BROWN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/cyan", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_CYAN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/gray", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_GRAY),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/green", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_GREEN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/light_blue", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_LIGHT_BLUE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/light_gray", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_LIGHT_GRAY),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/lime", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_LIME),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/magenta", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_MAGENTA),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/orange", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_ORANGE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/pink", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_PINK),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/purple", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_PURPLE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/red", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_RED),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/white", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_WHITE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass/yellow", Tags.Items.GLASS_BLOCKS, Tags.Items.DYED_YELLOW),
            createForgeMapEntry(RegistryKeys.ITEM, "glass/colorless", Tags.Items.GLASS_BLOCKS_COLORLESS),
            createForgeMapEntry(RegistryKeys.ITEM, "glass/silica", Tags.Items.GLASS_BLOCKS_CHEAP),
            createForgeMapEntry(RegistryKeys.ITEM, "glass/tinted", Tags.Items.GLASS_BLOCKS_TINTED),
            createForgeMapEntry(RegistryKeys.ITEM, "glass_panes", Tags.Items.GLASS_PANES),
            createMapEntry(RegistryKeys.ITEM, "forge", "stained_glass_panes", Tags.Items.GLASS_PANES, Tags.Items.DYED),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/black", Tags.Items.GLASS_PANES, Tags.Items.DYED_BLACK),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/blue", Tags.Items.GLASS_PANES, Tags.Items.DYED_BLUE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/brown", Tags.Items.GLASS_PANES, Tags.Items.DYED_BROWN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/cyan", Tags.Items.GLASS_PANES, Tags.Items.DYED_CYAN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/gray", Tags.Items.GLASS_PANES, Tags.Items.DYED_GRAY),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/green", Tags.Items.GLASS_PANES, Tags.Items.DYED_GREEN),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/light_blue", Tags.Items.GLASS_PANES, Tags.Items.DYED_LIGHT_BLUE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/light_gray", Tags.Items.GLASS_PANES, Tags.Items.DYED_LIGHT_GRAY),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/lime", Tags.Items.GLASS_PANES, Tags.Items.DYED_LIME),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/magenta", Tags.Items.GLASS_PANES, Tags.Items.DYED_MAGENTA),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/orange", Tags.Items.GLASS_PANES, Tags.Items.DYED_ORANGE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/pink", Tags.Items.GLASS_PANES, Tags.Items.DYED_PINK),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/purple", Tags.Items.GLASS_PANES, Tags.Items.DYED_PURPLE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/red", Tags.Items.GLASS_PANES, Tags.Items.DYED_RED),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/white", Tags.Items.GLASS_PANES, Tags.Items.DYED_WHITE),
            createMapEntry(RegistryKeys.ITEM, "forge", "glass_panes/yellow", Tags.Items.GLASS_PANES, Tags.Items.DYED_YELLOW),
            createForgeMapEntry(RegistryKeys.ITEM, "glass_panes/colorless", Tags.Items.GLASS_PANES_COLORLESS),
            createForgeMapEntry(RegistryKeys.ITEM, "gravel", Tags.Items.GRAVELS),
            createMapEntry(RegistryKeys.ITEM, "c", "gravel", Tags.Items.GRAVELS),
            createForgeMapEntry(RegistryKeys.ITEM, "gunpowder", Tags.Items.GUNPOWDERS),
            createMapEntry(RegistryKeys.ITEM, "c", "gunpowder", Tags.Items.GUNPOWDERS),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots", Tags.Items.INGOTS),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/brick", Tags.Items.BRICKS_NORMAL),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/copper", Tags.Items.INGOTS_COPPER),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/gold", Tags.Items.INGOTS_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/iron", Tags.Items.INGOTS_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/netherite", Tags.Items.INGOTS_NETHERITE),
            createForgeMapEntry(RegistryKeys.ITEM, "ingots/nether_brick", Tags.Items.BRICKS_NETHER),
            createForgeMapEntry(RegistryKeys.ITEM, "leather", Tags.Items.LEATHERS),
            createMapEntry(RegistryKeys.ITEM, "c", "leather", Tags.Items.LEATHERS),
            createForgeMapEntry(RegistryKeys.ITEM, "mushrooms", Tags.Items.MUSHROOMS),
            createForgeMapEntry(RegistryKeys.ITEM, "nether_stars", Tags.Items.NETHER_STARS),
            createForgeMapEntry(RegistryKeys.ITEM, "netherrack", Tags.Items.NETHERRACKS),
            createMapEntry(RegistryKeys.ITEM, "c", "netherrack", Tags.Items.NETHERRACKS),
            createForgeMapEntry(RegistryKeys.ITEM, "nuggets", Tags.Items.NUGGETS),
            createForgeMapEntry(RegistryKeys.ITEM, "nuggets/gold", Tags.Items.NUGGETS_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "nuggets/iron", Tags.Items.NUGGETS_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "obsidian", Tags.Items.OBSIDIANS),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_bearing_ground/deepslate", Tags.Items.ORE_BEARING_GROUND_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_bearing_ground/netherrack", Tags.Items.ORE_BEARING_GROUND_NETHERRACK),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_bearing_ground/stone", Tags.Items.ORE_BEARING_GROUND_STONE),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_rates/dense", Tags.Items.ORE_RATES_DENSE),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_rates/singular", Tags.Items.ORE_RATES_SINGULAR),
            createForgeMapEntry(RegistryKeys.ITEM, "ore_rates/sparse", Tags.Items.ORE_RATES_SPARSE),
            createForgeMapEntry(RegistryKeys.ITEM, "ores", Tags.Items.ORES),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/coal", Tags.Items.ORES_COAL),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/copper", Tags.Items.ORES_COPPER),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/diamond", Tags.Items.ORES_DIAMOND),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/emerald", Tags.Items.ORES_EMERALD),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/gold", Tags.Items.ORES_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/iron", Tags.Items.ORES_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/lapis", Tags.Items.ORES_LAPIS),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/netherite_scrap", Tags.Items.ORES_NETHERITE_SCRAP),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/quartz", Tags.Items.ORES_QUARTZ),
            createForgeMapEntry(RegistryKeys.ITEM, "ores/redstone", Tags.Items.ORES_REDSTONE),
            createForgeMapEntry(RegistryKeys.ITEM, "ores_in_ground/deepslate", Tags.Items.ORES_IN_GROUND_DEEPSLATE),
            createForgeMapEntry(RegistryKeys.ITEM, "ores_in_ground/netherrack", Tags.Items.ORES_IN_GROUND_NETHERRACK),
            createForgeMapEntry(RegistryKeys.ITEM, "ores_in_ground/stone", Tags.Items.ORES_IN_GROUND_STONE),
            createMapEntry(RegistryKeys.ITEM, "c", "raw_blocks", Tags.Items.STORAGE_BLOCKS),
            createMapEntry(RegistryKeys.ITEM, "c", "raw_blocks/copper", Tags.Items.STORAGE_BLOCKS_COPPER),
            createMapEntry(RegistryKeys.ITEM, "c", "raw_blocks/gold", Tags.Items.STORAGE_BLOCKS_GOLD),
            createMapEntry(RegistryKeys.ITEM, "c", "raw_blocks/iron", Tags.Items.STORAGE_BLOCKS_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_materials", Tags.Items.RAW_MATERIALS),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_materials/copper", Tags.Items.RAW_MATERIALS_COPPER),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_materials/gold", Tags.Items.RAW_MATERIALS_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_materials/iron", Tags.Items.RAW_MATERIALS_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "rods", Tags.Items.RODS),
            createForgeMapEntry(RegistryKeys.ITEM, "rods/blaze", Tags.Items.RODS_BLAZE),
            createForgeMapEntry(RegistryKeys.ITEM, "rods/wooden", Tags.Items.RODS_WOODEN),
            createForgeMapEntry(RegistryKeys.ITEM, "rope", Tags.Items.ROPES),
            createForgeMapEntry(RegistryKeys.ITEM, "sand", Tags.Items.SANDS),
            createForgeMapEntry(RegistryKeys.ITEM, "sand/colorless", Tags.Items.SANDS_COLORLESS),
            createForgeMapEntry(RegistryKeys.ITEM, "sand/red", Tags.Items.SANDS_RED),
            createForgeMapEntry(RegistryKeys.ITEM, "sandstone", Tags.Items.SANDSTONE_BLOCKS),
            createForgeMapEntry(RegistryKeys.ITEM, "seeds", Tags.Items.SEEDS),
            createForgeMapEntry(RegistryKeys.ITEM, "seeds/beetroot", Tags.Items.SEEDS_BEETROOT),
            createForgeMapEntry(RegistryKeys.ITEM, "seeds/melon", Tags.Items.SEEDS_MELON),
            createForgeMapEntry(RegistryKeys.ITEM, "seeds/pumpkin", Tags.Items.SEEDS_PUMPKIN),
            createForgeMapEntry(RegistryKeys.ITEM, "seeds/wheat", Tags.Items.SEEDS_WHEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "shears", Tags.Items.TOOLS_SHEAR),
            createForgeMapEntry(RegistryKeys.ITEM, "slimeballs", Tags.Items.SLIME_BALLS),
            createForgeMapEntry(RegistryKeys.ITEM, "stone", Tags.Items.STONES),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks", Tags.Items.STORAGE_BLOCKS),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/amethyst", "storage_blocks/amethyst"),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/coal", Tags.Items.STORAGE_BLOCKS_COAL),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/copper", Tags.Items.STORAGE_BLOCKS_COPPER),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/diamond", Tags.Items.STORAGE_BLOCKS_DIAMOND),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/emerald", Tags.Items.STORAGE_BLOCKS_EMERALD),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/gold", Tags.Items.STORAGE_BLOCKS_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/iron", Tags.Items.STORAGE_BLOCKS_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/lapis", Tags.Items.STORAGE_BLOCKS_LAPIS),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/netherite", Tags.Items.STORAGE_BLOCKS_NETHERITE),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/quartz", "storage_blocks/quartz"),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/raw_copper", Tags.Items.STORAGE_BLOCKS_RAW_COPPER),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/raw_gold", Tags.Items.STORAGE_BLOCKS_RAW_GOLD),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/raw_iron", Tags.Items.STORAGE_BLOCKS_RAW_IRON),
            createForgeMapEntry(RegistryKeys.ITEM, "storage_blocks/redstone", Tags.Items.STORAGE_BLOCKS_REDSTONE),
            createForgeMapEntry(RegistryKeys.ITEM, "string", Tags.Items.STRINGS),
            createForgeMapEntry(RegistryKeys.ITEM, "tools", Tags.Items.TOOLS),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/shields", Tags.Items.TOOLS_SHIELD),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/bows", Tags.Items.TOOLS_BOW),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/crossbows", Tags.Items.TOOLS_CROSSBOW),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/fishing_rods", Tags.Items.TOOLS_FISHING_ROD),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/tridents", Tags.Items.TOOLS_SPEAR),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/brushes", Tags.Items.TOOLS_BRUSH),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/shields", Tags.Items.TOOLS_SHIELD),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/bows", Tags.Items.TOOLS_BOW),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/brushes", Tags.Items.TOOLS_BRUSH),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/crossbows", Tags.Items.TOOLS_CROSSBOW),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/fishing_rods", Tags.Items.TOOLS_FISHING_ROD),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/shears", Tags.Items.TOOLS_SHEAR),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/tridents", Tags.Items.TOOLS_SPEAR),
            createForgeMapEntry(RegistryKeys.ITEM, "armors", Tags.Items.ARMORS),
            createForgeMapEntry(RegistryKeys.ITEM, "armors/helmets", ItemTags.HEAD_ARMOR),
            createForgeMapEntry(RegistryKeys.ITEM, "armors/chestplates", ItemTags.CHEST_ARMOR),
            createForgeMapEntry(RegistryKeys.ITEM, "armors/leggings", ItemTags.LEG_ARMOR),
            createForgeMapEntry(RegistryKeys.ITEM, "armors/boots", ItemTags.FOOT_ARMOR),
            createForgeMapEntry(RegistryKeys.ITEM, "wrench", Tags.Items.TOOLS_WRENCH),
            createForgeMapEntry(RegistryKeys.ITEM, "wrenches", Tags.Items.TOOLS_WRENCH),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/wrench", Tags.Items.TOOLS_WRENCH),
            createForgeMapEntry(RegistryKeys.ITEM, "tools/wrenches", Tags.Items.TOOLS_WRENCH),
            createMapEntry(RegistryKeys.ITEM, "c", "tools/wrenches", Tags.Items.TOOLS_WRENCH),
            createForgeMapEntry(RegistryKeys.ITEM, "food", Tags.Items.FOODS),
            createForgeMapEntry(RegistryKeys.ITEM, "foods", Tags.Items.FOODS),
            createForgeMapEntry(RegistryKeys.ITEM, "fruit", Tags.Items.FOODS_FRUIT),
            createForgeMapEntry(RegistryKeys.ITEM, "fruits", Tags.Items.FOODS_FRUIT),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/fruits", Tags.Items.FOODS_FRUIT),
            createForgeMapEntry(RegistryKeys.ITEM, "vegetable", Tags.Items.FOODS_VEGETABLE),
            createForgeMapEntry(RegistryKeys.ITEM, "vegetables", Tags.Items.FOODS_VEGETABLE),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/vegetables", Tags.Items.FOODS_VEGETABLE),
            createForgeMapEntry(RegistryKeys.ITEM, "berry", Tags.Items.FOODS_BERRY),
            createForgeMapEntry(RegistryKeys.ITEM, "berries", Tags.Items.FOODS_BERRY),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/berries", Tags.Items.FOODS_BERRY),
            createForgeMapEntry(RegistryKeys.ITEM, "bread", Tags.Items.FOODS_BREAD),
            createForgeMapEntry(RegistryKeys.ITEM, "breads", Tags.Items.FOODS_BREAD),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/breads", Tags.Items.FOODS_BREAD),
            createForgeMapEntry(RegistryKeys.ITEM, "cookie", Tags.Items.FOODS_COOKIE),
            createForgeMapEntry(RegistryKeys.ITEM, "cookies", Tags.Items.FOODS_COOKIE),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/cookies", Tags.Items.FOODS_COOKIE),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_meat", Tags.Items.FOODS_RAW_MEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_meats", Tags.Items.FOODS_RAW_MEAT),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/raw_meats", Tags.Items.FOODS_RAW_MEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_fish", Tags.Items.FOODS_RAW_FISH),
            createForgeMapEntry(RegistryKeys.ITEM, "raw_fishes", Tags.Items.FOODS_RAW_FISH),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/raw_fishes", Tags.Items.FOODS_RAW_FISH),
            createForgeMapEntry(RegistryKeys.ITEM, "cooked_meat", Tags.Items.FOODS_COOKED_MEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "cooked_meats", Tags.Items.FOODS_COOKED_MEAT),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/cooked_meats", Tags.Items.FOODS_COOKED_MEAT),
            createForgeMapEntry(RegistryKeys.ITEM, "cooked_fish", Tags.Items.FOODS_COOKED_FISH),
            createForgeMapEntry(RegistryKeys.ITEM, "cooked_fishes", Tags.Items.FOODS_COOKED_FISH),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/cooked_fishes", Tags.Items.FOODS_COOKED_FISH),
            createForgeMapEntry(RegistryKeys.ITEM, "soup", Tags.Items.FOODS_SOUP),
            createForgeMapEntry(RegistryKeys.ITEM, "soups", Tags.Items.FOODS_SOUP),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/soups", Tags.Items.FOODS_SOUP),
            createForgeMapEntry(RegistryKeys.ITEM, "stew", Tags.Items.FOODS_SOUP),
            createForgeMapEntry(RegistryKeys.ITEM, "stews", Tags.Items.FOODS_SOUP),
            createForgeMapEntry(RegistryKeys.ITEM, "candy", Tags.Items.FOODS_CANDY),
            createForgeMapEntry(RegistryKeys.ITEM, "candies", Tags.Items.FOODS_CANDY),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/candies", Tags.Items.FOODS_CANDY),
            createForgeMapEntry(RegistryKeys.ITEM, "pie", Tags.Items.FOODS_PIE),
            createForgeMapEntry(RegistryKeys.ITEM, "pies", Tags.Items.FOODS_PIE),
            createMapEntry(RegistryKeys.ITEM, "c", "foods/pies", Tags.Items.FOODS_PIE),

            createForgeMapEntry(RegistryKeys.FLUID, "water", Tags.Fluids.WATER),
            createForgeMapEntry(RegistryKeys.FLUID, "lava", Tags.Fluids.LAVA),
            createForgeMapEntry(RegistryKeys.FLUID, "milk", Tags.Fluids.MILK),
            createForgeMapEntry(RegistryKeys.FLUID, "gaseous", Tags.Fluids.GASEOUS),
            createForgeMapEntry(RegistryKeys.FLUID, "honey", Tags.Fluids.HONEY),
            createForgeMapEntry(RegistryKeys.FLUID, "xp", Tags.Fluids.EXPERIENCE),
            createForgeMapEntry(RegistryKeys.FLUID, "experience", Tags.Fluids.EXPERIENCE),
            createForgeMapEntry(RegistryKeys.FLUID, "potion", Tags.Fluids.POTION),
            createForgeMapEntry(RegistryKeys.FLUID, "plantoil", "plant_oil"),

            createForgeMapEntry(RegistryKeys.BIOME, "is_hot", Tags.Biomes.IS_HOT),
            createForgeMapEntry(RegistryKeys.BIOME, "is_hot/overworld", Tags.Biomes.IS_HOT_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_hot/nether", Tags.Biomes.IS_HOT_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_hot/end", Tags.Biomes.IS_HOT_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_cold", Tags.Biomes.IS_COLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_cold/overworld", Tags.Biomes.IS_COLD_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_cold/nether", Tags.Biomes.IS_COLD_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_cold/end", Tags.Biomes.IS_COLD_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_sparse", Tags.Biomes.IS_SPARSE_VEGETATION),
            createForgeMapEntry(RegistryKeys.BIOME, "is_sparse/overworld", Tags.Biomes.IS_SPARSE_VEGETATION_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_sparse/nether", Tags.Biomes.IS_SPARSE_VEGETATION_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_sparse/end", Tags.Biomes.IS_SPARSE_VEGETATION_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dense", Tags.Biomes.IS_DENSE_VEGETATION),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dense/overworld", Tags.Biomes.IS_DENSE_VEGETATION_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dense/nether", Tags.Biomes.IS_DENSE_VEGETATION_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dense/end", Tags.Biomes.IS_DENSE_VEGETATION_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_wet", Tags.Biomes.IS_WET),
            createForgeMapEntry(RegistryKeys.BIOME, "is_wet/overworld", Tags.Biomes.IS_WET_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_wet/nether", Tags.Biomes.IS_WET_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_wet/end", Tags.Biomes.IS_WET_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dry", Tags.Biomes.IS_DRY),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dry/overworld", Tags.Biomes.IS_DRY_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dry/nether", Tags.Biomes.IS_DRY_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dry/end", Tags.Biomes.IS_DRY_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_coniferous", Tags.Biomes.IS_CONIFEROUS_TREE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_savanna", Tags.Biomes.IS_SAVANNA_TREE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_jungle", Tags.Biomes.IS_JUNGLE_TREE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_deciduous", Tags.Biomes.IS_DECIDUOUS_TREE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_spooky", Tags.Biomes.IS_SPOOKY),
            createForgeMapEntry(RegistryKeys.BIOME, "is_dead", Tags.Biomes.IS_DEAD),
            createForgeMapEntry(RegistryKeys.BIOME, "is_lush", Tags.Biomes.IS_LUSH),
            createForgeMapEntry(RegistryKeys.BIOME, "is_mushroom", Tags.Biomes.IS_MUSHROOM),
            createForgeMapEntry(RegistryKeys.BIOME, "is_magical", Tags.Biomes.IS_MAGICAL),
            createForgeMapEntry(RegistryKeys.BIOME, "is_rare", Tags.Biomes.IS_RARE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_plateau", Tags.Biomes.IS_PLATEAU),
            createForgeMapEntry(RegistryKeys.BIOME, "is_modified", Tags.Biomes.IS_MODIFIED),
            createForgeMapEntry(RegistryKeys.BIOME, "is_water", Tags.Biomes.IS_AQUATIC),
            createForgeMapEntry(RegistryKeys.BIOME, "is_desert", Tags.Biomes.IS_DESERT),
            createForgeMapEntry(RegistryKeys.BIOME, "is_plains", Tags.Biomes.IS_PLAINS),
            createForgeMapEntry(RegistryKeys.BIOME, "is_swamp", Tags.Biomes.IS_SWAMP),
            createForgeMapEntry(RegistryKeys.BIOME, "is_sandy", Tags.Biomes.IS_SANDY),
            createForgeMapEntry(RegistryKeys.BIOME, "is_snowy", Tags.Biomes.IS_SNOWY),
            createForgeMapEntry(RegistryKeys.BIOME, "is_wasteland", Tags.Biomes.IS_WASTELAND),
            createForgeMapEntry(RegistryKeys.BIOME, "is_void", Tags.Biomes.IS_VOID),
            createForgeMapEntry(RegistryKeys.BIOME, "is_underground", Tags.Biomes.IS_UNDERGROUND),
            createForgeMapEntry(RegistryKeys.BIOME, "is_cave", Tags.Biomes.IS_CAVE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_peak", Tags.Biomes.IS_MOUNTAIN_PEAK),
            createForgeMapEntry(RegistryKeys.BIOME, "is_slope", Tags.Biomes.IS_MOUNTAIN_SLOPE),
            createForgeMapEntry(RegistryKeys.BIOME, "is_mountain", Tags.Biomes.IS_MOUNTAIN),
            createForgeMapEntry(RegistryKeys.BIOME, "is_end", Tags.Biomes.IS_END),
            createForgeMapEntry(RegistryKeys.BIOME, "is_nether", Tags.Biomes.IS_NETHER),
            createForgeMapEntry(RegistryKeys.BIOME, "is_overworld", Tags.Biomes.IS_OVERWORLD),
            createForgeMapEntry(RegistryKeys.BIOME, "no_default_monsters", Tags.Biomes.NO_DEFAULT_MONSTERS));

    /*package private*/
    static void init() {
        IEventBus forgeBus = NeoForge.EVENT_BUS;

        setupLegacyTagWarning(forgeBus);
    }

    // Remove in 1.22
    private static void setupLegacyTagWarning(IEventBus forgeBus) {
        // Log tags that are still using legacy 'forge' namespace
        forgeBus.addListener((ServerStartingEvent serverStartingEvent) -> {
            // We have to wait for server start to read the server config.
            LogWarningMode legacyTagWarningMode = NeoForgeConfig.COMMON.logLegacyTagWarnings.get();
            if (legacyTagWarningMode != LogWarningMode.SILENCED) {
                boolean isConfigSetToDev = legacyTagWarningMode == LogWarningMode.DEV_SHORT ||
                        legacyTagWarningMode == LogWarningMode.DEV_VERBOSE;

                if (!FMLLoader.isProduction() == isConfigSetToDev) {
                    List<TagKey<?>> legacyTags = new ObjectArrayList<>();
                    DynamicRegistryManager.Immutable registryAccess = serverStartingEvent.getServer().getRegistryManager();

                    // We only care about vanilla registries
                    registryAccess.streamAllRegistries().forEach(registryEntry -> {
                        if (registryEntry.key().getValue().getNamespace().equals("minecraft")) {
                            registryEntry.value().streamTags().forEach(tagKey -> {
                                // Grab tags under 'forge' namespace
                                if (LEGACY_FORGE_TAGS.containsKey(tagKey) || tagKey.id().getNamespace().equals("forge")) {
                                    legacyTags.add(tagKey);
                                }
                            });
                        }
                    });

                    if (!legacyTags.isEmpty()) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("""
                                \n   Dev warning - Legacy Tags detected. Please migrate your 'forge' namespace tags to the 'c' namespace! See net.neoforged.neoforge.common.Tags.java for all tags.
                                   NOTE: Many tags have been moved around or renamed. Some new ones were added so please review the new tags.
                                    And make sure you follow tag conventions for new tags! The convention is `c` with nouns generally being plural and adjectives being singular.
                                   You can disable this message in NeoForge's common config by setting `logLegacyTagWarnings` to "SILENCED" or see individual tags with "DEV_VERBOSE".
                                """);

                        // Print out all legacy tags when desired.
                        boolean isConfigSetToVerbose = legacyTagWarningMode == LogWarningMode.DEV_VERBOSE ||
                                legacyTagWarningMode == LogWarningMode.PROD_VERBOSE;

                        if (isConfigSetToVerbose) {
                            stringBuilder.append("\nLegacy tags:");
                            for (TagKey<?> tagKey : legacyTags) {
                                if (LEGACY_FORGE_TAGS.containsKey(tagKey)) {
                                    String replacementMessage = LEGACY_FORGE_TAGS.get(tagKey);
                                    stringBuilder.append("\n     ").append(tagKey).append("  ->  ").append(replacementMessage);
                                } else {
                                    stringBuilder.append("\n     ").append(tagKey).append("  ->  ").append("See similar `c` tags in NeoForge's Tags class");
                                }
                            }
                        }

                        LOGGER.warn(stringBuilder);
                    }
                }
            }
        });
    }

    private static <T> AbstractMap.SimpleEntry<TagKey<T>, String> createForgeMapEntry(RegistryKey<Registry<T>> registryKey, String tagId1, String tagId2) {
        return new AbstractMap.SimpleEntry<>(createTagKey(registryKey, "forge", tagId1), "c:" + tagId2);
    }

    private static <T, R> AbstractMap.SimpleEntry<TagKey<T>, String> createForgeMapEntry(RegistryKey<Registry<T>> registryKey, String tagId1, TagKey<R> tag2) {
        return new AbstractMap.SimpleEntry<>(createTagKey(registryKey, "forge", tagId1), tag2.toString());
    }

    private static <T, R> AbstractMap.SimpleEntry<TagKey<T>, String> createMapEntry(RegistryKey<Registry<T>> registryKey, String tagNamespace1, String tagId1, TagKey<R> tag2) {
        return new AbstractMap.SimpleEntry<>(createTagKey(registryKey, tagNamespace1, tagId1), tag2.toString());
    }

    private static <T, R> AbstractMap.SimpleEntry<TagKey<T>, String> createMapEntry(RegistryKey<Registry<T>> registryKey, String tagNamespace1, String tagId1, TagKey<R>... replacementTags) {
        return new AbstractMap.SimpleEntry<>(createTagKey(registryKey, tagNamespace1, tagId1), String.join(" and ", Arrays.stream(replacementTags).map(TagKey::toString).toList()));
    }

    private static <T> TagKey<T> createTagKey(RegistryKey<Registry<T>> registryKey, String namespace, String tagId) {
        return TagKey.of(registryKey, Identifier.of(namespace, tagId));
    }
}
