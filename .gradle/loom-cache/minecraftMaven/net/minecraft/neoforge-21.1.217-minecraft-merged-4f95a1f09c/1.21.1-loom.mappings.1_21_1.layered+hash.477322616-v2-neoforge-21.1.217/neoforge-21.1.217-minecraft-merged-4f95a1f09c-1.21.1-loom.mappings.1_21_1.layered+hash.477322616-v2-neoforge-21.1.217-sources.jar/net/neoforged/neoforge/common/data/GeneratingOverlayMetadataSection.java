/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.resource.metadata.PackOverlaysMetadata;
import net.minecraft.resource.metadata.ResourceMetadataSerializer;
import net.neoforged.neoforge.common.conditions.ConditionalOps;
import net.neoforged.neoforge.common.conditions.WithConditions;
import net.neoforged.neoforge.common.util.NeoForgeExtraCodecs;

/**
 * Can be used in place of {@link PackOverlaysMetadata} during datagen if you wish to generate conditions.
 */
public record GeneratingOverlayMetadataSection(List<WithConditions<PackOverlaysMetadata.Entry>> overlays) {
    private static final Codec<GeneratingOverlayMetadataSection> CODEC = RecordCodecBuilder.create(i -> i.group(
            NeoForgeExtraCodecs.listWithOptionalElements(
                    ConditionalOps.createConditionalCodecWithConditions(PackOverlaysMetadata.Entry.CODEC)).fieldOf("entries").forGetter(GeneratingOverlayMetadataSection::overlays))
            .apply(i, GeneratingOverlayMetadataSection::new));
    public static final ResourceMetadataSerializer<GeneratingOverlayMetadataSection> TYPE = ResourceMetadataSerializer.fromCodec("overlays", CODEC);
    public static final ResourceMetadataSerializer<GeneratingOverlayMetadataSection> NEOFORGE_TYPE = ResourceMetadataSerializer.fromCodec("neoforge:overlays", CODEC);
}
