/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.builder.ArgumentBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.dimension.DimensionType;

class DimensionsCommand {
    static ArgumentBuilder<ServerCommandSource, ?> register() {
        return CommandManager.literal("dimensions")
                .requires(cs -> cs.hasPermissionLevel(0)) //permission
                .executes(ctx -> {
                    ctx.getSource().sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.dimensions.list"), true);
                    final Registry<DimensionType> reg = ctx.getSource().getRegistryManager().get(RegistryKeys.DIMENSION_TYPE);

                    Map<Identifier, List<Text>> types = new HashMap<>();
                    for (ServerWorld dim : ctx.getSource().getServer().getWorlds()) {
                        types.computeIfAbsent(reg.getId(dim.getDimension()), k -> new ArrayList<>()).add(dim.getDescription());
                    }

                    types.keySet().stream().sorted().forEach(key -> {
                        ctx.getSource().sendFeedback(() -> {
                            var component = Text.literal(key + ": ");
                            var components = types.get(key);

                            for (int i = 0; i < components.size(); i++) {
                                component.append(components.get(i));

                                if (i + 1 < components.size())
                                    component.append(", ");
                            }

                            return component;
                        }, false);
                    });
                    return 0;
                });
    }
}
