/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public interface ITagAppenderExtension<T> {
    private TagProvider.ProvidedTagBuilder<T> self() {
        return (TagProvider.ProvidedTagBuilder<T>) this;
    }

    @SuppressWarnings("unchecked")
    default TagProvider.ProvidedTagBuilder<T> addTags(TagKey<T>... values) {
        TagProvider.ProvidedTagBuilder<T> builder = self();
        for (TagKey<T> value : values) {
            builder.addTag(value);
        }
        return builder;
    }

    default TagProvider.ProvidedTagBuilder<T> addOptionalTag(TagKey<T> value) {
        return self().addOptionalTag(value.id());
    }

    @SuppressWarnings("unchecked")
    default TagProvider.ProvidedTagBuilder<T> addOptionalTags(TagKey<T>... values) {
        TagProvider.ProvidedTagBuilder<T> builder = self();
        for (TagKey<T> value : values) {
            builder.addOptionalTag(value.id());
        }
        return builder;
    }

    default TagProvider.ProvidedTagBuilder<T> replace() {
        return replace(true);
    }

    default TagProvider.ProvidedTagBuilder<T> replace(boolean value) {
        self().getInternalBuilder().replace(value);
        return self();
    }

    /**
     * Adds a single element's ID to the tag json's remove list. Callable during datageneration.
     * 
     * @param location The ID of the element to remove
     * @return The builder for chaining
     */
    default TagProvider.ProvidedTagBuilder<T> remove(final Identifier location) {
        TagProvider.ProvidedTagBuilder<T> builder = self();
        builder.getInternalBuilder().removeElement(location);
        return builder;
    }

    /**
     * Adds multiple elements' IDs to the tag json's remove list. Callable during datageneration.
     * 
     * @param locations The IDs of the elements to remove
     * @return The builder for chaining
     */
    default TagProvider.ProvidedTagBuilder<T> remove(final Identifier first, final Identifier... locations) {
        this.remove(first);
        for (Identifier location : locations) {
            this.remove(location);
        }
        return self();
    }

    /**
     * Adds a resource key to the tag json's remove list. Callable during datageneration.
     *
     * @param resourceKey The resource key of the element to remove
     * @return The appender for chaining
     */
    default TagProvider.ProvidedTagBuilder<T> remove(final RegistryKey<T> resourceKey) {
        this.remove(resourceKey.getValue());
        return self();
    }

    /**
     * Adds multiple resource keys to the tag json's remove list. Callable during datageneration.
     *
     * @param resourceKeys The resource keys of the elements to remove
     * @return The appender for chaining
     */
    @SuppressWarnings("unchecked")
    default TagProvider.ProvidedTagBuilder<T> remove(final RegistryKey<T> firstResourceKey, final RegistryKey<T>... resourceKeys) {
        this.remove(firstResourceKey.getValue());
        for (RegistryKey<T> resourceKey : resourceKeys) {
            this.remove(resourceKey.getValue());
        }
        return self();
    }

    /**
     * Adds a tag to the tag json's remove list. Callable during datageneration.
     * 
     * @param tag The ID of the tag to remove
     * @return The builder for chaining
     */
    default TagProvider.ProvidedTagBuilder<T> remove(TagKey<T> tag) {
        TagProvider.ProvidedTagBuilder<T> builder = self();
        builder.getInternalBuilder().removeTag(tag.id());
        return builder;
    }

    /**
     * Adds multiple tags to the tag json's remove list. Callable during datageneration.
     * 
     * @param tags The IDs of the tags to remove
     * @return The builder for chaining
     */
    @SuppressWarnings("unchecked")
    default TagProvider.ProvidedTagBuilder<T> remove(TagKey<T> first, TagKey<T>... tags) {
        this.remove(first);
        for (TagKey<T> tag : tags) {
            this.remove(tag);
        }
        return self();
    }
}
