/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data.internal;

import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.ValueLookupTagProvider;
import net.minecraft.data.server.tag.vanilla.VanillaFluidTagProvider;
import net.minecraft.fluid.Fluid;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.common.Tags.Fluids;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

public final class NeoForgeFluidTagsProvider extends VanillaFluidTagProvider {
    public NeoForgeFluidTagsProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider, ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, "neoforge", existingFileHelper);
    }

    @Override
    public void configure(RegistryWrapper.WrapperLookup lookupProvider) {
        getOrCreateTagBuilder(Fluids.WATER).add(net.minecraft.fluid.Fluids.WATER).add(net.minecraft.fluid.Fluids.FLOWING_WATER);
        getOrCreateTagBuilder(Fluids.LAVA).add(net.minecraft.fluid.Fluids.LAVA).add(net.minecraft.fluid.Fluids.FLOWING_LAVA);
        getOrCreateTagBuilder(Fluids.MILK).addOptional(NeoForgeMod.MILK.getId()).addOptional(NeoForgeMod.FLOWING_MILK.getId());
        getOrCreateTagBuilder(Fluids.GASEOUS);
        getOrCreateTagBuilder(Fluids.HONEY);
        getOrCreateTagBuilder(Fluids.EXPERIENCE);
        getOrCreateTagBuilder(Fluids.POTION);
        getOrCreateTagBuilder(Fluids.SUSPICIOUS_STEW);
        getOrCreateTagBuilder(Fluids.MUSHROOM_STEW);
        getOrCreateTagBuilder(Fluids.RABBIT_STEW);
        getOrCreateTagBuilder(Fluids.BEETROOT_SOUP);
        getOrCreateTagBuilder(Fluids.HIDDEN_FROM_RECIPE_VIEWERS);

        // Backwards compat with pre-1.21 tags. Done after so optional tag is last for better readability.
        // TODO: Remove backwards compat tag entries in 1.22
        tagWithOptionalLegacy(Fluids.MILK);
        tagWithOptionalLegacy(Fluids.GASEOUS);
        tagWithOptionalLegacy(Fluids.HONEY);
        tagWithOptionalLegacy(Fluids.POTION);
        tagWithOptionalLegacy(Fluids.SUSPICIOUS_STEW);
        tagWithOptionalLegacy(Fluids.MUSHROOM_STEW);
        tagWithOptionalLegacy(Fluids.RABBIT_STEW);
        tagWithOptionalLegacy(Fluids.BEETROOT_SOUP);
    }

    private ValueLookupTagProvider.ObjectBuilder<Fluid> tagWithOptionalLegacy(TagKey<Fluid> tag) {
        ValueLookupTagProvider.ObjectBuilder<Fluid> tagAppender = getOrCreateTagBuilder(tag);
        tagAppender.addOptionalTag(Identifier.of("forge", tag.id().getPath()));
        return tagAppender;
    }
}
