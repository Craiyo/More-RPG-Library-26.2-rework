/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.extensions;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.DimensionEffects;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Extension interface for {@link DimensionEffects}.
 */
public interface IDimensionSpecialEffectsExtension {
    private DimensionEffects self() {
        return (DimensionEffects) this;
    }

    /**
     * Renders the clouds of this dimension.
     *
     * @return true to prevent vanilla cloud rendering
     */
    default boolean renderClouds(ClientWorld level, int ticks, float partialTick, MatrixStack poseStack, double camX, double camY, double camZ, Matrix4f modelViewMatrix, Matrix4f projectionMatrix) {
        return false;
    }

    /**
     * Renders the sky of this dimension.
     *
     * @return true to prevent vanilla sky rendering
     */
    default boolean renderSky(ClientWorld level, int ticks, float partialTick, Matrix4f modelViewMatrix, Camera camera, Matrix4f projectionMatrix, boolean isFoggy, Runnable setupFog) {
        return false;
    }

    /**
     * Renders the snow and rain effects of this dimension.
     *
     * @return true to prevent vanilla snow and rain rendering
     */
    default boolean renderSnowAndRain(ClientWorld level, int ticks, float partialTick, LightmapTextureManager lightTexture, double camX, double camY, double camZ) {
        return false;
    }

    /**
     * Ticks the rain of this dimension.
     *
     * @return true to prevent vanilla rain ticking
     */
    default boolean tickRain(ClientWorld level, int ticks, Camera camera) {
        return false;
    }

    /**
     * Allows for manipulating the coloring of the lightmap texture.
     * Will be called for each 16*16 combination of sky/block light values.
     *
     * @param level                The current level (client-side).
     * @param partialTicks         Progress between ticks.
     * @param skyDarken            Current darkness of the sky (can be used to calculate sky light).
     * @param blockLightRedFlicker Block light flicker factor (red color) (can be used to calculate block light).
     * @param skyLight             Sky light brightness (accounting for sky darkness).
     * @param pixelX               X-coordinate of the lightmap texture (block).
     * @param pixelY               Y-coordinate of the lightmap texture (sky).
     * @param colors               The color values that will be used: [r, g, b].
     * @see LightmapTextureManager#update(float)
     */
    default void adjustLightmapColors(ClientWorld level, float partialTicks, float skyDarken, float blockLightRedFlicker, float skyLight, int pixelX, int pixelY, Vector3f colors) {}
}
