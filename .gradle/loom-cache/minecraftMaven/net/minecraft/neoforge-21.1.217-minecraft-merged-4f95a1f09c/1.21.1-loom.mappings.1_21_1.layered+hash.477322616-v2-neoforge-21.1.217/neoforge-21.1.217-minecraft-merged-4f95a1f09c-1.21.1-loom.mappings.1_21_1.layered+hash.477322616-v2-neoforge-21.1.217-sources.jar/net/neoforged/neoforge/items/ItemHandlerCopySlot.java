/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.items;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

/**
 * Slot class that can be used with immutable {@link IItemHandler}s
 * like {@link ComponentItemHandler}.
 */
public class ItemHandlerCopySlot extends StackCopySlot {
    private final SlotItemHandler slotItemHandler;

    public ItemHandlerCopySlot(IItemHandler itemHandler, int index, int xPosition, int yPosition) {
        super(xPosition, yPosition);
        slotItemHandler = new SlotItemHandler(itemHandler, index, xPosition, yPosition);
    }

    public ItemHandlerCopySlot(SlotItemHandler slotItemHandler) {
        super(slotItemHandler.x, slotItemHandler.y);
        this.slotItemHandler = slotItemHandler;
    }

    @Override
    public boolean canInsert(ItemStack stack) {
        return slotItemHandler.canInsert(stack);
    }

    @Override
    protected ItemStack getStackCopy() {
        return slotItemHandler.getStack();
    }

    @Override
    protected void setStackCopy(ItemStack stack) {
        ((IItemHandlerModifiable) slotItemHandler.getItemHandler()).setStackInSlot(slotItemHandler.id, stack);
    }

    @Override
    public void onQuickTransfer(ItemStack oldStackIn, ItemStack newStackIn) {
        slotItemHandler.onQuickTransfer(oldStackIn, newStackIn);
    }

    @Override
    public int getMaxItemCount() {
        return slotItemHandler.getMaxItemCount();
    }

    @Override
    public int getMaxItemCount(ItemStack stack) {
        return slotItemHandler.getMaxItemCount(stack);
    }

    @Override
    public boolean canTakeItems(PlayerEntity playerIn) {
        return slotItemHandler.canTakeItems(playerIn);
    }

    @Override
    public boolean isSameInventory(Slot other) {
        return slotItemHandler.isSameInventory(other);
    }

    public IItemHandler getItemHandler() {
        return slotItemHandler.getItemHandler();
    }
}
