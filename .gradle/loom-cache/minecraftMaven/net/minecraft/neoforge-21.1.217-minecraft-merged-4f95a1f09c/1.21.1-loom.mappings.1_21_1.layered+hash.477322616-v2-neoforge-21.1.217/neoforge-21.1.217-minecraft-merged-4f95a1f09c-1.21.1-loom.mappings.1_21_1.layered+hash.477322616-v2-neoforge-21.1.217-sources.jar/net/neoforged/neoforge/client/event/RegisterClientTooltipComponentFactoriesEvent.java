/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.item.tooltip.TooltipData;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.fml.event.IModBusEvent;
import org.jetbrains.annotations.ApiStatus;

/**
 * Allows users to register custom {@link net.minecraft.client.gui.tooltip.TooltipComponent}
 * factories for their {@link net.minecraft.item.tooltip.TooltipData} types.
 *
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.
 *
 * <p>This event is fired on the mod-specific event bus, only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 */
public class RegisterClientTooltipComponentFactoriesEvent extends Event implements IModBusEvent {
    private final Map<Class<? extends TooltipData>, Function<TooltipData, TooltipComponent>> factories;

    @ApiStatus.Internal
    public RegisterClientTooltipComponentFactoriesEvent(Map<Class<? extends TooltipData>, Function<TooltipData, TooltipComponent>> factories) {
        this.factories = factories;
    }

    /**
     * Registers a {@link TooltipComponent} factory for a {@link TooltipData}.
     */
    @SuppressWarnings("unchecked")
    public <T extends TooltipData> void register(Class<T> type, Function<? super T, ? extends TooltipComponent> factory) {
        factories.put(type, (Function<TooltipData, TooltipComponent>) factory);
    }
}
