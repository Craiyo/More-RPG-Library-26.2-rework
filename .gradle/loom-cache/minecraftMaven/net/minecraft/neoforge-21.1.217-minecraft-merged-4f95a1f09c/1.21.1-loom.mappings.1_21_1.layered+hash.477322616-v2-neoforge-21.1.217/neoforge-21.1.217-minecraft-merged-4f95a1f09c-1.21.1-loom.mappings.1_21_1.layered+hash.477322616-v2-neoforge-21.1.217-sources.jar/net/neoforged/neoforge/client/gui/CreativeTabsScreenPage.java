/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.item.ItemGroup;
import net.neoforged.neoforge.common.CreativeModeTabRegistry;
import net.neoforged.neoforge.common.util.ConcatenatedListView;

public final class CreativeTabsScreenPage {
    private final List<ItemGroup> tabs;
    private final List<ItemGroup> topTabs;
    private final List<ItemGroup> bottomTabs;
    private final List<ItemGroup> visibleTabs;

    public CreativeTabsScreenPage(List<ItemGroup> tabs) {
        this.tabs = tabs;
        this.topTabs = new ArrayList<>();
        this.bottomTabs = new ArrayList<>();
        this.visibleTabs = ConcatenatedListView.of(tabs, CreativeModeTabRegistry.getDefaultTabs());

        int maxLength = 10;
        int topLength = maxLength / 2;
        int length = tabs.size();

        for (int i = 0; i < length; i++) {
            ItemGroup tab = tabs.get(i);
            (i < topLength ? this.topTabs : this.bottomTabs).add(tab);
        }
    }

    public List<ItemGroup> getVisibleTabs() {
        return this.visibleTabs.stream().filter(ItemGroup::shouldDisplay).toList();
    }

    public boolean isTop(ItemGroup tab) {
        if (!this.tabs.contains(tab))
            return CreativeModeTabRegistry.getDefaultTabs().indexOf(tab) < (CreativeModeTabRegistry.getDefaultTabs().size() / 2);

        return this.topTabs.contains(tab);
    }

    public int getColumn(ItemGroup tab) {
//        if (!this.tabs.contains(tab)) {
//            return CreativeModeTabs.tabs().indexOf(tab) % 6;
//        }
//        return this.topTabs.contains(tab) ? this.topTabs.indexOf(tab) : this.bottomTabs.indexOf(tab);
        if (!this.tabs.contains(tab))
            return (CreativeModeTabRegistry.getDefaultTabs().indexOf(tab) % (CreativeModeTabRegistry.getDefaultTabs().size() / 2)) + 5;

        return this.topTabs.contains(tab) ? this.topTabs.indexOf(tab) : this.bottomTabs.indexOf(tab);
    }

    public ItemGroup getDefaultTab() {
        return this.tabs.get(0);
    }
}
