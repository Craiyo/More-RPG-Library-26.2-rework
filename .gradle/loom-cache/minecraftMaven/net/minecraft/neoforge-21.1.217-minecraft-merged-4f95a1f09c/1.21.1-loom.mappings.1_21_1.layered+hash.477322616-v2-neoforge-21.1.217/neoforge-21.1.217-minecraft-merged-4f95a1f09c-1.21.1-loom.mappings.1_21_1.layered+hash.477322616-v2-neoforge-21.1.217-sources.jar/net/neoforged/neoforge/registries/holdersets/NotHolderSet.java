/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries.holdersets;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.entry.RegistryEntryListCodec;
import net.minecraft.registry.entry.RegistryEntryOwner;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.math.random.Random;
import net.neoforged.neoforge.common.NeoForgeMod;
import org.jetbrains.annotations.Nullable;

/**
 * <p>Holderset that represents all elements of a registry not present in another holderset.
 * neoforge:exclusion is preferable when the number of allowed elements is small relative to the size of the registry.
 * Json format:</p>
 * 
 * <pre>
 * {
 *   "type": "neoforge:not",
 *   "value": "not_this_holderset" // string, list, or object
 * }
 * </pre>
 */
// this doesn't extend CompositeHolderSet because it doesn't need to cache a set
public class NotHolderSet<T> implements ICustomHolderSet<T> {
    private final List<Runnable> owners = new ArrayList<>();
    private final RegistryWrapper.Impl<T> registryLookup;
    private final RegistryEntryList<T> value;
    @Nullable
    private List<RegistryEntry<T>> list = null;

    public RegistryWrapper.Impl<T> registryLookup() {
        return this.registryLookup;
    }

    public RegistryEntryList<T> value() {
        return this.value;
    }

    public NotHolderSet(RegistryWrapper.Impl<T> registryLookup, RegistryEntryList<T> value) {
        this.registryLookup = registryLookup;
        this.value = value;
        this.value.addInvalidationListener(this::invalidate);
    }

    @Override
    public HolderSetType type() {
        return NeoForgeMod.NOT_HOLDER_SET.value();
    }

    @Override
    public void addInvalidationListener(Runnable runnable) {
        this.owners.add(runnable);
    }

    @Override
    public Iterator<RegistryEntry<T>> iterator() {
        return this.getList().iterator();
    }

    @Override
    public Stream<RegistryEntry<T>> stream() {
        return this.getList().stream();
    }

    @Override
    public int size() {
        return this.getList().size();
    }

    @Override
    public Either<TagKey<T>, List<RegistryEntry<T>>> getStorage() {
        return Either.right(this.getList());
    }

    @Override
    public Optional<RegistryEntry<T>> getRandom(Random random) {
        List<RegistryEntry<T>> list = this.getList();
        int size = list.size();
        return size > 0
                ? Optional.of(list.get(random.nextInt(size)))
                : Optional.empty();
    }

    @Override
    public RegistryEntry<T> get(int i) {
        return this.getList().get(i);
    }

    @Override
    public boolean contains(RegistryEntry<T> holder) {
        return !this.value.contains(holder);
    }

    @Override
    public boolean ownerEquals(RegistryEntryOwner<T> holderOwner) {
        return this.value.ownerEquals(holderOwner);
    }

    @Override
    public Optional<TagKey<T>> getTagKey() {
        return Optional.empty();
    }

    @Override
    public String toString() {
        return "NotSet(" + this.value + ")";
    }

    private List<RegistryEntry<T>> getList() {
        List<RegistryEntry<T>> thisList = this.list;
        if (thisList == null) {
            List<RegistryEntry<T>> list = this.registryLookup.streamEntries()
                    .filter(holder -> !this.value.contains(holder))
                    .map(holder -> (RegistryEntry<T>) holder)
                    .toList();
            this.list = list;
            return list;
        } else {
            return thisList;
        }
    }

    private void invalidate() {
        this.list = null;
        for (Runnable runnable : this.owners) {
            runnable.run();
        }
    }

    public static class Type implements HolderSetType {
        @Override
        public <T> MapCodec<? extends ICustomHolderSet<T>> makeCodec(RegistryKey<? extends Registry<T>> registryKey, Codec<RegistryEntry<T>> holderCodec, boolean forceList) {
            return RecordCodecBuilder.<NotHolderSet<T>>mapCodec(
                    builder -> builder
                            .group(
                                    RegistryOps.retrieveRegistryLookup(registryKey).forGetter(NotHolderSet::registryLookup),
                                    RegistryEntryListCodec.create(registryKey, holderCodec, forceList).fieldOf("value").forGetter(NotHolderSet::value))
                            .apply(builder, NotHolderSet::new));
        }

        @Override
        public <T> PacketCodec<RegistryByteBuf, ? extends ICustomHolderSet<T>> makeStreamCodec(RegistryKey<? extends Registry<T>> registryKey) {
            return new PacketCodec<RegistryByteBuf, NotHolderSet<T>>() {
                private final PacketCodec<RegistryByteBuf, RegistryEntryList<T>> holderSetCodec = PacketCodecs.registryEntryList(registryKey);

                @Override
                public NotHolderSet<T> decode(RegistryByteBuf buf) {
                    return new NotHolderSet<>(buf.getRegistryManager().getWrapperOrThrow(registryKey), holderSetCodec.decode(buf));
                }

                @Override
                public void encode(RegistryByteBuf buf, NotHolderSet<T> holderSet) {
                    holderSetCodec.encode(buf, holderSet.value);
                }
            };
        }
    }
}
