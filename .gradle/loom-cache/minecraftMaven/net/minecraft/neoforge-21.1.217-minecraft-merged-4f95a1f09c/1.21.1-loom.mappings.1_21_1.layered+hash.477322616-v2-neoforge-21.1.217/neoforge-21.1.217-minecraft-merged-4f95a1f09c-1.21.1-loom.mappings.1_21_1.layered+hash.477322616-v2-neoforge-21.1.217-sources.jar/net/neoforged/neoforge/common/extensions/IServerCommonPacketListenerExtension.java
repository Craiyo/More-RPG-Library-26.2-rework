/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.listener.ServerCommonPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import org.jetbrains.annotations.Nullable;

/**
 * Extension interface for {@link ServerCommonPacketListener}
 */
public interface IServerCommonPacketListenerExtension extends ICommonPacketListener {
    /**
     * {@inheritDoc}
     */
    @Override
    default void send(CustomPayload payload) {
        this.send(new CustomPayloadS2CPacket(payload));
    }

    /**
     * Sends a packet to the client of this listener.
     *
     * @param listener An optional callback for when the payload is sent
     */
    void send(Packet<?> packet, @Nullable PacketCallbacks listener);

    /**
     * Sends a payload to the client of this listener.
     *
     * @param listener An optional callback for when the payload is sent
     */
    default void send(CustomPayload payload, @Nullable PacketCallbacks listener) {
        this.send(new CustomPayloadS2CPacket(payload), listener);
    }
}
