/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.world.GameMode;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.ApiStatus;

/**
 * Fired when the client player is notified of a change of {@link GameMode} from the server.
 *
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
 *
 * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 */
public class ClientPlayerChangeGameTypeEvent extends Event {
    private final PlayerListEntry info;
    private final GameMode currentGameType;
    private final GameMode newGameType;

    @ApiStatus.Internal
    public ClientPlayerChangeGameTypeEvent(PlayerListEntry info, GameMode currentGameType, GameMode newGameType) {
        this.info = info;
        this.currentGameType = currentGameType;
        this.newGameType = newGameType;
    }

    /**
     * {@return the client player information}
     */
    public PlayerListEntry getInfo() {
        return info;
    }

    /**
     * {@return the current game type of the player}
     */
    public GameMode getCurrentGameType() {
        return currentGameType;
    }

    /**
     * {@return the new game type of the player}
     */
    public GameMode getNewGameType() {
        return newGameType;
    }
}
