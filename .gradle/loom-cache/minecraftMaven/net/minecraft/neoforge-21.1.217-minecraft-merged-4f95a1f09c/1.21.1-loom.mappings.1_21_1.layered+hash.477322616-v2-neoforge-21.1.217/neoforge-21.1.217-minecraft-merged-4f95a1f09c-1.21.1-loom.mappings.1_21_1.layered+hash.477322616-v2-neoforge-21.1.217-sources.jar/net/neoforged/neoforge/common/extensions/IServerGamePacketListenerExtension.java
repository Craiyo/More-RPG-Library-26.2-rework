/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.listener.ServerPlayPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.network.packet.s2c.play.BundleS2CPacket;

/**
 * Extension class for {@link ServerPlayPacketListener}
 */
public interface IServerGamePacketListenerExtension extends IServerCommonPacketListenerExtension {
    /**
     * {@return the listener this extension is attached to}
     */
    private ServerPlayPacketListener self() {
        return (ServerPlayPacketListener) this;
    }

    /**
     * Sends all given payloads as a bundle to the client.
     *
     * @param payloads the payloads to send
     */
    default void sendBundled(CustomPayload... payloads) {
        this.sendBundled(List.of(payloads));
    }

    /**
     * Sends all given payloads as a bundle to the client.
     *
     * @param payloads the payloads to send
     */
    default void sendBundled(Iterable<CustomPayload> payloads) {
        final List<Packet<? super ClientPlayPacketListener>> packets = new ArrayList<>();
        for (CustomPayload payload : payloads) {
            packets.add(new CustomPayloadS2CPacket(payload));
        }

        self().send(new BundleS2CPacket(packets));
    }
}
