/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.living;

import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.SpawnHelper;

/**
 * This event is fired from {@link SpawnHelper#spawnEntitiesInChunk} when the spawning
 * system determines the maximum amount of the selected entity that can spawn at the same time.
 */
public class SpawnClusterSizeEvent extends LivingEvent {
    private int size;

    public SpawnClusterSizeEvent(MobEntity entity) {
        super(entity);
        this.size = entity.getLimitPerChunk();
    }

    /**
     * Gets the possibly event-modified max spawn cluster size for the entity.
     * <p>
     * To see the default size, use {@link MobEntity#getLimitPerChunk()}
     * 
     * @return The max spawn cluster size
     */
    public int getSize() {
        return size;
    }

    /**
     * Changes the max cluster size for the entity.
     * 
     * @param size The new size
     */
    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public MobEntity getEntity() {
        return (MobEntity) super.getEntity();
    }
}
