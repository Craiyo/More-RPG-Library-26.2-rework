/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.world.GameRules;
import net.minecraft.world.GameRules.BooleanRule;

class TimeSpeedCommand {
    static ArgumentBuilder<ServerCommandSource, ?> register() {
        return CommandManager.literal("day")
                .then(CommandManager.literal("speed")
                        .then(CommandManager.literal("set").requires(cs -> cs.hasPermissionLevel(CommandManager.field_31839)) // same as /gamerule
                                .then(CommandManager.literal("default").executes(context -> setDefault(context.getSource())))
                                .then(CommandManager.literal("realtime").executes(context -> setDaylength(context.getSource(), 1440)))
                                .then(CommandManager.argument("speed", FloatArgumentType.floatArg(0f, 1000f)).executes(context -> setSpeed(context.getSource(), FloatArgumentType.getFloat(context, "speed")))))
                        .executes(context -> query(context.getSource())))
                .then(CommandManager.literal("length")
                        .then(CommandManager.literal("set").requires(cs -> cs.hasPermissionLevel(CommandManager.field_31839))
                                .then(CommandManager.literal("default").executes(context -> setDefault(context.getSource())))
                                .then(CommandManager.literal("realtime").executes(context -> setDaylength(context.getSource(), 1440)))
                                .then(CommandManager.argument("minutes", IntegerArgumentType.integer(1, 1440)).executes(context -> setDaylength(context.getSource(), IntegerArgumentType.getInteger(context, "minutes")))))
                        .executes(context -> query(context.getSource())))
                .executes(context -> query(context.getSource()));
    }

    private static int query(ServerCommandSource source) {
        final float speed = source.getWorld().getDayTimePerTick();
        if (speed < 0) {
            source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.timespeed.query.default", levelName(source)), true);
        } else {
            source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.timespeed.query", levelName(source), speed, minutes(speed)), true);
        }
        return Command.SINGLE_SUCCESS;
    }

    private static Text levelName(ServerCommandSource source) {
        return source.getWorld().getDescription();
    }

    private static float minutes(final float speed) {
        return (int) (200f / speed) / 10f;
    }

    private static int setSpeed(ServerCommandSource source, float speed) {
        final BooleanRule rule = source.getWorld().getGameRules().get(GameRules.DO_DAYLIGHT_CYCLE);
        if (!rule.get() && speed > 0) {
            rule.set(true, null);
            source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.gamerule.set", GameRules.DO_DAYLIGHT_CYCLE.getName(), rule.toString()), true);
        } else if (rule.get() && speed == 0) {
            rule.set(false, null);
            source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.gamerule.set", GameRules.DO_DAYLIGHT_CYCLE.getName(), rule.toString()), true);
            return Command.SINGLE_SUCCESS;
        }
        source.getWorld().setDayTimePerTick(speed);
        source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.timespeed.set", levelName(source), speed, minutes(speed)), true);
        return Command.SINGLE_SUCCESS;
    }

    private static int setDaylength(ServerCommandSource source, int minutes) {
        if (minutes == 20) {
            return setDefault(source);
        }
        return setSpeed(source, 20f / minutes);
    }

    private static int setDefault(ServerCommandSource source) {
        source.getWorld().setDayTimePerTick(-1f);
        source.sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.timespeed.set.default", levelName(source)), true);
        return Command.SINGLE_SUCCESS;
    }
}
