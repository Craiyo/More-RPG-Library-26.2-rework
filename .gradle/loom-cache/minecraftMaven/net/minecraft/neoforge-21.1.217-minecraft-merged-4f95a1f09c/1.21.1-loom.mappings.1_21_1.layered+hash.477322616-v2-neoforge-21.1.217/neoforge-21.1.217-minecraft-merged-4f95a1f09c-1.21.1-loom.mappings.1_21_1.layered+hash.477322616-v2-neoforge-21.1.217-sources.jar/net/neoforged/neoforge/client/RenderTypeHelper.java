/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;
import net.neoforged.neoforge.client.model.data.ModelData;

/**
 * Provides helper functions replacing those in {@link RenderLayers}.
 */
public final class RenderTypeHelper {
    /**
     * Provides a {@link RenderLayer} using {@link VertexFormats#POSITION_COLOR_TEXTURE_OVERLAY_LIGHT_NORMAL} for the given {@link VertexFormats#POSITION_COLOR_TEXTURE_LIGHT_NORMAL} format.
     * This should be called for each {@link RenderLayer} returned by {@link BakedModel#getRenderTypes(BlockState, Random, ModelData)}.
     * <p>
     * Mimics the behavior of vanilla's {@link RenderLayers#getEntityBlockLayer(BlockState, boolean)}.
     */
    public static RenderLayer getEntityRenderType(RenderLayer chunkRenderType, boolean cull) {
        if (chunkRenderType != RenderLayer.getTranslucent())
            return TexturedRenderLayers.getEntityCutout();
        return cull || !MinecraftClient.isFabulousGraphicsOrBetter() ? TexturedRenderLayers.getEntityTranslucentCull() : TexturedRenderLayers.getItemEntityTranslucentCull();
    }

    /**
     * Provides a {@link RenderLayer} fit for rendering moving blocks given the specified chunk render type.
     * This should be called for each {@link RenderLayer} returned by {@link BakedModel#getRenderTypes(BlockState, Random, ModelData)}.
     * <p>
     * Mimics the behavior of vanilla's {@link RenderLayers#getMovingBlockLayer(BlockState)}.
     */
    public static RenderLayer getMovingBlockRenderType(RenderLayer renderType) {
        if (renderType == RenderLayer.getTranslucent())
            return RenderLayer.getTranslucentMovingBlock();
        return renderType;
    }

    /**
     * Provides a fallback {@link RenderLayer} for the given {@link ItemStack} in the case that none is explicitly specified.
     * <p>
     * Mimics the behavior of vanilla's {@link RenderLayers#getItemLayer(ItemStack, boolean)}
     * but removes the need to query the model again if the item is a {@link BlockItem}.
     */
    public static RenderLayer getFallbackItemRenderType(ItemStack stack, BakedModel model, boolean cull) {
        if (stack.getItem() instanceof BlockItem blockItem) {
            var renderTypes = model.getRenderTypes(blockItem.getBlock().getDefaultState(), Random.create(42), ModelData.EMPTY);
            if (renderTypes.contains(RenderLayer.getTranslucent()))
                return getEntityRenderType(RenderLayer.getTranslucent(), cull);
            return TexturedRenderLayers.getEntityCutout();
        }
        return cull ? TexturedRenderLayers.getEntityTranslucentCull() : TexturedRenderLayers.getItemEntityTranslucentCull();
    }

    private RenderTypeHelper() {}
}
