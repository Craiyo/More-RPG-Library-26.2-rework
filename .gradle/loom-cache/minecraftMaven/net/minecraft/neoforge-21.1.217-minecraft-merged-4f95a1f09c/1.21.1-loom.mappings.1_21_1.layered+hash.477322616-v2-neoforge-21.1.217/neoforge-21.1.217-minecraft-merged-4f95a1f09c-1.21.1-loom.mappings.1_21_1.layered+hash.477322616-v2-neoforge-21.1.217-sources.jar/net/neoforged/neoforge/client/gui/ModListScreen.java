/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.LogoDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.resource.ResourcePackSource;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import net.minecraft.util.Util;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.VersionChecker;
import net.neoforged.fml.i18n.FMLTranslations;
import net.neoforged.fml.i18n.MavenVersionTranslator;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.loading.StringUtils;
import net.neoforged.neoforge.client.gui.widget.ModListWidget;
import net.neoforged.neoforge.client.gui.widget.ScrollPanel;
import net.neoforged.neoforge.common.CommonHooks;
import net.neoforged.neoforge.common.util.Size2i;
import net.neoforged.neoforge.resource.ResourcePackLoader;
import net.neoforged.neoforgespi.language.IModInfo;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.maven.artifact.versioning.ComparableVersion;

public class ModListScreen extends Screen {
    private static String stripControlCodes(String value) {
        return net.minecraft.util.StringHelper.stripTextFormat(value);
    }

    private static final Logger LOGGER = LogManager.getLogger();

    private enum SortType implements Comparator<ModContainer> {
        NORMAL,
        A_TO_Z {
            @Override
            protected int compare(String name1, String name2) {
                return name1.compareTo(name2);
            }
        },
        Z_TO_A {
            @Override
            protected int compare(String name1, String name2) {
                return name2.compareTo(name1);
            }
        };

        ButtonWidget button;

        protected int compare(String name1, String name2) {
            return 0;
        }

        @Override
        public int compare(ModContainer o1, ModContainer o2) {
            String name1 = StringUtils.toLowerCase(stripControlCodes(o1.getModInfo().getDisplayName()));
            String name2 = StringUtils.toLowerCase(stripControlCodes(o2.getModInfo().getDisplayName()));
            return compare(name1, name2);
        }

        Text getButtonText() {
            return Text.translatable("fml.menu.mods." + StringUtils.toLowerCase(name()));
        }
    }

    private static final int PADDING = 6;

    private Screen parentScreen;

    private ModListWidget modList;
    private InfoPanel modInfo;
    private ModListWidget.ModEntry selected = null;
    private int listWidth;
    private List<ModContainer> mods;
    private final List<ModContainer> unsortedMods;
    private ButtonWidget configButton, openModsFolderButton, doneButton;

    private int buttonMargin = 1;
    private int numButtons = SortType.values().length;
    private String lastFilterText = "";

    private TextFieldWidget search;

    private boolean sorted = false;
    private SortType sortType = SortType.NORMAL;

    public ModListScreen(Screen parentScreen) {
        super(Text.translatable("fml.menu.mods.title"));
        this.parentScreen = parentScreen;
        this.mods = Collections.unmodifiableList(ModList.get().getSortedMods());
        this.unsortedMods = Collections.unmodifiableList(this.mods);
    }

    class InfoPanel extends ScrollPanel {
        private Identifier logoPath;
        private Size2i logoDims = new Size2i(0, 0);
        private List<OrderedText> lines = Collections.emptyList();

        InfoPanel(MinecraftClient mcIn, int widthIn, int heightIn, int topIn) {
            super(mcIn, widthIn, heightIn, topIn, modList.getRight() + PADDING);
        }

        void setInfo(List<String> lines, Identifier logoPath, Size2i logoDims) {
            this.logoPath = logoPath;
            this.logoDims = logoDims;
            this.lines = resizeContent(lines);
        }

        void clearInfo() {
            this.logoPath = null;
            this.logoDims = new Size2i(0, 0);
            this.lines = Collections.emptyList();
        }

        private List<OrderedText> resizeContent(List<String> lines) {
            List<OrderedText> ret = new ArrayList<>();
            for (String line : lines) {
                if (line == null) {
                    ret.add(null);
                    continue;
                }

                Text chat = CommonHooks.newChatWithLinks(line, false);
                int maxTextLength = this.width - 12;
                if (maxTextLength >= 0) {
                    ret.addAll(Language.getInstance().reorder(textRenderer.getTextHandler().wrapLines(chat, maxTextLength, Style.EMPTY)));
                }
            }
            return ret;
        }

        @Override
        public int getContentHeight() {
            int height = 50;
            height += (lines.size() * textRenderer.fontHeight);
            if (height < this.bottom - this.top - 8)
                height = this.bottom - this.top - 8;
            return height;
        }

        @Override
        protected int getScrollAmount() {
            return textRenderer.fontHeight * 3;
        }

        @Override
        protected void drawPanel(DrawContext guiGraphics, int entryRight, int relativeY, Tessellator tess, int mouseX, int mouseY) {
            if (logoPath != null) {
                RenderSystem.enableBlend();
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
                // Draw the logo image inscribed in a rectangle with width entryWidth (minus some padding) and height 50
                int headerHeight = 50;
                guiGraphics.blitInscribed(logoPath, left + PADDING, relativeY, width - (PADDING * 2), headerHeight, logoDims.width, logoDims.height, false, true);
                relativeY += headerHeight + PADDING;
            }

            for (OrderedText line : lines) {
                if (line != null) {
                    RenderSystem.enableBlend();
                    guiGraphics.drawTextWithShadow(ModListScreen.this.textRenderer, line, left + PADDING, relativeY, 0xFFFFFF);
                    RenderSystem.disableBlend();
                }
                relativeY += textRenderer.fontHeight;
            }

            final Style component = findTextLine(mouseX, mouseY);
            if (component != null) {
                guiGraphics.drawHoverEvent(ModListScreen.this.textRenderer, component, mouseX, mouseY);
            }
        }

        private Style findTextLine(final int mouseX, final int mouseY) {
            if (!isMouseOver(mouseX, mouseY))
                return null;

            double offset = (mouseY - top - PADDING - border) + scrollDistance;
            if (logoPath != null) {
                offset -= 50;
            }
            if (offset <= 0)
                return null;

            int lineIdx = (int) (offset / textRenderer.fontHeight);
            if (lineIdx >= lines.size() || lineIdx < 0)
                return null;

            OrderedText line = lines.get(lineIdx);
            if (line != null) {
                return textRenderer.getTextHandler().getStyleAt(line, mouseX - left - border - 1);
            }
            return null;
        }

        @Override
        public boolean mouseClicked(final double mouseX, final double mouseY, final int button) {
            final Style component = findTextLine((int) mouseX, (int) mouseY);
            if (component != null) {
                ModListScreen.this.handleTextClick(component);
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }

        @Override
        public SelectionType getType() {
            return SelectionType.NONE;
        }

        @Override
        public void appendNarrations(NarrationMessageBuilder p_169152_) {}
    }

    @Override
    public void init() {
        for (var mod : mods) {
            listWidth = Math.max(listWidth, getFontRenderer().getWidth(mod.getModInfo().getDisplayName()) + 10);
            listWidth = Math.max(listWidth, getFontRenderer().getWidth(MavenVersionTranslator.artifactVersionToString(mod.getModInfo().getVersion())) + 5);
        }
        listWidth = Math.max(Math.min(listWidth, width / 3), 100);
        listWidth += listWidth % numButtons != 0 ? (numButtons - listWidth % numButtons) : 0;

        int modInfoWidth = this.width - this.listWidth - (PADDING * 3);
        int doneButtonWidth = Math.min(modInfoWidth, 200);
        int y = this.height - 20 - PADDING;
        int fullButtonHeight = PADDING + 20 + PADDING;

        doneButton = ButtonWidget.builder(Text.translatable("gui.done"), b -> ModListScreen.this.close()).dimensions(((listWidth + PADDING + this.width - doneButtonWidth) / 2), y, doneButtonWidth, 20).build();
        openModsFolderButton = ButtonWidget.builder(Text.translatable("fml.menu.mods.openmodsfolder"), b -> Util.getOperatingSystem().open(FMLPaths.MODSDIR.get().toFile())).dimensions(6, y, this.listWidth, 20).build();
        y -= 20 + PADDING;
        configButton = ButtonWidget.builder(Text.translatable("fml.menu.mods.config"), b -> ModListScreen.this.displayModConfig()).dimensions(6, y, this.listWidth, 20).build();
        y -= 14 + PADDING;
        search = new TextFieldWidget(getFontRenderer(), PADDING, y, listWidth, 14, Text.translatable("fml.menu.mods.search"));

        this.modList = new ModListWidget(this, listWidth, fullButtonHeight, search.getY() - getFontRenderer().fontHeight - PADDING);
        this.modList.setX(6);
        this.modInfo = new InfoPanel(this.client, modInfoWidth, this.height - PADDING - fullButtonHeight, PADDING);

        this.addDrawableChild(modList);
        this.addDrawableChild(modInfo);
        this.addDrawableChild(search);
        this.addDrawableChild(doneButton);
        this.addDrawableChild(configButton);
        this.addDrawableChild(openModsFolderButton);

        search.setFocused(false);
        search.setFocusUnlocked(true);
        configButton.active = false;

        final int width = listWidth / numButtons;
        int x = PADDING;
        addDrawableChild(SortType.NORMAL.button = ButtonWidget.builder(SortType.NORMAL.getButtonText(), b -> resortMods(SortType.NORMAL)).dimensions(x, PADDING, width - buttonMargin, 20).build());
        x += width + buttonMargin;
        addDrawableChild(SortType.A_TO_Z.button = ButtonWidget.builder(SortType.A_TO_Z.getButtonText(), b -> resortMods(SortType.A_TO_Z)).dimensions(x, PADDING, width - buttonMargin, 20).build());
        x += width + buttonMargin;
        addDrawableChild(SortType.Z_TO_A.button = ButtonWidget.builder(SortType.Z_TO_A.getButtonText(), b -> resortMods(SortType.Z_TO_A)).dimensions(x, PADDING, width - buttonMargin, 20).build());
        resortMods(SortType.NORMAL);
        updateCache();
    }

    private void displayModConfig() {
        if (selected == null) return;
        try {
            IConfigScreenFactory.getForMod(selected.getInfo()).map(f -> f.createScreen(selected.getContainer(), this)).ifPresent(newScreen -> this.client.setScreen(newScreen));
        } catch (final Exception e) {
            LOGGER.error("There was a critical issue trying to build the config GUI for {}", selected.getInfo().getModId(), e);
        }
    }

    @Override
    public void tick() {
        modList.setSelected(selected);

        if (!search.getText().equals(lastFilterText)) {
            reloadMods();
            sorted = false;
        }

        if (!sorted) {
            reloadMods();
            mods.sort(sortType);
            modList.refreshList();
            if (selected != null) {
                selected = modList.children().stream().filter(e -> e.getInfo() == selected.getInfo()).findFirst().orElse(null);
                updateCache();
            }
            sorted = true;
        }
    }

    public <T extends AlwaysSelectedEntryListWidget.Entry<T>> void buildModList(Consumer<T> modListViewConsumer, Function<ModContainer, T> newEntry) {
        mods.forEach(mod -> modListViewConsumer.accept(newEntry.apply(mod)));
    }

    private void reloadMods() {
        this.mods = this.unsortedMods.stream().filter(mi -> StringUtils.toLowerCase(stripControlCodes(mi.getModInfo().getDisplayName())).contains(StringUtils.toLowerCase(search.getText()))).collect(Collectors.toList());
        lastFilterText = search.getText();
    }

    private void resortMods(SortType newSort) {
        this.sortType = newSort;

        for (SortType sort : SortType.values()) {
            if (sort.button != null)
                sort.button.active = sortType != sort;
        }
        sorted = false;
    }

    @Override
    public void render(DrawContext guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.render(guiGraphics, mouseX, mouseY, partialTick);
        Text text = Text.translatable("fml.menu.mods.search");
        int x = modList.getX() + ((modList.getRight() - modList.getX()) / 2) - (getFontRenderer().getWidth(text) / 2);
        guiGraphics.drawText(getFontRenderer(), text.asOrderedText(), x, search.getY() - getFontRenderer().fontHeight, 0xFFFFFF, false);
    }

    public MinecraftClient getMinecraftInstance() {
        return client;
    }

    public TextRenderer getFontRenderer() {
        return textRenderer;
    }

    public void setSelected(ModListWidget.ModEntry entry) {
        this.selected = entry;
        updateCache();
    }

    private void updateCache() {
        if (selected == null) {
            this.configButton.active = false;
            this.modInfo.clearInfo();
            return;
        }
        IModInfo selectedMod = selected.getInfo();
        this.configButton.active = IConfigScreenFactory.getForMod(selectedMod).isPresent();
        List<String> lines = new ArrayList<>();
        VersionChecker.CheckResult vercheck = VersionChecker.getResult(selectedMod);

        @SuppressWarnings("resource")
        Pair<Identifier, Size2i> logoData;

        if (selectedMod.getModId().equals(Identifier.DEFAULT_NAMESPACE)) {
            logoData = Pair.of(LogoDrawer.LOGO_TEXTURE, new Size2i(LogoDrawer.LOGO_TEXTURE_WIDTH, LogoDrawer.LOGO_TEXTURE_HEIGHT));
        } else {
            logoData = selectedMod.getLogoFile().map(logoFile -> {
                TextureManager tm = this.client.getTextureManager();
                final ResourcePackProfile.PackFactory resourcePack = ResourcePackLoader.getPackFor(selectedMod.getModId())
                        .orElse(ResourcePackLoader.getPackFor("neoforge").orElseThrow(() -> new RuntimeException("Can't find neoforge, WHAT!")));
                try (ResourcePack packResources = resourcePack.open(new ResourcePackInfo("mod/" + selectedMod.getModId(), Text.empty(), ResourcePackSource.BUILTIN, Optional.empty()))) {
                    NativeImage logo = null;
                    InputSupplier<InputStream> logoResource = packResources.openRoot(logoFile.split("[/\\\\]"));
                    if (logoResource != null)
                        logo = NativeImage.read(logoResource.get());
                    if (logo != null) {

                        return Pair.of(tm.registerDynamicTexture("modlogo", new NativeImageBackedTexture(logo) {
                            @Override
                            public void upload() {
                                this.bindTexture();
                                NativeImage td = this.getImage();
                                // Use custom "blur" value which controls texture filtering (nearest-neighbor vs linear)
                                this.getImage().upload(0, 0, 0, 0, 0, td.getWidth(), td.getHeight(), selectedMod.getLogoBlur(), false, false, false);
                            }
                        }), new Size2i(logo.getWidth(), logo.getHeight()));
                    }
                } catch (IOException | IllegalArgumentException e) {}
                return Pair.<Identifier, Size2i>of(null, new Size2i(0, 0));
            }).orElse(Pair.of(null, new Size2i(0, 0)));
        }

        lines.add(selectedMod.getDisplayName());
        lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.version", MavenVersionTranslator.artifactVersionToString(selectedMod.getVersion())));
        lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.idstate", selectedMod.getModId(), "LOADED")); // TODO: remove mod loading stages from here too

        // Normalizing line endings to LF because it is currently not automatically handled for us. Descriptions are already normalized.
        selectedMod.getConfig().getConfigElement("credits").ifPresent(credits -> lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.credits", credits).replace("\r\n", "\n")));
        selectedMod.getConfig().getConfigElement("authors").ifPresent(authors -> lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.authors", authors).replace("\r\n", "\n")));
        selectedMod.getConfig().getConfigElement("displayURL").ifPresent(displayURL -> lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.displayurl", displayURL).replace("\r\n", "\n")));
        if (selectedMod.getOwningFile() == null || selectedMod.getOwningFile().getMods().size() == 1)
            lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.nochildmods"));
        else
            lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.childmods", selectedMod.getOwningFile().getMods().stream().map(IModInfo::getDisplayName).collect(Collectors.joining(","))));

        if (vercheck.status() == VersionChecker.Status.OUTDATED || vercheck.status() == VersionChecker.Status.BETA_OUTDATED)
            lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.updateavailable", vercheck.url() == null ? "" : vercheck.url()).replace("\r\n", "\n"));
        lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.license", selectedMod.getOwningFile().getLicense()).replace("\r\n", "\n"));
        lines.add(null);
        lines.add(FMLTranslations.getPattern("fml.menu.mods.info.description." + selectedMod.getModId(), selectedMod::getDescription));

        /* Removed because people bitched that this information was misleading.
        lines.add(null);
        if (FMLEnvironment.secureJarsEnabled) {
            lines.add(ForgeI18getOwningFile().getFile().n.parseMessage("fml.menu.mods.info.signature", selectedMod.getOwningFile().getCodeSigningFingerprint().orElse(ForgeI18n.parseMessage("fml.menu.mods.info.signature.unsigned"))));
            lines.add(ForgeI18n.parseMessage("fml.menu.mods.info.trust", selectedMod.getOwningFile().getTrustData().orElse(ForgeI18n.parseMessage("fml.menu.mods.info.trust.noauthority"))));
        } else {
            lines.add(ForgeI18n.parseMessage("fml.menu.mods.info.securejardisabled"));
        }
        */

        if ((vercheck.status() == VersionChecker.Status.OUTDATED || vercheck.status() == VersionChecker.Status.BETA_OUTDATED) && vercheck.changes().size() > 0) {
            lines.add(null);
            lines.add(FMLTranslations.parseMessage("fml.menu.mods.info.changelogheader"));
            for (Entry<ComparableVersion, String> entry : vercheck.changes().entrySet()) {
                lines.add("  " + entry.getKey() + ":");
                lines.add(entry.getValue());
                lines.add(null);
            }
        }

        modInfo.setInfo(lines, logoData.getLeft(), logoData.getRight());
    }

    @Override
    public void resize(MinecraftClient mc, int width, int height) {
        String s = this.search.getText();
        SortType sort = this.sortType;
        ModListWidget.ModEntry selected = this.selected;
        this.init(mc, width, height);
        this.search.setText(s);
        this.selected = selected;
        if (!this.search.getText().isEmpty())
            reloadMods();
        if (sort != SortType.NORMAL)
            resortMods(sort);
        updateCache();
    }

    @Override
    public void close() {
        this.client.setScreen(this.parentScreen);
    }
}
