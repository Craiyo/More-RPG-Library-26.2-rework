/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.world;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.world.biome.SpawnSettings;
import org.jetbrains.annotations.Nullable;

public class MobSpawnSettingsBuilder extends SpawnSettings.Builder {
    private final Set<SpawnGroup> typesView = Collections.unmodifiableSet(this.spawners.keySet());
    private final Set<EntityType<?>> costView = Collections.unmodifiableSet(this.spawnCosts.keySet());

    public MobSpawnSettingsBuilder(SpawnSettings orig) {
        orig.getSpawnerTypes().forEach(k -> {
            spawners.get(k).clear();
            spawners.get(k).addAll(orig.getSpawnEntries(k).getEntries());
        });
        orig.getEntityTypes().forEach(k -> spawnCosts.put(k, orig.getSpawnDensity(k)));
        creatureSpawnProbability = orig.getCreatureSpawnProbability();
    }

    public Set<SpawnGroup> getSpawnerTypes() {
        return this.typesView;
    }

    public List<SpawnSettings.SpawnEntry> getSpawner(SpawnGroup type) {
        return this.spawners.get(type);
    }

    public Set<EntityType<?>> getEntityTypes() {
        return this.costView;
    }

    @Nullable
    public SpawnSettings.SpawnDensity getCost(EntityType<?> type) {
        return this.spawnCosts.get(type);
    }

    public float getProbability() {
        return this.creatureSpawnProbability;
    }

    public MobSpawnSettingsBuilder disablePlayerSpawn() {
        return this;
    }

    public MobSpawnSettingsBuilder removeSpawnCost(EntityType<?>... entityTypes) {
        for (EntityType<?> entityType : entityTypes) {
            this.spawnCosts.remove(entityType);
        }
        return this;
    }
}
