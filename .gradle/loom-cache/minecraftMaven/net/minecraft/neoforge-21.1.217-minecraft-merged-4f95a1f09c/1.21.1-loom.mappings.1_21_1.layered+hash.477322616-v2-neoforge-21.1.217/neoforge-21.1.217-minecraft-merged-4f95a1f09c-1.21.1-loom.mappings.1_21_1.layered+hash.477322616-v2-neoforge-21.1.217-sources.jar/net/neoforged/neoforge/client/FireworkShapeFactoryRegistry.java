/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.particle.FireworksSparkParticle;
import net.minecraft.component.type.FireworkExplosionComponent;
import org.jetbrains.annotations.Nullable;

/**
 * Keeps track of custom firework shape types, because Particle is client side only this can't be on the Shape itself.
 * So sometime during your client initalization call register.
 */
public class FireworkShapeFactoryRegistry {
    private static final Map<FireworkExplosionComponent.Type, Factory> factories = new HashMap<>();

    public interface Factory {
        void build(FireworksSparkParticle.FireworkParticle starter, boolean trail, boolean flicker, int[] colors, int[] fadeColors);
    }

    public static void register(FireworkExplosionComponent.Type shape, Factory factory) {
        factories.put(shape, factory);
    }

    @Nullable
    public static Factory get(FireworkExplosionComponent.Type shape) {
        return factories.get(shape);
    }
}
