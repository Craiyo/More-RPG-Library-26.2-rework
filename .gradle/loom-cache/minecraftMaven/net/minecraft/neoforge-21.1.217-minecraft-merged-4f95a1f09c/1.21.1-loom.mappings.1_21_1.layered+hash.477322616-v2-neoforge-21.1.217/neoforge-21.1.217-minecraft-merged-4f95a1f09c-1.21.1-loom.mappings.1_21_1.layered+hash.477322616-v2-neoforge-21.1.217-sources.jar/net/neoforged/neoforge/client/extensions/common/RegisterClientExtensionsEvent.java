/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.extensions.common;

import java.util.Arrays;
import net.minecraft.block.Block;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.Item;
import net.minecraft.registry.entry.RegistryEntry;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.fml.event.IModBusEvent;
import net.neoforged.neoforge.fluids.FluidType;

/**
 * Allows registering client extensions for various game objects.
 *
 * <p>
 * This event is not {@linkplain ICancellableEvent cancellable}.
 *
 * <p>
 * This event is fired on the mod-specific event bus, only on the {@linkplain LogicalSide#CLIENT logical client}.
 */
public final class RegisterClientExtensionsEvent extends Event implements IModBusEvent {
    RegisterClientExtensionsEvent() {}

    /**
     * Register the given {@link IClientBlockExtensions} for the given {@link Block}s
     */
    public void registerBlock(IClientBlockExtensions extensions, Block... blocks) {
        ClientExtensionsManager.register(extensions, ClientExtensionsManager.BLOCK_EXTENSIONS, blocks);
    }

    /**
     * Register the given {@link IClientBlockExtensions} for the given {@link Block}s
     */
    @SafeVarargs
    public final void registerBlock(IClientBlockExtensions extensions, RegistryEntry<Block>... blocks) {
        registerBlock(extensions, Arrays.stream(blocks).map(RegistryEntry::value).toArray(Block[]::new));
    }

    /**
     * {@return whether a {@link IClientBlockExtensions} has been registered for the given {@link Block}}
     */
    public boolean isBlockRegistered(Block block) {
        return ClientExtensionsManager.BLOCK_EXTENSIONS.containsKey(block);
    }

    /**
     * Register the given {@link IClientItemExtensions} for the given {@link Item}s
     */
    public void registerItem(IClientItemExtensions extensions, Item... items) {
        ClientExtensionsManager.register(extensions, ClientExtensionsManager.ITEM_EXTENSIONS, items);
    }

    /**
     * Register the given {@link IClientItemExtensions} for the given {@link Item}s
     */
    @SafeVarargs
    public final void registerItem(IClientItemExtensions extensions, RegistryEntry<Item>... items) {
        registerItem(extensions, Arrays.stream(items).map(RegistryEntry::value).toArray(Item[]::new));
    }

    /**
     * {@return whether a {@link IClientItemExtensions} has been registered for the given {@link Item}}
     */
    public boolean isItemRegistered(Item item) {
        return ClientExtensionsManager.ITEM_EXTENSIONS.containsKey(item);
    }

    /**
     * Register the given {@link IClientMobEffectExtensions} for the given {@link StatusEffect}s
     */
    public void registerMobEffect(IClientMobEffectExtensions extensions, StatusEffect... mobEffects) {
        ClientExtensionsManager.register(extensions, ClientExtensionsManager.MOB_EFFECT_EXTENSIONS, mobEffects);
    }

    /**
     * Register the given {@link IClientMobEffectExtensions} for the given {@link StatusEffect}s
     */
    @SafeVarargs
    public final void registerMobEffect(IClientMobEffectExtensions extensions, RegistryEntry<StatusEffect>... mobEffects) {
        registerMobEffect(extensions, Arrays.stream(mobEffects).map(RegistryEntry::value).toArray(StatusEffect[]::new));
    }

    /**
     * {@return whether a {@link IClientMobEffectExtensions} has been registered for the given {@link StatusEffect}}
     */
    public boolean isMobEffectRegistered(StatusEffect mobEffect) {
        return ClientExtensionsManager.MOB_EFFECT_EXTENSIONS.containsKey(mobEffect);
    }

    /**
     * Register the given {@link IClientFluidTypeExtensions} for the given {@link FluidType}s
     */
    public void registerFluidType(IClientFluidTypeExtensions extensions, FluidType... fluidTypes) {
        ClientExtensionsManager.register(extensions, ClientExtensionsManager.FLUID_TYPE_EXTENSIONS, fluidTypes);
    }

    /**
     * Register the given {@link IClientFluidTypeExtensions} for the given {@link FluidType}s
     */
    @SafeVarargs
    public final void registerFluidType(IClientFluidTypeExtensions extensions, RegistryEntry<FluidType>... fluidTypes) {
        registerFluidType(extensions, Arrays.stream(fluidTypes).map(RegistryEntry::value).toArray(FluidType[]::new));
    }

    /**
     * {@return whether a {@link IClientFluidTypeExtensions} has been registered for the given {@link FluidType}}
     */
    public boolean isFluidTypeRegistered(FluidType fluidType) {
        return ClientExtensionsManager.FLUID_TYPE_EXTENSIONS.containsKey(fluidType);
    }
}
