/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.settings;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.InputUtil.Key;

public class KeyMappingLookup {
    private static final EnumMap<KeyModifier, Map<InputUtil.Key, Collection<KeyBinding>>> map = new EnumMap<>(KeyModifier.class);
    static {
        for (KeyModifier modifier : KeyModifier.values()) {
            map.put(modifier, Maps.newConcurrentMap());
        }
    }

    /**
     * Returns all active keys associated with the given key code and the active
     * modifiers and conflict context.
     *
     * @param keyCode the key being pressed
     * @return the list of key mappings
     */
    public List<KeyBinding> getAll(InputUtil.Key keyCode) {
        return this.getAll(keyCode, false);
    }

    /**
     * Returns all active keys associated with the given key code and the active
     * modifiers and conflict context.
     *
     * @param keyCode   the key being pressed
     * @param releasing if the key is being released
     * @return the list of key mappings
     */
    public List<KeyBinding> getAll(InputUtil.Key keyCode, boolean releasing) {
        List<KeyBinding> matchingBindings = new ArrayList<>();
        // Get a list of all active modifiers
        List<KeyModifier> activeModifiers = KeyModifier.getActiveModifiers();
        // Get modifier for key code
        KeyModifier keyCodeModifier = KeyModifier.getKeyModifier(keyCode);

        for (var modifier : activeModifiers) {
            // If modifier matches, add other modifiers
            if (modifier.matches(keyCode)) {
                // Check if binding matches with another modifier
                for (var otherModifier : activeModifiers) {

                    // Skip if modifier matches current key code
                    if (otherModifier == keyCodeModifier) {
                        continue;
                    }

                    // Loop through all modifier codes
                    for (var otherModifierCode : otherModifier.codes()) {
                        if (InputUtil.isKeyPressed(MinecraftClient.getInstance().getWindow().getHandle(), otherModifierCode.getCode())) {
                            matchingBindings.addAll(findKeybinds(otherModifierCode, modifier));
                        }
                    }
                }
            } else {
                // Attempt to add all bindings where the keycode and the modifier are different
                matchingBindings.addAll(findKeybinds(keyCode, modifier));
            }
        }

        // Release all bindings which use this key code as a modifier
        if (releasing && keyCodeModifier != KeyModifier.NONE) {
            matchingBindings.addAll(map.get(keyCodeModifier).entrySet().stream()
                    // Only match keys that are mapped
                    .filter(entry -> entry.getKey() != InputUtil.UNKNOWN_KEY)
                    .flatMap(entry -> entry.getValue().stream())
                    // Make sure the key is active in the current context
                    .filter(mapping -> mapping.getKeyConflictContext().isActive())
                    .toList());
        }

        // If there were no matches or a key is being released, check the key without any modifiers
        if (releasing || matchingBindings.isEmpty()) {
            matchingBindings.addAll(findKeybinds(keyCode, KeyModifier.NONE));
        }

        return matchingBindings;
    }

    private List<KeyBinding> findKeybinds(InputUtil.Key keyCode, KeyModifier modifier) {
        Collection<KeyBinding> modifierBindings = map.get(modifier).get(keyCode);
        if (modifierBindings != null) {
            return modifierBindings.stream()
                    .filter(binding -> binding.isActiveAndMatches(keyCode))
                    .toList();
        }
        return List.of();
    }

    public void put(InputUtil.Key keyCode, KeyBinding keyBinding) {
        KeyModifier keyModifier = keyBinding.getKeyModifier();
        Map<InputUtil.Key, Collection<KeyBinding>> bindingsMap = map.get(keyModifier);
        Collection<KeyBinding> bindingsForKey = bindingsMap.computeIfAbsent(keyCode, k -> Lists.newCopyOnWriteArrayList());
        bindingsForKey.add(keyBinding);
    }

    public void remove(KeyBinding keyBinding) {
        KeyModifier keyModifier = keyBinding.getKeyModifier();
        InputUtil.Key keyCode = keyBinding.getKey();
        Map<InputUtil.Key, Collection<KeyBinding>> bindingsMap = map.get(keyModifier);
        Collection<KeyBinding> bindingsForKey = bindingsMap.get(keyCode);
        if (bindingsForKey != null) {
            bindingsForKey.remove(keyBinding);
            if (bindingsForKey.isEmpty()) {
                bindingsMap.remove(keyCode);
            }
        }
    }

    public void clear() {
        for (Map<InputUtil.Key, Collection<KeyBinding>> bindings : map.values()) {
            bindings.clear();
        }
    }
}
