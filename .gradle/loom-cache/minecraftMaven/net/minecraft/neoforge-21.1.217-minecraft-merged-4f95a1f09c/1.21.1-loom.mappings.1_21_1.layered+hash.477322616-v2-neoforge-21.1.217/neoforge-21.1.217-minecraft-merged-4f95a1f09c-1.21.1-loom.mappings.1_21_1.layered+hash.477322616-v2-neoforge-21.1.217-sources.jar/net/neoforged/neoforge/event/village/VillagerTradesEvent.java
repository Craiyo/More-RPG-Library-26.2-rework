/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.village;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import java.util.List;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.village.TradeOffers.Factory;
import net.minecraft.village.VillagerData;
import net.minecraft.village.VillagerProfession;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.TagsUpdatedEvent;
import org.jetbrains.annotations.ApiStatus;

/**
 * VillagerTradesEvent is fired during reload by {@link TagsUpdatedEvent}. It is used to gather the trade lists for each profession.
 * It is fired on the {@link NeoForge#EVENT_BUS}.
 * It is fired once for each registered villager profession.
 * Villagers pick two trades from their trade map, based on their level.
 * Villager level is increased by successful trades.
 * The map is populated for levels 1-5 (inclusive), so Map#get will never return null for those keys.
 * Levels outside of this range do nothing, as specified by {@link VillagerData#canLevelUp(int)} which is called before attempting to level up.
 * To add trades to the merchant, simply add new trades to the list. {@link BasicItemListing} provides a default implementation.
 */
public class VillagerTradesEvent extends Event {
    protected Int2ObjectMap<List<Factory>> trades;
    protected VillagerProfession type;
    private final DynamicRegistryManager registryAccess;

    /**
     * @deprecated Use {@link #VillagerTradesEvent(Int2ObjectMap, VillagerProfession, DynamicRegistryManager)} instead
     */
    @Deprecated(forRemoval = true, since = "1.21.1")
    public VillagerTradesEvent(Int2ObjectMap<List<Factory>> trades, VillagerProfession type) {
        this(trades, type, DynamicRegistryManager.EMPTY);
    }

    @ApiStatus.Internal
    public VillagerTradesEvent(Int2ObjectMap<List<Factory>> trades, VillagerProfession type, DynamicRegistryManager registryAccess) {
        this.trades = trades;
        this.type = type;
        this.registryAccess = registryAccess;
    }

    public Int2ObjectMap<List<Factory>> getTrades() {
        return trades;
    }

    public VillagerProfession getType() {
        return type;
    }

    public DynamicRegistryManager getRegistryAccess() {
        return registryAccess;
    }
}
