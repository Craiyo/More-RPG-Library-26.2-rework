/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.util;

import net.minecraft.component.type.MapIdComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.map.MapState;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Extended {@link TooltipContext} used when generating attribute tooltips.
 */
public interface AttributeTooltipContext extends Item.TooltipContext {
    /**
     * {@return the player for whom tooltips are being generated for, if known}
     */
    @Nullable
    PlayerEntity player();

    /**
     * {@return the current tooltip flag}
     */
    TooltipType flag();

    public static AttributeTooltipContext of(@Nullable PlayerEntity player, Item.TooltipContext itemCtx, TooltipType flag) {
        return new AttributeTooltipContext() {
            @Override
            public WrapperLookup getRegistryLookup() {
                return itemCtx.getRegistryLookup();
            }

            @Override
            public float getUpdateTickRate() {
                return itemCtx.getUpdateTickRate();
            }

            @Override
            public MapState getMapState(MapIdComponent id) {
                return itemCtx.getMapState(id);
            }

            @Override
            public World level() {
                return itemCtx.level();
            }

            @Nullable
            @Override
            public PlayerEntity player() {
                return player;
            }

            @Override
            public TooltipType flag() {
                return flag;
            }
        };
    }
}
