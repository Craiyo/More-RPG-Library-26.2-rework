/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries.holdersets;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryOwner;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Util;
import net.minecraft.util.math.random.Random;
import net.neoforged.neoforge.common.NeoForgeMod;

/**
 * <p>Holderset that represents all elements of a registry. Json format:</p>
 * 
 * <pre>
 * {
 *   "type": "neoforge:any"
 * }
 * </pre>
 */
public record AnyHolderSet<T>(RegistryWrapper.Impl<T> registryLookup) implements ICustomHolderSet<T> {

    @Override
    public HolderSetType type() {
        return NeoForgeMod.ANY_HOLDER_SET.value();
    }

    @Override
    public Iterator<RegistryEntry<T>> iterator() {
        return this.stream().iterator();
    }

    @Override
    public Stream<RegistryEntry<T>> stream() {
        return this.registryLookup.streamEntries().map(Function.identity());
    }

    @Override
    public int size() {
        return (int) this.stream().count();
    }

    @Override
    public Either<TagKey<T>, List<RegistryEntry<T>>> getStorage() {
        return Either.right(this.stream().toList());
    }

    @Override
    public Optional<RegistryEntry<T>> getRandom(Random random) {
        return Util.getRandomOrEmpty(this.stream().toList(), random);
    }

    @Override
    public RegistryEntry<T> get(int i) {
        List<RegistryEntry<T>> holders = this.stream().toList();
        RegistryEntry<T> holder = i >= holders.size() ? null : holders.get(i);
        if (holder == null)
            throw new NoSuchElementException("No element " + i + " in registry " + this.registryLookup.getRegistryKey());

        return holder;
    }

    @Override
    public boolean contains(RegistryEntry<T> holder) {
        RegistryKey<T> key = holder.getKey();
        return key != null && this.registryLookup().getOptional(key).isPresent();
    }

    @Override
    public boolean ownerEquals(RegistryEntryOwner<T> holderOwner) {
        return true;
    }

    @Override
    public Optional<TagKey<T>> getTagKey() {
        return Optional.empty();
    }

    @Override
    public String toString() {
        return "AnySet(" + this.registryLookup.getRegistryKey() + ")";
    }
    public static class Type implements HolderSetType {
        @Override
        public <T> MapCodec<? extends ICustomHolderSet<T>> makeCodec(RegistryKey<? extends Registry<T>> registryKey, Codec<RegistryEntry<T>> holderCodec, boolean forceList) {
            return RegistryOps.retrieveRegistryLookup(registryKey)
                    .xmap(AnyHolderSet::new, AnyHolderSet::registryLookup);
        }

        @Override
        public <T> PacketCodec<RegistryByteBuf, ? extends ICustomHolderSet<T>> makeStreamCodec(RegistryKey<? extends Registry<T>> registryKey) {
            return new PacketCodec<RegistryByteBuf, AnyHolderSet<T>>() {
                @Override
                public AnyHolderSet<T> decode(RegistryByteBuf buf) {
                    return new AnyHolderSet<>(buf.getRegistryManager().getWrapperOrThrow(registryKey));
                }

                @Override
                public void encode(RegistryByteBuf buf, AnyHolderSet<T> holderSet) {
                    final var registryKeyIn = holderSet.registryLookup.getRegistryKey();
                    if (!registryKey.equals(registryKeyIn)) {
                        throw new IllegalStateException("Can not encode " + holderSet
                                + ", expected registry: "
                                + registryKey.getRegistry() + "/" + registryKey.getValue());
                    }
                }
            };
        }
    }
}
