/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui.widget;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.VersionChecker;
import net.neoforged.fml.i18n.MavenVersionTranslator;
import net.neoforged.neoforge.client.gui.ModListScreen;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforgespi.language.IModInfo;

public class ModListWidget extends AlwaysSelectedEntryListWidget<ModListWidget.ModEntry> {
    private static String stripControlCodes(String value) {
        return net.minecraft.util.StringHelper.stripTextFormat(value);
    }

    private static final Identifier VERSION_CHECK_ICONS = Identifier.of(NeoForgeVersion.MOD_ID, "textures/gui/version_check_icons.png");
    private final int listWidth;

    private ModListScreen parent;

    public ModListWidget(ModListScreen parent, int listWidth, int top, int bottom) {
        super(parent.getMinecraftInstance(), listWidth, bottom - top, top, parent.getFontRenderer().fontHeight * 2 + 8);
        this.parent = parent;
        this.listWidth = listWidth;
        //this.setRenderBackground(false); // Porting 1.20.5 still needed?
        this.refreshList();
    }

    @Override
    protected int getScrollbarX() {
        return this.listWidth;
    }

    @Override
    public int getRowWidth() {
        return this.listWidth;
    }

    public void refreshList() {
        this.clearEntries();
        parent.buildModList(this::addEntry, mod -> new ModEntry(mod, this.parent));
    }

    public class ModEntry extends AlwaysSelectedEntryListWidget.Entry<ModEntry> {
        private final ModContainer container;
        private final ModListScreen parent;

        ModEntry(ModContainer info, ModListScreen parent) {
            this.container = info;
            this.parent = parent;
        }

        @Override
        public Text getNarration() {
            return Text.translatable("narrator.select", container.getModInfo().getDisplayName());
        }

        @Override
        public void render(DrawContext guiGraphics, int entryIdx, int top, int left, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isMouseOver, float partialTick) {
            Text name = Text.literal(stripControlCodes(container.getModInfo().getDisplayName()));
            Text version = Text.literal(stripControlCodes(MavenVersionTranslator.artifactVersionToString(container.getModInfo().getVersion())));
            VersionChecker.CheckResult vercheck = VersionChecker.getResult(container.getModInfo());
            TextRenderer font = this.parent.getFontRenderer();
            guiGraphics.drawText(font, Language.getInstance().reorder(StringVisitable.concat(font.trimToWidth(name, listWidth))), left + 3, top + 2, 0xFFFFFF, false);
            guiGraphics.drawText(font, Language.getInstance().reorder(StringVisitable.concat(font.trimToWidth(version, listWidth))), left + 3, top + 2 + font.fontHeight, 0xCCCCCC, false);
            if (vercheck.status().shouldDraw()) {
                //TODO: Consider adding more icons for visualization
                RenderSystem.setShaderColor(1, 1, 1, 1);
                guiGraphics.getMatrices().push();
                guiGraphics.drawTexture(VERSION_CHECK_ICONS, getX() + width - 12, top + entryHeight / 4, vercheck.status().getSheetOffset() * 8, (vercheck.status().isAnimated() && ((System.currentTimeMillis() / 800 & 1)) == 1) ? 8 : 0, 8, 8, 64, 16);
                guiGraphics.getMatrices().pop();
            }
        }

        @Override
        public boolean mouseClicked(double p_mouseClicked_1_, double p_mouseClicked_3_, int p_mouseClicked_5_) {
            // clicking on a selected item a second time unselects it
            parent.setSelected(isFocused() ? null : this);
            ModListWidget.this.setSelected(isFocused() ? null : this);
            return false;
        }

        @Override
        public void setFocused(boolean focused) {
            // ignore focus loss so the item stays selected when tabbing to the config button
            if (focused) {
                parent.setSelected(this);
                ModListWidget.this.setSelected(this);
            }
        }

        @Override
        public boolean isFocused() {
            return ModListWidget.this.getSelectedOrNull() == this;
        }

        public IModInfo getInfo() {
            return container.getModInfo();
        }

        public ModContainer getContainer() {
            return container;
        }
    }
}
