/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.world;

import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Set;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.SpawnSettings.SpawnEntry;
import net.minecraft.world.gen.structure.Structure;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.common.world.StructureSettingsBuilder.StructureSpawnOverrideBuilder;

public final class StructureModifiers {
    private StructureModifiers() {} // Utility class.

    /**
     * <p>Stock structure modifier that adds a mob spawn override to a structure.
     * If a structure has mob spawn overrides, random mob spawning will use the structure's spawns instead of the local biome's spawns.
     * Has the following json format:</p>
     * 
     * <pre>
     * {
     *   "type": "neoforge:add_spawns", // Required
     *   "structures": "#namespace:structure_tag", // Accepts a structure id, [list of structure ids], or #namespace:structure_tag
     *   "spawners":
     *   {
     *     "type": "namespace:entity_type", // Type of mob to spawn
     *     "weight": 100, // int, spawn weighting
     *     "minCount": 1, // int, minimum pack size
     *     "maxCount": 4, // int, maximum pack size
     *   }
     * }
     * </pre>
     * 
     * <p>Optionally accepts a list of spawner objects instead of a single spawner:</p>
     * 
     * <pre>
     * {
     *   "type": "neoforge:add_spawns", // Required
     *   "structure": "#namespace:structure_tag", // Accepts a structure id, [list of structure ids], or #namespace:structure_tag
     *   "spawners":
     *   [
     *     {
     *       "type": "namespace:entity_type", // Type of mob to spawn
     *       "weight": 100, // int, spawn weighting
     *       "minCount": 1, // int, minimum pack size
     *       "maxCount": 4, // int, maximum pack size
     *     },
     *     {
     *       // additional spawner object
     *     }
     *   ]
     * }
     * </pre>
     *
     * @param structures Structures to add mob spawns to.
     * @param spawners   List of SpawnerDatas specifying EntityType, weight, and pack size.
     */
    public record AddSpawnsStructureModifier(RegistryEntryList<Structure> structures,
            List<SpawnEntry> spawners) implements StructureModifier {
        /**
         * Convenience method for using a single {@link SpawnEntry}.
         *
         * @param structures Structures to add mob spawns to.
         * @param spawner    SpawnerData specifying EntityTYpe, weight, and pack size.
         * @return AddSpawnsStructureModifier that adds a single spawn entry to the specified biomes.
         */
        public static AddSpawnsStructureModifier singleSpawn(RegistryEntryList<Structure> structures, SpawnEntry spawner) {
            return new AddSpawnsStructureModifier(structures, List.of(spawner));
        }

        @Override
        public void modify(RegistryEntry<Structure> structure, Phase phase, ModifiableStructureInfo.StructureInfo.Builder builder) {
            if (phase == Phase.ADD && this.structures.contains(structure)) {
                StructureSettingsBuilder settingsBuilder = builder.getStructureSettings();
                for (SpawnEntry spawner : this.spawners) {
                    EntityType<?> type = spawner.type;
                    settingsBuilder.getOrAddSpawnOverrides(type.getSpawnGroup()).addSpawn(spawner);
                }
            }
        }

        @Override
        public MapCodec<? extends StructureModifier> codec() {
            return NeoForgeMod.ADD_SPAWNS_STRUCTURE_MODIFIER_TYPE.get();
        }
    }

    /**
     * <p>Stock structure modifier that removes mob spawns from a structure.
     * Does not remove the override list itself;
     * see {@link ClearSpawnsStructureModifier} to remove override lists completely.
     * </p>
     * Has the following json format:</p>
     * 
     * <pre>
     * {
     *   "type": "neoforge:remove_spawns", // Required
     *   "structures": "#namespace:structure_tag", // Accepts a structure id, [list of structure ids], or #namespace:structure_tag
     *   "entity_types": #namespace:entitytype_tag // Accepts an entity type, [list of entity types], or #namespace:entitytype_tag
     * }
     * </pre>
     *
     * @param structures  Biomes to remove mob spawns from.
     * @param entityTypes EntityTypes to remove from spawn lists.
     */
    public record RemoveSpawnsStructureModifier(RegistryEntryList<Structure> structures,
            RegistryEntryList<EntityType<?>> entityTypes) implements StructureModifier {
        @Override
        public void modify(RegistryEntry<Structure> structure, Phase phase, ModifiableStructureInfo.StructureInfo.Builder builder) {
            if (phase == Phase.REMOVE && this.structures.contains(structure)) {
                StructureSettingsBuilder settingsBuilder = builder.getStructureSettings();
                for (SpawnGroup category : SpawnGroup.values()) {
                    var overrides = settingsBuilder.getSpawnOverrides(category);
                    if (overrides == null || overrides.getSpawns().isEmpty())
                        continue;
                    overrides.removeSpawns(spawnerData -> {
                        Identifier key = Registries.ENTITY_TYPE.getId(spawnerData.type);
                        return this.entityTypes.contains(Registries.ENTITY_TYPE.entryOf(RegistryKey.of(RegistryKeys.ENTITY_TYPE, key)));
                    });
                }
            }
        }

        @Override
        public MapCodec<? extends StructureModifier> codec() {
            return NeoForgeMod.REMOVE_SPAWNS_STRUCTURE_MODIFIER_TYPE.get();
        }
    }

    /**
     * <p>Stock biome modifier that removes mob spawns from a structure modifier.
     * Does not remove the override list itself;
     * see {@link ClearSpawnsStructureModifier} to remove override lists completely.
     * </p>
     * Has the following json format:</p>
     * 
     * <pre>
     * {
     *   "type": "neoforge:clear_spawns", // Required
     *   "structures": "#namespace:structure_tag", // Accepts a structure id, [list of structure ids], or #namespace:structure_tag
     *   "categories": "monster" OR ["monster", "creature"] // Optional, one or more {@link SpawnGroup}; defaults to all categories if not specified.
     * }
     * </pre>
     *
     * @param structures Structures to remove mob spawn overrides from.
     * @param categories Set of mob categories to remove spawn overrides for.
     */
    public record ClearSpawnsStructureModifier(RegistryEntryList<Structure> structures,
            Set<SpawnGroup> categories) implements StructureModifier {
        @Override
        public void modify(RegistryEntry<Structure> structure, Phase phase, ModifiableStructureInfo.StructureInfo.Builder builder) {
            if (phase == Phase.REMOVE && this.structures.contains(structure)) {
                StructureSettingsBuilder settingsBuilder = builder.getStructureSettings();
                for (SpawnGroup category : this.categories) {
                    settingsBuilder.removeSpawnOverrides(category);
                }
            }
        }

        @Override
        public MapCodec<? extends StructureModifier> codec() {
            return NeoForgeMod.CLEAR_SPAWNS_STRUCTURE_MODIFIER_TYPE.get();
        }
    }
}
