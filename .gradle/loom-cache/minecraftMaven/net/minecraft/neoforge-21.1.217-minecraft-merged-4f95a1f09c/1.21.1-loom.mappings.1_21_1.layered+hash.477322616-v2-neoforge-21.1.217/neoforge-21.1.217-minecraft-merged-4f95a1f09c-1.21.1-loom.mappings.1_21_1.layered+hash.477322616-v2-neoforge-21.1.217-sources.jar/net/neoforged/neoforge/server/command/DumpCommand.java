/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.logging.LogUtils;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.command.argument.RegistryKeyArgumentType;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.neoforged.fml.loading.FMLLoader;
import org.slf4j.Logger;

/**
 * The {@code /neoforge dump registry} command for printing out the contents of a registry to a file in the game directory's dumps/registry folder.
 */
class DumpCommand {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final RegistryKey<Registry<Registry<?>>> ROOT_REGISTRY_KEY = RegistryKey.ofRegistry(Identifier.ofVanilla("root"));
    private static final String ALPHABETICAL_SORT_PARAM = "alphabetical_sort";
    private static final String PRINT_NUMERIC_ID_PARAM = "print_numeric_ids";

    private static final DynamicCommandExceptionType UNKNOWN_REGISTRY = new DynamicCommandExceptionType(key -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.dump.error.unknown_registry", key));

    public static ArgumentBuilder<ServerCommandSource, ?> register() {
        /*
         * /neoforge dump registry <registry> <alphabetical_sort> <print_numeric_ids>
         */
        return CommandManager.literal("dump")
                .requires(cs -> cs.hasPermissionLevel(CommandManager.field_31841))
                .then(CommandManager.literal("registry")
                        .then(CommandManager.argument("registry", RegistryKeyArgumentType.registryKey(ROOT_REGISTRY_KEY))
                                .suggests(CommandUtils::suggestRegistries)
                                .executes(context -> dumpRegistry(context, false, false))
                                .then(CommandManager.argument(ALPHABETICAL_SORT_PARAM, BoolArgumentType.bool())
                                        .executes(context -> dumpRegistry(context, BoolArgumentType.getBool(context, ALPHABETICAL_SORT_PARAM), false))
                                        .then(CommandManager.argument(PRINT_NUMERIC_ID_PARAM, BoolArgumentType.bool())
                                                .executes(context -> dumpRegistry(context, BoolArgumentType.getBool(context, ALPHABETICAL_SORT_PARAM), BoolArgumentType.getBool(context, PRINT_NUMERIC_ID_PARAM)))))));
    }

    private static int dumpRegistry(final CommandContext<ServerCommandSource> ctx, boolean alphabeticalSort, boolean printNumericIds) throws CommandSyntaxException {
        final RegistryKey<? extends Registry<?>> registryKey = CommandUtils.getResourceKey(ctx, "registry", ROOT_REGISTRY_KEY)
                .orElseThrow(); // Expect to always retrieve a resource key for the root registry (registry key)

        final Registry<?> registry = ctx.getSource().getServer().getRegistryManager().getOptional(registryKey)
                .orElseThrow(() -> UNKNOWN_REGISTRY.create(registryKey.getValue()));

        String fileLocationForErrorReporting = "";
        try {
            Path registryDumpDirectory = FMLLoader.getGamePath().resolve("dumps").resolve("registry");
            Path registryNamespaceDirectory = registryDumpDirectory.resolve(registryKey.getValue().getNamespace().replaceAll("[/:.]", "_"));
            Files.createDirectories(registryNamespaceDirectory);

            String fileName = registryKey.getValue().getPath().replaceAll("[/:.]", "_") + ".txt";
            Path registryDumpFile = registryNamespaceDirectory.resolve(fileName);
            fileLocationForErrorReporting = registryDumpFile.toString();

            try (var outputStream = Files.newOutputStream(registryDumpFile)) {
                List<Identifier> sortedRegistryKeys = getSortedRegistryKeys(alphabeticalSort, printNumericIds, registry);

                for (Identifier registryKeys : sortedRegistryKeys) {
                    String results = registryKeys.toString();
                    if (printNumericIds) {
                        results = registry.getId(registryKeys) + " - " + results;
                    }
                    outputStream.write((results + "\n").getBytes());
                }
            }

            MutableText filePathComponent = Text.literal("..." + FMLLoader.getGamePath().relativize(registryDumpFile))
                    .formatted(Formatting.UNDERLINE)
                    .formatted(Formatting.GOLD);

            // Click action not allow on dedicated servers as client cannot click link to a server's file path.
            if (!FMLLoader.getDist().isDedicatedServer()) {
                filePathComponent.styled((style) -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, registryDumpFile.toString())));
            }

            ctx.getSource().sendFeedback(() -> CommandUtils.makeTranslatableWithFallback(
                    "commands.neoforge.dump.success",
                    Text.literal(registryKey.getValue().toString()).formatted(Formatting.YELLOW),
                    filePathComponent),
                    false);

            return Command.SINGLE_SUCCESS;
        } catch (Exception e) {

            ctx.getSource().sendError(
                    CommandUtils.makeTranslatableWithFallback(
                            "commands.neoforge.dump.failure",
                            Text.literal(registryKey.getValue().toString()).formatted(Formatting.YELLOW),
                            Text.literal(fileLocationForErrorReporting).formatted(Formatting.GOLD)));

            LOGGER.error("Failed to create new file with " + registryKey + " registry's contents at " + fileLocationForErrorReporting, e);

            return 0;
        }
    }

    private static List<Identifier> getSortedRegistryKeys(boolean alphabeticalSort, boolean printNumericIds, Registry<?> registry) {
        List<Identifier> sortedRegistryNames = new ArrayList<>(registry.getIds());

        if (alphabeticalSort) {
            sortedRegistryNames.sort(Identifier::compareNamespaced);
        } else if (printNumericIds) {
            sortedRegistryNames = sortedRegistryNames.stream().sorted(Comparator.comparingInt(registry::getId)).toList();
        }

        return sortedRegistryNames;
    }
}
