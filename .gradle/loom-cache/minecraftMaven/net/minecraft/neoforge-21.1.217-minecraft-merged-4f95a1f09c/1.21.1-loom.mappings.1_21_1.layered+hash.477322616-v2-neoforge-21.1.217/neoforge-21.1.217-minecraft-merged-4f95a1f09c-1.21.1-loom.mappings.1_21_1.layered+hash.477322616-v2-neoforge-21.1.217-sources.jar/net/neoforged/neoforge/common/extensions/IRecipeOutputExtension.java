/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.data.server.recipe.RecipeExporter;
import net.minecraft.recipe.Recipe;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.crafting.ConditionalRecipeOutput;
import org.jetbrains.annotations.Nullable;

/**
 * Extra methods for {@link RecipeExporter}.
 */
public interface IRecipeOutputExtension {
    private RecipeExporter self() {
        return (RecipeExporter) this;
    }

    /**
     * Generates a recipe with the given conditions.
     */
    void accept(Identifier id, Recipe<?> recipe, @Nullable AdvancementEntry advancement, ICondition... conditions);

    /**
     * Builds a wrapper around this recipe output that adds conditions to all received recipes.
     */
    default RecipeExporter withConditions(ICondition... conditions) {
        return new ConditionalRecipeOutput(self(), conditions);
    }
}
