/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import org.jetbrains.annotations.ApiStatus;

/**
 * This payload is sent to the client when the server has finished sending all the frozen registries.
 */
@ApiStatus.Internal
public final class FrozenRegistrySyncCompletedPayload implements CustomPayload {
    public static final Id<FrozenRegistrySyncCompletedPayload> TYPE = new Id<>(Identifier.of(NeoForgeVersion.MOD_ID, "frozen_registry_sync_completed"));
    public static final FrozenRegistrySyncCompletedPayload INSTANCE = new FrozenRegistrySyncCompletedPayload();
    public static final PacketCodec<PacketByteBuf, FrozenRegistrySyncCompletedPayload> STREAM_CODEC = PacketCodec.unit(INSTANCE);

    private FrozenRegistrySyncCompletedPayload() {}

    @Override
    public Id<FrozenRegistrySyncCompletedPayload> getId() {
        return TYPE;
    }
}
