/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.text.Text;
import net.minecraft.text.TextCodecs;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import org.jetbrains.annotations.ApiStatus;

/**
 * Payload sent to the client when the server has failed to set up the modded network.
 *
 * @param failureReasons A map of mod ids to the reason why the modded network failed to set up.
 */
@ApiStatus.Internal
public record ModdedNetworkSetupFailedPayload(Map<Identifier, Text> failureReasons) implements CustomPayload {
    public static final Identifier ID = Identifier.of(NeoForgeVersion.MOD_ID, "modded_network_setup_failed");
    public static final Id<ModdedNetworkSetupFailedPayload> TYPE = new Id<>(ID);
    public static final PacketCodec<PacketByteBuf, ModdedNetworkSetupFailedPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.map(HashMap::new, Identifier.PACKET_CODEC, TextCodecs.PACKET_CODEC),
            ModdedNetworkSetupFailedPayload::failureReasons,
            ModdedNetworkSetupFailedPayload::new);

    @Override
    public Id<ModdedNetworkSetupFailedPayload> getId() {
        return TYPE;
    }
}
