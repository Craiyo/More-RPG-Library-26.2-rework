/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui;

import com.google.common.collect.ImmutableMap;
import java.util.HashMap;
import java.util.function.Function;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.item.tooltip.TooltipData;
import net.neoforged.fml.ModLoader;
import net.neoforged.neoforge.client.event.RegisterClientTooltipComponentFactoriesEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Manager for {@link TooltipComponent} factories.
 * <p>
 * Provides a lookup.
 */
public final class ClientTooltipComponentManager {
    private static ImmutableMap<Class<? extends TooltipData>, Function<TooltipData, TooltipComponent>> FACTORIES;

    /**
     * Creates a client component for the given argument, or null if unsupported.
     */
    @Nullable
    public static TooltipComponent createClientTooltipComponent(TooltipData component) {
        var factory = FACTORIES.get(component.getClass());
        return factory != null ? factory.apply(component) : null;
    }

    @ApiStatus.Internal
    public static void init() {
        var factories = new HashMap<Class<? extends TooltipData>, Function<TooltipData, TooltipComponent>>();
        var event = new RegisterClientTooltipComponentFactoriesEvent(factories);
        ModLoader.postEventWrapContainerInModOrder(event);
        FACTORIES = ImmutableMap.copyOf(factories);
    }

    private ClientTooltipComponentManager() {}
}
