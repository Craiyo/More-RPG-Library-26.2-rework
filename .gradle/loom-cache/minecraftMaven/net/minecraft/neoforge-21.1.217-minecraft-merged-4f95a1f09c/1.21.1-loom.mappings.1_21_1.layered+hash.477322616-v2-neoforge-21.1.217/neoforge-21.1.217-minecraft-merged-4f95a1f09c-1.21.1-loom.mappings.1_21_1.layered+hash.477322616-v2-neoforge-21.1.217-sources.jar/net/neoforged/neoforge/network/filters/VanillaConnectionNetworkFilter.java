/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.filters;

import com.google.common.collect.ImmutableMap;
import com.mojang.brigadier.tree.RootCommandNode;
import com.mojang.logging.LogUtils;
import io.netty.channel.ChannelHandler;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.ArgumentTypes;
import net.minecraft.command.argument.TestClassArgumentType;
import net.minecraft.command.argument.TestFunctionArgumentType;
import net.minecraft.command.argument.serialize.ArgumentSerializer;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.common.SynchronizeTagsS2CPacket;
import net.minecraft.network.packet.s2c.play.CommandTreeS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityAttributesS2CPacket;
import net.minecraft.registry.BuiltinRegistries;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagPacketSerializer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.network.connection.ConnectionType;
import net.neoforged.neoforge.registries.RegistryManager;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;

/**
 * A filter for impl packets, used to filter/modify parts of vanilla impl messages that
 * will cause errors or warnings on vanilla clients, for example entity attributes that are added by Forge or mods.
 */
@ApiStatus.Internal
@ChannelHandler.Sharable
public class VanillaConnectionNetworkFilter extends VanillaPacketFilter {
    private static final Logger LOGGER = LogUtils.getLogger();

    private final ConnectionType connectionType;

    public VanillaConnectionNetworkFilter(ConnectionType connectionType) {
        super(
                ImmutableMap.<Class<? extends Packet<?>>, BiConsumer<Packet<?>, List<? super Packet<?>>>>builder()
                        .put(handler(EntityAttributesS2CPacket.class, VanillaConnectionNetworkFilter::filterEntityProperties))
                        .put(handler(CommandTreeS2CPacket.class, VanillaConnectionNetworkFilter::filterCommandList))
                        .put(handler(SynchronizeTagsS2CPacket.class, VanillaConnectionNetworkFilter::filterCustomTagTypes))
                        .build());

        this.connectionType = connectionType;
    }

    @Override
    public boolean isNecessary(ClientConnection manager) {
        return !connectionType.isNeoForge();
    }

    /**
     * Filter for SEntityPropertiesPacket. Filters out any entity attributes that are not in the "minecraft" namespace.
     * A vanilla client would ignore these with an error log.
     */
    private static EntityAttributesS2CPacket filterEntityProperties(EntityAttributesS2CPacket msg) {
        EntityAttributesS2CPacket newPacket = new EntityAttributesS2CPacket(msg.getEntityId(), Collections.emptyList());
        msg.getEntries().stream()
                .filter(snapshot -> {
                    Identifier key = snapshot.attribute().getKey().map(RegistryKey::getValue).orElse(null);
                    return key != null && key.getNamespace().equals("minecraft");
                })
                .forEach(snapshot -> newPacket.getEntries().add(snapshot));
        return newPacket;
    }

    /**
     * Filter for SCommandListPacket. Uses {@link CommandTreeCleaner} to filter out any ArgumentTypes that are not in the "minecraft" or "brigadier" namespace.
     * A vanilla client would fail to deserialize the packet and disconnect with an error message if these were sent.
     */
    private static CommandTreeS2CPacket filterCommandList(CommandTreeS2CPacket packet) {
        CommandRegistryAccess commandBuildContext = CommandManager.createRegistryAccess(BuiltinRegistries.createWrapperLookup());
        RootCommandNode<CommandSource> root = packet.getCommandTree(commandBuildContext);
        RootCommandNode<CommandSource> newRoot = CommandTreeCleaner.cleanArgumentTypes(root, argType -> {
            if (argType instanceof TestFunctionArgumentType || argType instanceof TestClassArgumentType)
                return false; // Vanilla connections should not have gametest on, so we should filter these out always

            ArgumentSerializer<?, ?> info = ArgumentTypes.get(argType);
            Identifier id = Registries.COMMAND_ARGUMENT_TYPE.getId(info);
            return id != null && (id.getNamespace().equals("minecraft") || id.getNamespace().equals("brigadier"));
        });
        return new CommandTreeS2CPacket(newRoot);
    }

    /**
     * Filters out custom tag types that the vanilla client won't recognize.
     * It prevents a rare error from logging and reduces the packet size
     */
    private static SynchronizeTagsS2CPacket filterCustomTagTypes(SynchronizeTagsS2CPacket packet) {
        Map<RegistryKey<? extends Registry<?>>, TagPacketSerializer.Serialized> tags = packet.getGroups()
                .entrySet().stream().filter(e -> isVanillaRegistry(e.getKey().getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
        return new SynchronizeTagsS2CPacket(tags);
    }

    private static boolean isVanillaRegistry(Identifier location) {
        // Checks if the registry name is contained within the static view of both BuiltInRegistries and VanillaRegistries
        return RegistryManager.getVanillaRegistryKeys().contains(location)
                || BuiltinRegistries.DATAPACK_REGISTRY_KEYS.stream().anyMatch(k -> k.getValue().equals(location));
    }
}
