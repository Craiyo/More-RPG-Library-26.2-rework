/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.datafixers.util.Pair;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.command.argument.RegistryKeyArgumentType;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.Texts;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/**
 * The {@code /neoforge tags} command for listing a registry's tags, getting the elements of tags, and querying the tags of a
 * registry object.
 *
 * <p>Each command is paginated, showing {@value PAGE_SIZE} entries at a time. When there are more than 0 entries,
 * the text indicating the amount of entries is highlighted and can be clicked to copy the list of all entries (across
 * all pages) to the clipboard. (This is reflected by the use of green text in brackets, mimicking the clickable
 * coordinates in the {@code /locate} command's message)</p>
 *
 * <p>The command has three subcommands:</p>
 * <ul>
 * <li>{@code /neoforge tags &lt;registry> list [page]} - Lists all available tags in the given registry.</li>
 * <li>{@code /neoforge tags &lt;registry> get &lt;tag> [page]} - Gets all elements of the given tag in the given registry.</li>
 * <li>{@code /neoforge tags &lt;registry> query &lt;element> [page]} - Queries for all tags in the given registry which
 * contain the given registry object.</li>
 * </ul>
 */
class TagsCommand {
    private static final long PAGE_SIZE = 8;
    private static final RegistryKey<Registry<Registry<?>>> ROOT_REGISTRY_KEY = RegistryKey.ofRegistry(Identifier.ofVanilla("root"));

    private static final DynamicCommandExceptionType UNKNOWN_REGISTRY = new DynamicCommandExceptionType(key -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.error.unknown_registry", key.toString()));
    private static final Dynamic2CommandExceptionType UNKNOWN_TAG = new Dynamic2CommandExceptionType((tag, registry) -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.error.unknown_tag", tag.toString(), registry.toString()));
    private static final Dynamic2CommandExceptionType UNKNOWN_ELEMENT = new Dynamic2CommandExceptionType((tag, registry) -> CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.error.unknown_element", tag.toString(), registry.toString()));

    public static ArgumentBuilder<ServerCommandSource, ?> register() {
        /*
         * /neoforge tags <registry> list [page]
         * /neoforge tags <registry> get <tag> [page]
         * /neoforge tags <registry> query <element> [page]
         */
        return CommandManager.literal("tags")
                .requires(cs -> cs.hasPermissionLevel(2))
                .then(CommandManager.argument("registry", RegistryKeyArgumentType.registryKey(ROOT_REGISTRY_KEY))
                        .suggests(CommandUtils::suggestRegistries)
                        .then(CommandManager.literal("list")
                                .executes(ctx -> listTags(ctx, 1))
                                .then(CommandManager.argument("page", IntegerArgumentType.integer(1))
                                        .executes(ctx -> listTags(ctx, IntegerArgumentType.getInteger(ctx, "page")))))
                        .then(CommandManager.literal("get")
                                .then(CommandManager.argument("tag", IdentifierArgumentType.identifier())
                                        .suggests(CommandUtils.suggestFromRegistry(r -> r.streamTags().map(TagKey::id)::iterator, "registry", ROOT_REGISTRY_KEY))
                                        .executes(ctx -> listTagElements(ctx, 1))
                                        .then(CommandManager.argument("page", IntegerArgumentType.integer(1))
                                                .executes(ctx -> listTagElements(ctx, IntegerArgumentType.getInteger(ctx, "page"))))))
                        .then(CommandManager.literal("query")
                                .then(CommandManager.argument("element", IdentifierArgumentType.identifier())
                                        .suggests(CommandUtils.suggestFromRegistry(Registry::getIds, "registry", ROOT_REGISTRY_KEY))
                                        .executes(ctx -> queryElementTags(ctx, 1))
                                        .then(CommandManager.argument("page", IntegerArgumentType.integer(1))
                                                .executes(ctx -> queryElementTags(ctx, IntegerArgumentType.getInteger(ctx, "page")))))));
    }

    private static int listTags(final CommandContext<ServerCommandSource> ctx, final int page) throws CommandSyntaxException {
        final RegistryKey<? extends Registry<?>> registryKey = CommandUtils.getResourceKey(ctx, "registry", ROOT_REGISTRY_KEY)
                .orElseThrow(); // Expect to always retrieve a resource key for the root registry (registry key)
        final Registry<?> registry = ctx.getSource().getServer().getRegistryManager().getOptional(registryKey)
                .orElseThrow(() -> UNKNOWN_REGISTRY.create(registryKey.getValue()));

        final long tagCount = registry.streamTagsAndEntries().count();

        ctx.getSource().sendFeedback(() -> createMessage(
                CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.registry_key", Text.literal(registryKey.getValue().toString()).formatted(Formatting.GOLD)),
                "commands.neoforge.tags.tag_count",
                "commands.neoforge.tags.copy_tag_names",
                tagCount,
                page,
                Formatting.DARK_GREEN,
                () -> registry.streamTagsAndEntries()
                        .map(Pair::getSecond)
                        .map(s -> s.getStorage().map(k -> k.id().toString(), Object::toString))),
                false);

        return (int) tagCount;
    }

    private static int listTagElements(final CommandContext<ServerCommandSource> ctx, final int page) throws CommandSyntaxException {
        final RegistryKey<? extends Registry<?>> registryKey = CommandUtils.getResourceKey(ctx, "registry", ROOT_REGISTRY_KEY)
                .orElseThrow(); // Expect to always retrieve a resource key for the root registry (registry key)
        final Registry<?> registry = ctx.getSource().getServer().getRegistryManager().getOptional(registryKey)
                .orElseThrow(() -> UNKNOWN_REGISTRY.create(registryKey.getValue()));

        final Identifier tagLocation = IdentifierArgumentType.getIdentifier(ctx, "tag");
        final TagKey<?> tagKey = TagKey.of(cast(registryKey), tagLocation);

        final RegistryEntryList.Named<?> tag = registry.getEntryList(cast(tagKey))
                .orElseThrow(() -> UNKNOWN_TAG.create(tagKey.id(), registryKey.getValue()));

        ctx.getSource().sendFeedback(() -> createMessage(
                CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.tag_key",
                        Text.literal(tagKey.registry().getValue().toString()).formatted(Formatting.GOLD),
                        Text.literal(tagKey.id().toString()).formatted(Formatting.DARK_GREEN)),
                "commands.neoforge.tags.element_count",
                "commands.neoforge.tags.copy_element_names",
                tag.size(),
                page,
                Formatting.YELLOW,
                () -> tag.stream().map(s -> s.getKeyOrValue().map(k -> k.getValue().toString(), Object::toString))), false);

        return tag.size();
    }

    private static int queryElementTags(final CommandContext<ServerCommandSource> ctx, final int page) throws CommandSyntaxException {
        final RegistryKey<? extends Registry<?>> registryKey = CommandUtils.getResourceKey(ctx, "registry", ROOT_REGISTRY_KEY)
                .orElseThrow(); // Expect to always retrieve a resource key for the root registry (registry key)
        final Registry<?> registry = ctx.getSource().getServer().getRegistryManager().getOptional(registryKey)
                .orElseThrow(() -> UNKNOWN_REGISTRY.create(registryKey.getValue()));

        final Identifier elementLocation = IdentifierArgumentType.getIdentifier(ctx, "element");
        final RegistryKey<?> elementKey = RegistryKey.of(cast(registryKey), elementLocation);

        @SuppressWarnings({ "unchecked", "rawtypes" })
        final Optional<RegistryEntry<?>> elementHolderOpt = registry.getEntry(TagsCommand.<RegistryKey>cast(elementKey));
        final RegistryEntry<?> elementHolder = elementHolderOpt.orElseThrow(() -> UNKNOWN_ELEMENT.create(elementLocation, registryKey.getValue()));

        final long containingTagsCount = elementHolder.streamTags().count();

        ctx.getSource().sendFeedback(() -> createMessage(
                CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.element",
                        Text.literal(registryKey.getValue().toString()).formatted(Formatting.GOLD),
                        Text.literal(elementLocation.toString()).formatted(Formatting.YELLOW)),
                "commands.neoforge.tags.containing_tag_count",
                "commands.neoforge.tags.copy_tag_names",
                containingTagsCount,
                page,
                Formatting.DARK_GREEN,
                () -> elementHolder.streamTags().map(k -> k.id().toString())), false);

        return (int) containingTagsCount;
    }

    private static MutableText createMessage(final MutableText header,
            final String containsText,
            final String copyHoverText,
            final long count,
            final long currentPage,
            final Formatting elementColor,
            final Supplier<Stream<String>> names) {
        final String allElementNames = names.get().sorted().collect(Collectors.joining("\n"));
        final long totalPages = (count - 1) / PAGE_SIZE + 1;
        final long actualPage = (long) MathHelper.clamp(currentPage, 1, totalPages);

        MutableText containsComponent = CommandUtils.makeTranslatableWithFallback(containsText, count);
        if (count > 0) // Highlight the count text, make it clickable, and append page counters
        {
            containsComponent = Texts.bracketed(containsComponent.styled(s -> s
                    .withColor(Formatting.GREEN)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, allElementNames))
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                            CommandUtils.makeTranslatableWithFallback(copyHoverText)))));
            containsComponent = CommandUtils.makeTranslatableWithFallback("commands.neoforge.tags.page_info",
                    containsComponent, actualPage, totalPages);
        }

        final MutableText tagElements = Text.literal("").append(containsComponent);
        names.get()
                .sorted()
                .skip(PAGE_SIZE * (actualPage - 1))
                .limit(PAGE_SIZE)
                .map(Text::literal)
                .map(t -> t.formatted(elementColor))
                .map(t -> CommandUtils.makeTranslatableWithFallback("\n - ").append(t))
                .forEach(tagElements::append);

        return header.append("\n").append(tagElements);
    }

    @SuppressWarnings("unchecked")
    private static <O> O cast(final Object input) {
        return (O) input;
    }
}
