/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.List;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import org.jetbrains.annotations.ApiStatus;

/**
 * Packet payload sent to the client to start the frozen registry sync.
 * <p>
 * It indicates to the client which registries it should expect to receive.
 * </p>
 * 
 * @param toAccess The registries to access.
 */
@ApiStatus.Internal
public record FrozenRegistrySyncStartPayload(List<Identifier> toAccess) implements CustomPayload {
    public static final Id<FrozenRegistrySyncStartPayload> TYPE = new Id<>(Identifier.of(NeoForgeVersion.MOD_ID, "frozen_registry_sync_start"));
    public static final PacketCodec<PacketByteBuf, FrozenRegistrySyncStartPayload> STREAM_CODEC = PacketCodec.tuple(
            Identifier.PACKET_CODEC.collect(PacketCodecs.toList()),
            FrozenRegistrySyncStartPayload::toAccess,
            FrozenRegistrySyncStartPayload::new);

    @Override
    public Id<FrozenRegistrySyncStartPayload> getId() {
        return TYPE;
    }
}
