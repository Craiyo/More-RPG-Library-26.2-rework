/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.world.BiomeColors;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfigs;
import net.neoforged.neoforge.client.entity.animation.json.AnimationLoader;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterNamedRenderTypesEvent;
import net.neoforged.neoforge.client.event.RegisterSpriteSourceTypesEvent;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.client.internal.SelfTestClient;
import net.neoforged.neoforge.client.model.CompositeModel;
import net.neoforged.neoforge.client.model.DynamicFluidContainerModel;
import net.neoforged.neoforge.client.model.ElementsModel;
import net.neoforged.neoforge.client.model.EmptyModel;
import net.neoforged.neoforge.client.model.ItemLayerModel;
import net.neoforged.neoforge.client.model.SeparateTransformsModel;
import net.neoforged.neoforge.client.model.obj.ObjLoader;
import net.neoforged.neoforge.client.textures.NamespacedDirectoryLister;
import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@Mod(value = "neoforge", dist = Dist.CLIENT)
public class ClientNeoForgeMod {
    public ClientNeoForgeMod(IEventBus modEventBus, ModContainer container) {
        SelfTestClient.initClient();

        ClientCommandHandler.init();
        TagConventionLogWarningClient.init();

        modEventBus.register(ClientNeoForgeMod.class);

        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);

        // Reset WORLD type config caches
        NeoForge.EVENT_BUS.addListener((final ClientPlayerNetworkEvent.LoggingOut event) -> {
            ModConfigs.getFileMap().values().forEach(config -> {
                if (config.getSpec() instanceof ModConfigSpec spec) {
                    spec.resetCaches(ModConfigSpec.RestartType.WORLD);
                }
            });
        });
    }

    @SubscribeEvent
    static void onRegisterGeometryLoaders(ModelEvent.RegisterGeometryLoaders event) {
        event.register(Identifier.of("neoforge", "empty"), EmptyModel.LOADER);
        event.register(Identifier.of("neoforge", "elements"), ElementsModel.Loader.INSTANCE);
        event.register(Identifier.of("neoforge", "obj"), ObjLoader.INSTANCE);
        event.register(Identifier.of("neoforge", "fluid_container"), DynamicFluidContainerModel.Loader.INSTANCE);
        event.register(Identifier.of("neoforge", "composite"), CompositeModel.Loader.INSTANCE);
        event.register(Identifier.of("neoforge", "item_layers"), ItemLayerModel.Loader.INSTANCE);
        event.register(Identifier.of("neoforge", "separate_transforms"), SeparateTransformsModel.Loader.INSTANCE);
    }

    @SubscribeEvent
    static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
        event.registerReloadListener(ObjLoader.INSTANCE);
        event.registerReloadListener(AnimationLoader.INSTANCE);
    }

    @SubscribeEvent
    static void onRegisterNamedRenderTypes(RegisterNamedRenderTypesEvent event) {
        event.register(Identifier.of("neoforge", "item_unlit"), RenderLayer.getTranslucent(), NeoForgeRenderTypes.ITEM_UNSORTED_UNLIT_TRANSLUCENT.get());
    }

    @SubscribeEvent
    static void onRegisterSpriteSourceTypes(RegisterSpriteSourceTypesEvent event) {
        event.register(NamespacedDirectoryLister.ID, NamespacedDirectoryLister.TYPE);
    }

    @SubscribeEvent
    static void onRegisterClientExtensions(RegisterClientExtensionsEvent event) {
        event.registerFluidType(new IClientFluidTypeExtensions() {
            private static final Identifier UNDERWATER_LOCATION = Identifier.ofVanilla("textures/misc/underwater.png");
            private static final Identifier WATER_STILL = Identifier.ofVanilla("block/water_still");
            private static final Identifier WATER_FLOW = Identifier.ofVanilla("block/water_flow");
            private static final Identifier WATER_OVERLAY = Identifier.ofVanilla("block/water_overlay");

            @Override
            public Identifier getStillTexture() {
                return WATER_STILL;
            }

            @Override
            public Identifier getFlowingTexture() {
                return WATER_FLOW;
            }

            @Override
            public Identifier getOverlayTexture() {
                return WATER_OVERLAY;
            }

            @Override
            public Identifier getRenderOverlayTexture(MinecraftClient mc) {
                return UNDERWATER_LOCATION;
            }

            @Override
            public int getTintColor() {
                return 0xFF3F76E4;
            }

            @Override
            public int getTintColor(FluidState state, BlockRenderView getter, BlockPos pos) {
                return BiomeColors.getWaterColor(getter, pos) | 0xFF000000;
            }
        }, NeoForgeMod.WATER_TYPE.value());

        event.registerFluidType(new IClientFluidTypeExtensions() {
            private static final Identifier LAVA_STILL = Identifier.ofVanilla("block/lava_still");
            private static final Identifier LAVA_FLOW = Identifier.ofVanilla("block/lava_flow");

            @Override
            public Identifier getStillTexture() {
                return LAVA_STILL;
            }

            @Override
            public Identifier getFlowingTexture() {
                return LAVA_FLOW;
            }
        }, NeoForgeMod.LAVA_TYPE.value());

        NeoForgeMod.MILK_TYPE.asOptional().ifPresent(milkType -> event.registerFluidType(new IClientFluidTypeExtensions() {
            private static final Identifier MILK_STILL = Identifier.of(NeoForgeVersion.MOD_ID, "block/milk_still");
            private static final Identifier MILK_FLOW = Identifier.of(NeoForgeVersion.MOD_ID, "block/milk_flowing");

            @Override
            public Identifier getStillTexture() {
                return MILK_STILL;
            }

            @Override
            public Identifier getFlowingTexture() {
                return MILK_FLOW;
            }
        }, milkType));
    }
}
