/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui;

import net.minecraft.client.gui.LayeredDrawer;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.Identifier;

/**
 * Identifiers for the vanilla {@link LayeredDrawer.Layer}, in the order that they render.
 *
 * <p>The corresponding rendering code can be found in the source code of {@link InGameHud}.
 */
public final class VanillaGuiLayers {
    public static final Identifier CAMERA_OVERLAYS = Identifier.ofVanilla("camera_overlays");
    public static final Identifier CROSSHAIR = Identifier.ofVanilla("crosshair");
    public static final Identifier HOTBAR = Identifier.ofVanilla("hotbar");
    public static final Identifier JUMP_METER = Identifier.ofVanilla("jump_meter");
    public static final Identifier EXPERIENCE_BAR = Identifier.ofVanilla("experience_bar");
    public static final Identifier PLAYER_HEALTH = Identifier.ofVanilla("player_health");
    public static final Identifier ARMOR_LEVEL = Identifier.ofVanilla("armor_level");
    public static final Identifier FOOD_LEVEL = Identifier.ofVanilla("food_level");
    public static final Identifier VEHICLE_HEALTH = Identifier.ofVanilla("vehicle_health");
    public static final Identifier AIR_LEVEL = Identifier.ofVanilla("air_level");
    public static final Identifier SELECTED_ITEM_NAME = Identifier.ofVanilla("selected_item_name");
    public static final Identifier SPECTATOR_TOOLTIP = Identifier.ofVanilla("spectator_tooltip");
    public static final Identifier EXPERIENCE_LEVEL = Identifier.ofVanilla("experience_level");
    public static final Identifier EFFECTS = Identifier.ofVanilla("effects");
    public static final Identifier BOSS_OVERLAY = Identifier.ofVanilla("boss_overlay");
    public static final Identifier SLEEP_OVERLAY = Identifier.ofVanilla("sleep_overlay");
    public static final Identifier DEMO_OVERLAY = Identifier.ofVanilla("demo_overlay");
    public static final Identifier DEBUG_OVERLAY = Identifier.ofVanilla("debug_overlay");
    public static final Identifier SCOREBOARD_SIDEBAR = Identifier.ofVanilla("scoreboard_sidebar");
    public static final Identifier OVERLAY_MESSAGE = Identifier.ofVanilla("overlay_message");
    public static final Identifier TITLE = Identifier.ofVanilla("title");
    public static final Identifier CHAT = Identifier.ofVanilla("chat");
    public static final Identifier TAB_LIST = Identifier.ofVanilla("tab_list");
    public static final Identifier SUBTITLE_OVERLAY = Identifier.ofVanilla("subtitle_overlay");
    public static final Identifier SAVING_INDICATOR = Identifier.ofVanilla("saving_indicator");
}
