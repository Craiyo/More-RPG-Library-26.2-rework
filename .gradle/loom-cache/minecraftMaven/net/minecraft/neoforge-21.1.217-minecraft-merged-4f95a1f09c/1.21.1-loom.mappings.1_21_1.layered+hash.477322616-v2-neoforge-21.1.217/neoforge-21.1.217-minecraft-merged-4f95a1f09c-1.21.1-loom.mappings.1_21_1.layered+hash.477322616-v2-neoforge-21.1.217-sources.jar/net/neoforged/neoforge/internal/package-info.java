/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

@ApiStatus.Internal
@FieldsAreNonnullByDefault
@MethodsReturnNonnullByDefault
@ParametersAreNonnullByDefault
package net.neoforged.neoforge.internal;

import javax.annotation.ParametersAreNonnullByDefault;
import org.jetbrains.annotations.ApiStatus;
