/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.listener.ClientCommonPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.text.Text;
import net.minecraft.util.thread.ReentrantThreadExecutor;

/**
 * Extension interface for {@link ClientCommonPacketListener}
 */
public interface IClientCommonPacketListenerExtension extends ICommonPacketListener {
    /**
     * {@inheritDoc}
     */
    @Override
    default void send(CustomPayload payload) {
        this.send(new CustomPayloadC2SPacket(payload));
    }

    /**
     * {@inheritDoc}
     */
    @Override
    default void disconnect(Text reason) {
        this.getConnection().disconnect(reason);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    default ReentrantThreadExecutor<?> getMainThreadEventLoop() {
        return MinecraftClient.getInstance();
    }
}
