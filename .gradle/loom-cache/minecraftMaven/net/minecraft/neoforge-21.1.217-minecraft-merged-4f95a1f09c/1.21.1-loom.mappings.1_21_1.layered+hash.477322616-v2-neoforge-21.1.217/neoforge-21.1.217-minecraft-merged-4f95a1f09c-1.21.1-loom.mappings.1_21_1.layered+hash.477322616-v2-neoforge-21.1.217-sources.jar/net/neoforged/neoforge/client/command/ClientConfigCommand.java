/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.io.File;
import java.util.List;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.config.ModConfigs;
import net.neoforged.neoforge.server.command.ModIdArgument;

public class ClientConfigCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("config").then(ShowFile.register()));
    }

    public static class ShowFile {
        static ArgumentBuilder<ServerCommandSource, ?> register() {
            return CommandManager.literal("showfileclient").requires(cs -> cs.hasPermissionLevel(0)).then(CommandManager.argument("mod", ModIdArgument.modIdArgument()).executes(ShowFile::showFile));
        }

        private static int showFile(final CommandContext<ServerCommandSource> context) {
            final String modId = context.getArgument("mod", String.class);
            final ModConfig.Type type = ModConfig.Type.CLIENT;
            var configFileNames = ModConfigs.getConfigFileNames(modId, type);
            for (var configFileName : configFileNames) {
                File f = new File(configFileName);
                MutableText fileComponent = Text.literal(f.getName()).formatted(Formatting.UNDERLINE)
                        .styled((style) -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, f.getAbsolutePath())));

                context.getSource().sendFeedback(() -> Text.translatable("commands.config.getwithtype",
                        modId, type.toString(), fileComponent), true);
            }
            if (configFileNames.isEmpty()) {
                context.getSource().sendFeedback(() -> Text.translatable("commands.config.noconfig", modId, type.toString()),
                        true);
            }
            return 0;
        }
    }
}
