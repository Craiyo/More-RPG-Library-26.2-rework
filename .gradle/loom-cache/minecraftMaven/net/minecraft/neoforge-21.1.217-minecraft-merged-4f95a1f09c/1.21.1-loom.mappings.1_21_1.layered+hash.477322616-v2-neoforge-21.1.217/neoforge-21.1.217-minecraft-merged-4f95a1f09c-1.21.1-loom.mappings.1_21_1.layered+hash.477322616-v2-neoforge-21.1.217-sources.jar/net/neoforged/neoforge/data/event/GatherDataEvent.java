/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.data.event;

import com.google.common.collect.Lists;
import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.MinecraftVersion;
import net.minecraft.block.Block;
import net.minecraft.client.resource.DefaultClientResourcePackProvider;
import net.minecraft.client.resource.ResourceIndex;
import net.minecraft.data.DataGenerator;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryBuilder;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.DirectoryResourcePack;
import net.minecraft.resource.LifecycledResourceManagerImpl;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourcePackInfo;
import net.minecraft.resource.ResourcePackSource;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.VanillaDataPackProvider;
import net.minecraft.text.Text;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.event.IModBusEvent;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.data.DatapackBuiltinEntriesProvider;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.neoforged.neoforge.resource.ResourcePackLoader;
import net.neoforged.neoforgespi.language.IModFileInfo;
import org.apache.commons.lang3.function.Consumers;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public class GatherDataEvent extends Event implements IModBusEvent {
    private final DataGenerator dataGenerator;
    private final DataGeneratorConfig config;
    private final ExistingFileHelper existingFileHelper;
    private final ModContainer modContainer;

    @Nullable
    private CompletableFuture<RegistryWrapper.WrapperLookup> registriesWithModdedEntries = null;

    public GatherDataEvent(final ModContainer mc, final DataGenerator dataGenerator, final DataGeneratorConfig dataGeneratorConfig, final ExistingFileHelper existingFileHelper) {
        this.modContainer = mc;
        this.dataGenerator = dataGenerator;
        this.config = dataGeneratorConfig;
        this.existingFileHelper = existingFileHelper;
    }

    public ModContainer getModContainer() {
        return this.modContainer;
    }

    public ResourceManager getResourceManager(ResourceType packType) {
        return switch (packType) {
            case CLIENT_RESOURCES -> config.clientResourceManager;
            case SERVER_DATA -> config.serverResourceManager;
        };
    }

    public Collection<Path> getInputs() {
        return this.config.getInputs();
    }

    /**
     * @return the mod IDs for which data should be generated
     */
    public Set<String> getMods() {
        return this.config.getMods();
    }

    public DataGenerator getGenerator() {
        return this.dataGenerator;
    }

    public ExistingFileHelper getExistingFileHelper() {
        return existingFileHelper;
    }

    public CompletableFuture<RegistryWrapper.WrapperLookup> getLookupProvider() {
        return Objects.requireNonNullElse(this.registriesWithModdedEntries, this.config.lookupProvider);
    }

    public boolean includeServer() {
        return this.config.server;
    }

    public boolean includeClient() {
        return this.config.client;
    }

    public boolean includeDev() {
        return this.config.dev;
    }

    public boolean includeReports() {
        return this.config.reports;
    }

    public boolean validate() {
        return this.config.validate;
    }

    @ApiStatus.Internal
    public static class DataGeneratorConfig {
        private final Set<String> mods;
        private final Path path;
        private final Collection<Path> inputs;
        private final CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider;
        private final boolean server;
        private final boolean client;
        private final boolean dev;
        private final boolean reports;
        private final boolean validate;
        private final boolean flat;
        private final List<DataGenerator> generators = new ArrayList<>();
        private final ResourceManager clientResourceManager;
        private final ResourceManager serverResourceManager;

        @Deprecated(forRemoval = true)
        public DataGeneratorConfig(final Set<String> mods, final Path path, final Collection<Path> inputs, final CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider,
                final boolean server, final boolean client, final boolean dev, final boolean reports, final boolean validate, final boolean flat) {
            this(mods, path, inputs, lookupProvider, server, client, dev, reports, validate, flat, null, null, List.of());
        }

        public DataGeneratorConfig(final Set<String> mods, final Path path, final Collection<Path> inputs, final CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider,
                final boolean server, final boolean client, final boolean dev, final boolean reports, final boolean validate, final boolean flat, final @Nullable String assetIndex, final @Nullable File assetsDir, Collection<Path> existingPacks) {
            this.mods = mods;
            this.path = path;
            this.inputs = inputs;
            this.lookupProvider = lookupProvider;
            this.server = server;
            this.client = client;
            this.dev = dev;
            this.reports = reports;
            this.validate = validate;
            this.flat = flat;

            clientResourceManager = createResourceManager(ResourceType.CLIENT_RESOURCES, mods::contains, existingPacks, consumer -> {
                if (FMLEnvironment.dist.isClient() && assetIndex != null && assetsDir != null)
                    consumer.accept(DefaultClientResourcePackProvider.createDefaultPack(ResourceIndex.buildFileSystem(assetsDir.toPath(), assetIndex)));
            });

            serverResourceManager = createResourceManager(ResourceType.SERVER_DATA, mods::contains, existingPacks, consumer -> consumer.accept(VanillaDataPackProvider.createDefaultPack()));
        }

        public Collection<Path> getInputs() {
            return this.inputs;
        }

        public Set<String> getMods() {
            return mods;
        }

        public boolean isFlat() {
            return flat || getMods().size() == 1;
        }

        public DataGenerator makeGenerator(final Function<Path, Path> pathEnhancer, final boolean shouldExecute) {
            final DataGenerator generator = new DataGenerator(pathEnhancer.apply(path), MinecraftVersion.create(), shouldExecute);
            if (shouldExecute)
                generators.add(generator);
            return generator;
        }

        public void runAll() {
            Map<Path, List<DataGenerator>> paths = generators.stream().collect(Collectors.groupingBy(gen -> gen.getPackOutput().getPath(), LinkedHashMap::new, Collectors.toList()));

            paths.values().forEach(lst -> {
                DataGenerator parent = lst.get(0);
                for (int x = 1; x < lst.size(); x++)
                    parent.merge(lst.get(x));
                try {
                    parent.run();
                } catch (IOException ex) {
                    throw new UncheckedIOException(ex);
                }
            });
        }

        private static ResourceManager createResourceManager(ResourceType packType, Predicate<String> isGeneratedMod, Collection<Path> existingPacks, Consumer<Consumer<ResourcePack>> consumer) {
            var packs = Lists.<ResourcePack>newArrayList();
            // include vanilla resource packs first
            consumer.accept(packs::add);

            // include existing packs
            existingPacks.forEach(path -> {
                var packInfo = new ResourcePackInfo(path.getFileName().toString(), Text.empty(), ResourcePackSource.BUILTIN, Optional.empty());
                packs.add(new DirectoryResourcePack(packInfo, path));
            });

            // include mod resources last
            ModList.get().getSortedMods().stream()
                    // ignore 'minecraft' mod, this is added via `[Server|Client]PackSource`
                    .filter(Predicate.not(mod -> mod.getModId().equals("minecraft")))
                    // ignore actively generated models, their resource packs should be included using `--existing <packPath>`
                    // this is to workaround accidentally including resources being actively generated
                    .filter(Predicate.not(mod -> isGeneratedMod.test(mod.getModId())))
                    .map(mod -> {
                        var owningFile = mod.getModInfo().getOwningFile();
                        var packInfo = new ResourcePackInfo("mod/" + mod.getModId(), Text.empty(), ResourcePackSource.BUILTIN, Optional.empty());
                        return ResourcePackLoader.createPackForMod(owningFile).open(packInfo);
                    })
                    .forEach(packs::add);

            return new LifecycledResourceManagerImpl(packType, packs);
        }
    }

    public <T extends DataProvider> T addProvider(T provider) {
        return dataGenerator.addProvider(true, provider);
    }

    public <T extends DataProvider> T createProvider(DataProviderFromOutput<T> builder) {
        return addProvider(builder.create(dataGenerator.getPackOutput()));
    }

    public <T extends DataProvider> T createProvider(DataProviderFromOutputLookup<T> builder) {
        return addProvider(builder.create(dataGenerator.getPackOutput(), this.getLookupProvider()));
    }

    public void createBlockAndItemTags(DataProviderFromOutputLookup<TagProvider<Block>> blockTagsProvider, ItemTagsProvider itemTagsProvider) {
        var blockTags = createProvider(blockTagsProvider);
        addProvider(itemTagsProvider.create(this.getGenerator().getPackOutput(), this.getLookupProvider(), blockTags.getTagLookupFuture()));
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder) {
        this.createDatapackRegistryObjects(datapackEntriesBuilder, Set.of(this.modContainer.getModId()));
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder, Set<String> modIds) {
        this.createDatapackRegistryObjects(datapackEntriesBuilder, Consumers.nop(), modIds);
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder, Map<RegistryKey<?>, List<ICondition>> conditions) {
        this.createDatapackRegistryObjects(datapackEntriesBuilder, conditions, Set.of(this.modContainer.getModId()));
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder, Map<RegistryKey<?>, List<ICondition>> conditions, Set<String> modIds) {
        var registries = this.createProvider((output, lookupProvider) -> new DatapackBuiltinEntriesProvider(output, lookupProvider, datapackEntriesBuilder, conditions, modIds));
        this.registriesWithModdedEntries = registries.getRegistryProvider();
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder, Consumer<BiConsumer<RegistryKey<?>, ICondition>> conditionsBuilder) {
        this.createDatapackRegistryObjects(datapackEntriesBuilder, conditionsBuilder, Set.of(this.modContainer.getModId()));
    }

    public void createDatapackRegistryObjects(RegistryBuilder datapackEntriesBuilder, Consumer<BiConsumer<RegistryKey<?>, ICondition>> conditionsBuilder, Set<String> modIds) {
        var registries = this.createProvider((output, lookupProvider) -> new DatapackBuiltinEntriesProvider(output, lookupProvider, datapackEntriesBuilder, conditionsBuilder, modIds));
        this.registriesWithModdedEntries = registries.getRegistryProvider();
    }

    @FunctionalInterface
    public interface DataProviderFromOutput<T extends DataProvider> {
        T create(DataOutput output);
    }

    @FunctionalInterface
    public interface DataProviderFromOutputLookup<T extends DataProvider> {
        T create(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider);
    }

    @FunctionalInterface
    public interface GatherDataEventGenerator {
        GatherDataEvent create(final ModContainer mc, final DataGenerator dataGenerator, final DataGeneratorConfig dataGeneratorConfig);
    }

    @FunctionalInterface
    public interface ItemTagsProvider {
        TagProvider<Item> create(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider, CompletableFuture<TagProvider.TagLookup<Block>> contentsGetter);
    }
}
