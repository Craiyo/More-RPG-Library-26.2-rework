/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.BoolArgumentType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.server.command.CommandManager;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;

@EventBusSubscriber(value = Dist.CLIENT, modid = NeoForgeVersion.MOD_ID)
public final class ParticleBoundsDebugRenderer {
    private static boolean enabled = false;

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (!enabled || event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) {
            return;
        }

        var camPos = event.getCamera().getPos();

        MatrixStack poseStack = event.getPoseStack();
        poseStack.push();

        VertexConsumer consumer = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getLines());

        MinecraftClient.getInstance().particleManager.iterateParticles(particle -> {
            var bb = particle.getRenderBoundingBox(event.getPartialTick().getTickDelta(false));
            if (!bb.isInfinite() && event.getFrustum().isVisible(bb)) {
                poseStack.push();
                var offset = particle.getPos().subtract(camPos);
                poseStack.translate(offset.x, offset.y, offset.z);
                bb = bb.offset(-particle.getPos().x, -particle.getPos().y, -particle.getPos().z);
                WorldRenderer.drawBox(poseStack, consumer, bb, 1F, 0F, 0F, 1F);
                poseStack.pop();
            }
        });

        MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers().draw(RenderLayer.getLines());

        poseStack.pop();
    }

    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(
                CommandManager.literal("neoforge")
                        .then(CommandManager.literal("debug_particle_renderbounds")
                                .requires(src -> src.hasPermissionLevel(CommandManager.field_31840))
                                .then(CommandManager.argument("enable", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            enabled = BoolArgumentType.getBool(ctx, "enable");
                                            return Command.SINGLE_SUCCESS;
                                        }))));
    }

    private ParticleBoundsDebugRenderer() {}
}
