/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.recipebook.RecipeBookGroup;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.book.RecipeBookCategory;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.fml.event.IModBusEvent;
import org.jetbrains.annotations.ApiStatus;

/**
 * Allows users to register custom categories for the vanilla recipe book, making it usable in modded GUIs.
 *
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.
 *
 * <p>This event is fired on the mod-specific event bus, only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 */
public class RegisterRecipeBookCategoriesEvent extends Event implements IModBusEvent {
    private final Map<RecipeBookGroup, ImmutableList<RecipeBookGroup>> aggregateCategories;
    private final Map<RecipeBookCategory, ImmutableList<RecipeBookGroup>> typeCategories;
    private final Map<RecipeType<?>, Function<RecipeEntry<?>, RecipeBookGroup>> recipeCategoryLookups;

    @ApiStatus.Internal
    public RegisterRecipeBookCategoriesEvent(
            Map<RecipeBookGroup, ImmutableList<RecipeBookGroup>> aggregateCategories,
            Map<RecipeBookCategory, ImmutableList<RecipeBookGroup>> typeCategories,
            Map<RecipeType<?>, Function<RecipeEntry<?>, RecipeBookGroup>> recipeCategoryLookups) {
        this.aggregateCategories = aggregateCategories;
        this.typeCategories = typeCategories;
        this.recipeCategoryLookups = recipeCategoryLookups;
    }

    /**
     * Registers the list of categories that compose an aggregate category.
     */
    public void registerAggregateCategory(RecipeBookGroup category, List<RecipeBookGroup> others) {
        aggregateCategories.put(category, ImmutableList.copyOf(others));
    }

    /**
     * Registers the list of categories that compose a recipe book.
     */
    public void registerBookCategories(RecipeBookCategory type, List<RecipeBookGroup> categories) {
        typeCategories.put(type, ImmutableList.copyOf(categories));
    }

    /**
     * Registers a category lookup for a certain recipe type.
     */
    public void registerRecipeCategoryFinder(RecipeType<?> type, Function<RecipeEntry<?>, RecipeBookGroup> lookup) {
        recipeCategoryLookups.put(type, lookup);
    }
}
