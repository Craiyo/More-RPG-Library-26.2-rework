/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.util;

import java.io.File;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.world.PersistentState;

/**
 * A no-op {@link PersistentState} implementation which does not store data.
 * 
 * @deprecated This type often causes more data corruption than is worth.
 */
@Deprecated(since = "1.21.1", forRemoval = true)
public class DummySavedData extends PersistentState {
    public static final DummySavedData DUMMY = new DummySavedData();

    private DummySavedData() {
        super();
    }

    @Override
    public NbtCompound writeNbt(final NbtCompound compound, RegistryWrapper.WrapperLookup provider) {
        // NOOP
        return null;
    }

    @Override
    public void save(final File file, final RegistryWrapper.WrapperLookup provider) {
        // Do nothing, because we don't want to overwrite the saved data
        // that may already be here.
    }
}
