/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.Optional;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

/**
 * Represents a modded network component, indicates what channel and version the client and server
 * agreed upon.
 *
 * @param id      The mod id
 * @param version The mod version, if present
 */
@ApiStatus.Internal
public record ModdedNetworkComponent(Identifier id, Optional<String> version) {
    public static final PacketCodec<PacketByteBuf, ModdedNetworkComponent> STREAM_CODEC = PacketCodec.tuple(
            Identifier.PACKET_CODEC,
            ModdedNetworkComponent::id,
            PacketCodecs.optional(PacketCodecs.STRING),
            ModdedNetworkComponent::version,
            ModdedNetworkComponent::new);
}
