/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity;

import com.google.common.collect.ImmutableList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.DefaultAttributeRegistry;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.event.IModBusEvent;

/**
 * EntityAttributeModificationEvent.<br>
 * Use this event to add attributes to existing entity types.
 * This event is fired after registration and before common setup, and after {@link EntityAttributeCreationEvent}
 * <br>
 * Fired on the Mod bus {@link IModBusEvent}.<br>
 **/
public class EntityAttributeModificationEvent extends Event implements IModBusEvent {
    private final Map<EntityType<? extends LivingEntity>, DefaultAttributeContainer.Builder> entityAttributes;
    private final List<EntityType<? extends LivingEntity>> entityTypes;

    @SuppressWarnings("unchecked")
    public EntityAttributeModificationEvent(Map<EntityType<? extends LivingEntity>, DefaultAttributeContainer.Builder> mapIn) {
        this.entityAttributes = mapIn;
        this.entityTypes = ImmutableList.copyOf(
                Registries.ENTITY_TYPE.stream()
                        .filter(DefaultAttributeRegistry::hasDefinitionFor)
                        .map(entityType -> (EntityType<? extends LivingEntity>) entityType)
                        .collect(Collectors.toList()));
    }

    public void add(EntityType<? extends LivingEntity> entityType, RegistryEntry<EntityAttribute> attribute, double value) {
        DefaultAttributeContainer.Builder attributes = entityAttributes.computeIfAbsent(entityType,
                (type) -> new DefaultAttributeContainer.Builder());
        attributes.add(attribute, value);
    }

    public void add(EntityType<? extends LivingEntity> entityType, RegistryEntry<EntityAttribute> attribute) {
        add(entityType, attribute, attribute.value().getDefaultValue());
    }

    public boolean has(EntityType<? extends LivingEntity> entityType, RegistryEntry<EntityAttribute> attribute) {
        DefaultAttributeContainer globalMap = DefaultAttributeRegistry.get(entityType);
        return globalMap.has(attribute) || (entityAttributes.get(entityType) != null && entityAttributes.get(entityType).hasAttribute(attribute));
    }

    public List<EntityType<? extends LivingEntity>> getTypes() {
        return entityTypes;
    }
}
