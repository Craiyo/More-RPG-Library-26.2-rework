/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.command;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.function.Predicate;
import net.minecraft.command.EntitySelector;
import net.minecraft.command.EntitySelectorReader;
import net.minecraft.text.Text;

/**
 * Implementations of this interface can be registered using {@link EntitySelectorManager#register}
 */
public interface IEntitySelectorType {
    /**
     * Returns an {@link EntitySelector} based on the given {@link EntitySelectorReader}. <br>
     *
     * Use {@link EntitySelectorReader#getReader} to read extra arguments and {@link EntitySelectorReader#addPredicate(Predicate)} to add the corresponding filters. <br>
     * If the token being parsed does not match the syntax of this selector, this method should throw an appropriate {@link CommandSyntaxException}.
     */
    EntitySelector build(EntitySelectorReader parser) throws CommandSyntaxException;

    /**
     * Returns an {@link Text} containing a short description for this selector type.
     */
    Text getSuggestionTooltip();
}
