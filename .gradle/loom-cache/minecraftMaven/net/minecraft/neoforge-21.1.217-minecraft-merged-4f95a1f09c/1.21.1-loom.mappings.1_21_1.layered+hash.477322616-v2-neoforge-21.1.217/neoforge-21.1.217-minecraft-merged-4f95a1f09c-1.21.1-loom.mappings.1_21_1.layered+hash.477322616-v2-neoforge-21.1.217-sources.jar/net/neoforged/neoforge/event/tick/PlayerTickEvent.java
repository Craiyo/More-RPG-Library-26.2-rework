/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.tick;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

/**
 * Base class of the two player tick events.
 * <p>
 * These events are separate from {@link LivingTickEvent} due to the semantics of player ticks.
 * On the client, players tick from the usual {@link Entity#tick()} method, but on the server, they rely
 * on {@link ServerPlayerEntity#playerTick()} which is called from {@link ServerPlayNetworkHandler#tick()}.
 * <p>
 * Use of these events should only be necessary if you rely on this specific timing.
 * 
 * @see PlayerTickEvent.Pre
 * @see PlayerTickEvent.Post
 */
public abstract class PlayerTickEvent extends PlayerEvent {
    protected PlayerTickEvent(PlayerEntity player) {
        super(player);
    }

    /**
     * {@link PlayerTickEvent.Pre} is fired once per game tick, per player, before the player performs work for the current tick.
     * <p>
     * This event will fire on both the logical server and logical client, for subclasses of {@link PlayerEntity} on their respective sides.
     * <p>
     * As such, be sure to check {@link World#isClient()} before performing any operations.
     */
    public static class Pre extends PlayerTickEvent {
        public Pre(PlayerEntity player) {
            super(player);
        }
    }

    /**
     * {@link PlayerTickEvent.Post} is fired once per game tick, per player, after the player performs work for the current tick.
     * <p>
     * This event will fire on both the logical server and logical client, for subclasses of {@link PlayerEntity} on their respective sides.
     * <p>
     * As such, be sure to check {@link World#isClient()} before performing any operations.
     */
    public static class Post extends PlayerTickEvent {
        public Post(PlayerEntity player) {
            super(player);
        }
    }
}
