/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.WorldChunk;
import net.neoforged.neoforge.client.model.data.ModelData;
import net.neoforged.neoforge.client.model.data.ModelDataManager;
import org.jetbrains.annotations.ApiStatus;

public interface IBlockEntityExtension {
    private BlockEntity self() {
        return (BlockEntity) this;
    }

    /**
     * Called when you receive a TileEntityData packet for the location this
     * TileEntity is currently in. On the client, the NetworkManager will always
     * be the remote server. On the server, it will be whomever is responsible for
     * sending the packet.
     *
     * @param net The NetworkManager the packet originated from
     * @param pkt The data packet
     */
    default void onDataPacket(ClientConnection net, BlockEntityUpdateS2CPacket pkt, RegistryWrapper.WrapperLookup lookupProvider) {
        NbtCompound compoundtag = pkt.getNbt();
        if (!compoundtag.isEmpty()) {
            self().read(compoundtag, lookupProvider);
        }
    }

    /**
     * Called when the chunk's TE update tag, gotten from {@link BlockEntity#toInitialChunkDataNbt(RegistryWrapper.WrapperLookup)}, is received on the client.
     * <p>
     * Used to handle this tag in a special way. By default this simply calls {@link BlockEntity#read(NbtCompound, RegistryWrapper.WrapperLookup)}.
     *
     * @param tag The {@link NbtCompound} sent from {@link BlockEntity#toInitialChunkDataNbt(RegistryWrapper.WrapperLookup)}
     */
    default void handleUpdateTag(NbtCompound tag, RegistryWrapper.WrapperLookup lookupProvider) {
        self().read(tag, lookupProvider);
    }

    /**
     * Gets a {@link NbtCompound} that can be used to store custom data for this block entity.
     * It will be written, and read from disc, so it persists over world saves.
     *
     * @return A compound tag for custom persistent data
     */
    NbtCompound getPersistentData();

    default void onChunkUnloaded() {}

    /**
     * Called when this is first added to the world (by {@link WorldChunk#addBlockEntity(BlockEntity)})
     * or right before the first tick when the chunk is generated or loaded from disk.
     * Override instead of adding {@code if (firstTick)} stuff in update.
     */
    default void onLoad() {
        requestModelDataUpdate();
    }

    /**
     * Requests a refresh for the model data of your TE
     * Call this every time your {@link #getModelData()} changes
     */
    default void requestModelDataUpdate() {
        BlockEntity te = self();
        World level = te.getWorld();
        if (level != null && level.isClient) {
            var modelDataManager = level.getModelDataManager();
            if (modelDataManager != null) {
                modelDataManager.requestRefresh(te);
            }
        }
    }

    /**
     * Allows you to return additional model data.
     * This data can be used to provide additional functionality in your {@link BakedModel}.
     * You need to schedule a refresh of you model data via {@link #requestModelDataUpdate()} if the result of this function changes.
     *
     * <p>This method is always called on the main client thread.
     * 
     * @return Your model data
     */
    default ModelData getModelData() {
        return ModelData.EMPTY;
    }

    /**
     * Returns whether this {@link BlockEntity} has custom outline rendering behavior.
     *
     * @param player the local player currently viewing this {@code BlockEntity}
     * @return {@code true} to enable outline processing
     */
    default boolean hasCustomOutlineRendering(PlayerEntity player) {
        return false;
    }

    /**
     * Notify all listeners that the capabilities at the positions of this block entity might have changed.
     * This includes new capabilities becoming available.
     * <p>
     * This is just a convenience method for {@link World#invalidateCapabilities(BlockPos)}.
     */
    @ApiStatus.NonExtendable
    default void invalidateCapabilities() {
        BlockEntity be = self();
        World level = be.getWorld();
        if (level != null)
            level.invalidateCapabilities(be.getPos());
    }
}
