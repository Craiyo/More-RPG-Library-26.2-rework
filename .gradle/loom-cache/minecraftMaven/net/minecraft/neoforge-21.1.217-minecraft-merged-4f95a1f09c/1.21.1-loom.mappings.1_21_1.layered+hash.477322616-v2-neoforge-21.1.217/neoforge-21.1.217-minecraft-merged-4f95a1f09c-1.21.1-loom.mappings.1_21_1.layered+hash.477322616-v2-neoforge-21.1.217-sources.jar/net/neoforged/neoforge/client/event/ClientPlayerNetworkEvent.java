/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.network.ClientConnection;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Fired for different client connectivity events.
 * See the various subclasses to listen for specific events.
 *
 * <p>These events are fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 *
 * @see LoggingIn
 * @see LoggingOut
 * @see Clone
 **/
public abstract class ClientPlayerNetworkEvent extends Event {
    private final ClientPlayerInteractionManager multiPlayerGameMode;
    private final ClientPlayerEntity player;
    private final ClientConnection connection;

    @ApiStatus.Internal
    protected ClientPlayerNetworkEvent(final ClientPlayerInteractionManager multiPlayerGameMode, final ClientPlayerEntity player, final ClientConnection connection) {
        this.multiPlayerGameMode = multiPlayerGameMode;
        this.player = player;
        this.connection = connection;
    }

    /**
     * {@return the multiplayer game mode controller for the player}
     */
    public ClientPlayerInteractionManager getMultiPlayerGameMode() {
        return multiPlayerGameMode;
    }

    /**
     * {@return the player instance}
     */
    public ClientPlayerEntity getPlayer() {
        return player;
    }

    /**
     * {@return the network connection for the player}
     */
    public ClientConnection getConnection() {
        return connection;
    }

    /**
     * Fired when the client player logs in to the server. The player should be initialized.
     *
     * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
     *
     * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
     * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
     */
    public static class LoggingIn extends ClientPlayerNetworkEvent {
        @ApiStatus.Internal
        public LoggingIn(final ClientPlayerInteractionManager controller, final ClientPlayerEntity player, final ClientConnection networkManager) {
            super(controller, player, networkManager);
        }
    }

    /**
     * Fired when the client player logs out. This event may also fire when a new integrated server is being created.
     *
     * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
     *
     * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
     * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
     */
    @SuppressWarnings("NullableProblems")
    // Shush IntelliJ, we override non-nullables as nullables in this specific event; see later comment
    public static class LoggingOut extends ClientPlayerNetworkEvent {
        @ApiStatus.Internal
        public LoggingOut(@Nullable final ClientPlayerInteractionManager controller, @Nullable final ClientPlayerEntity player, @Nullable final ClientConnection networkManager) {
            //noinspection ConstantConditions we know these are nullable, but we don't want to annotate the super as nullable since this is the only event with nullables
            super(controller, player, networkManager);
        }

        /**
         * {@return the multiplayer game mode controller for the player, may be {@code null}}. This may be {@code null}
         * in certain situations such as the creating a new integrated server (singleplayer world) or connecting to
         * a multiplayer server.
         */
        @Nullable
        @Override
        public ClientPlayerInteractionManager getMultiPlayerGameMode() {
            return super.getMultiPlayerGameMode();
        }

        /**
         * {@return the player instance, may be {@code null}}. This may be {@code null}
         * in certain situations such as the creating a new integrated server (singleplayer world) or connecting to
         * a multiplayer server.
         */
        @Nullable
        @Override
        public ClientPlayerEntity getPlayer() {
            return super.getPlayer();
        }

        /**
         * {@return the network connection for the player, may be {@code null}}. This may be {@code null}
         * in certain situations such as the creating a new integrated server (singleplayer world) or connecting to
         * a multiplayer server.
         */
        @Nullable
        @Override
        public ClientConnection getConnection() {
            return super.getConnection();
        }
    }

    /**
     * Fired when the client player respawns, creating a new player instance to replace the old player instance.
     *
     * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
     *
     * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
     * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
     */
    public static class Clone extends ClientPlayerNetworkEvent {
        private final ClientPlayerEntity oldPlayer;

        @ApiStatus.Internal
        public Clone(final ClientPlayerInteractionManager pc, final ClientPlayerEntity oldPlayer, final ClientPlayerEntity newPlayer, final ClientConnection networkManager) {
            super(pc, newPlayer, networkManager);
            this.oldPlayer = oldPlayer;
        }

        /**
         * {@return the previous player instance}
         */
        public ClientPlayerEntity getOldPlayer() {
            return oldPlayer;
        }

        /**
         * {@return the newly created player instance}
         */
        public ClientPlayerEntity getNewPlayer() {
            return super.getPlayer();
        }

        /**
         * {@return the newly created player instance}
         *
         * @see #getNewPlayer()
         */
        @Override
        public ClientPlayerEntity getPlayer() {
            return super.getPlayer();
        }
    }
}
