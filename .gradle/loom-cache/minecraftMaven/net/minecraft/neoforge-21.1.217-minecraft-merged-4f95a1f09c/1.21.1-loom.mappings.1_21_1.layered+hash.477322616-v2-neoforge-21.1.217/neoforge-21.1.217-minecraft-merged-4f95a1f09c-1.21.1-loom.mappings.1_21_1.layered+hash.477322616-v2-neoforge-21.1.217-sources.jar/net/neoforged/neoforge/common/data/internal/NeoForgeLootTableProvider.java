/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data.internal;

import com.mojang.datafixers.util.Either;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.loottable.LootTableGenerator;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.data.server.loottable.vanilla.VanillaLootTableProviders;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.loot.condition.AllOfLootCondition;
import net.minecraft.loot.condition.AlternativeLootCondition;
import net.minecraft.loot.condition.AnyOfLootCondition;
import net.minecraft.loot.condition.InvertedLootCondition;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.MatchToolLootCondition;
import net.minecraft.loot.entry.AlternativeEntry;
import net.minecraft.loot.entry.CombinedEntry;
import net.minecraft.loot.entry.DynamicEntry;
import net.minecraft.loot.entry.EmptyEntry;
import net.minecraft.loot.entry.GroupEntry;
import net.minecraft.loot.entry.ItemEntry;
import net.minecraft.loot.entry.LeafEntry;
import net.minecraft.loot.entry.LootPoolEntry;
import net.minecraft.loot.entry.LootTableEntry;
import net.minecraft.loot.entry.SequenceEntry;
import net.minecraft.loot.entry.TagEntry;
import net.minecraft.loot.function.LootFunction;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.registry.MutableRegistry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.ErrorReporter;
import net.minecraft.util.Identifier;
import net.neoforged.fml.util.ObfuscationReflectionHelper;
import net.neoforged.neoforge.common.ItemAbilities;
import net.neoforged.neoforge.common.loot.CanItemPerformAbility;
import org.jetbrains.annotations.Nullable;

/**
 * Currently used only for replacing shears item to shears_dig item ability
 */
public final class NeoForgeLootTableProvider extends LootTableProvider {
    private final List<Function<LootCondition, LootCondition.Builder>> conditionReplacers = new ArrayList<>();

    public NeoForgeLootTableProvider(DataOutput packOutput, CompletableFuture<RegistryWrapper.WrapperLookup> provider) {
        super(packOutput, Set.of(), VanillaLootTableProviders.createVanillaProvider(packOutput, provider).getTables(), provider);
    }

    @Override
    protected void validate(MutableRegistry<LootTable> writableregistry, LootTableReporter validationcontext, ErrorReporter.Impl problemreporter$collector) {
        // Do not validate against all registered loot tables
    }

    @Override
    public List<LootTableProvider.LootTypeGenerator> getTables() {
        replaceLootItemCondition(condition -> {
            if (condition instanceof MatchToolLootCondition matchTool && checkMatchTool(matchTool, Items.SHEARS)) {
                return CanItemPerformAbility.canItemPerformAbility(ItemAbilities.SHEARS_DIG);
            }
            return null;
        });
        return super.getTables().stream().map(entry -> {
            // Provides new sub provider with filtering only changed loot tables and replacing condition item to condition tag
            return new LootTableProvider.LootTypeGenerator((provider) -> replaceAndFilterChangesOnly(entry.provider().apply(provider)), entry.paramSet());
        }).collect(Collectors.toList());
    }

    private LootTableGenerator replaceAndFilterChangesOnly(LootTableGenerator subProvider) {
        return (newConsumer) -> subProvider.accept((resourceLocation, builder) -> {
            LootTable.Builder newBuilder = findAndReplaceInLootTableBuilder(builder);
            if (newBuilder != null) {
                newConsumer.accept(resourceLocation, newBuilder);
            }
        });
    }

    private void replaceLootItemCondition(Function<LootCondition, LootCondition.Builder> replacer) {
        conditionReplacers.add(replacer);
    }

    @Nullable
    private LootTable.Builder findAndReplaceInLootTableBuilder(LootTable.Builder builder) {
        LootTable lootTable = builder.build();

        Optional<Identifier> randomSequence = getPrivateValue(LootTable.class, lootTable, "randomSequence");
        List<LootPool> lootPools = getPrivateValue(LootTable.class, lootTable, "pools");
        List<LootFunction> lootItemFunctions = getPrivateValue(LootTable.class, lootTable, "functions");

        boolean found = false;
        LootTable.Builder newBuilder = new LootTable.Builder();
        newBuilder.type(lootTable.getType());
        randomSequence.ifPresent(newBuilder::randomSequenceId);
        for (LootFunction lootItemFunction : lootItemFunctions) {
            newBuilder.apply(() -> lootItemFunction);
        }

        for (LootPool lootPool : lootPools) {
            found |= findAndReplaceInLootPool(lootPool, newBuilder);
        }

        return found ? newBuilder : null;
    }

    private boolean findAndReplaceInLootPool(LootPool lootPool, LootTable.Builder newBuilder) {
        List<LootPoolEntry> lootEntries = getPrivateValue(LootPool.class, lootPool, "entries");
        List<LootCondition> lootConditions = getPrivateValue(LootPool.class, lootPool, "conditions");
        List<LootFunction> lootFunctions = getPrivateValue(LootPool.class, lootPool, "functions");

        LootPool.Builder poolBuilder = new LootPool.Builder();
        poolBuilder.rolls(lootPool.getRolls());
        poolBuilder.bonusRolls(lootPool.getBonusRolls());
        poolBuilder.name(lootPool.getName());
        boolean found = false;

        for (LootPoolEntry lootEntry : lootEntries) {
            found |= findAndReplaceInLootEntry(lootEntry, poolBuilder::with);
        }

        for (LootCondition lootCondition : lootConditions) {
            if (lootCondition instanceof InvertedLootCondition invertedLootItemCondition) {
                LootCondition invLootCondition = invertedLootItemCondition.term();

                Consumer<LootCondition.Builder> consumer = cond -> poolBuilder.conditionally(InvertedLootCondition.builder(cond));
                if (invLootCondition instanceof AlternativeLootCondition compositeLootItemCondition && findAndReplaceInComposite(compositeLootItemCondition, consumer)) {
                    found = true;
                } else {
                    found |= replaceCondition(invLootCondition, consumer);
                }
            } else {
                found |= replaceCondition(lootCondition, poolBuilder::conditionally);
            }
        }

        for (LootFunction lootFunction : lootFunctions) {
            poolBuilder.apply(() -> lootFunction);
        }

        newBuilder.pool(poolBuilder);

        return found;
    }

    private boolean findAndReplaceInParentedLootEntry(CombinedEntry entry, Consumer<LootPoolEntry.Builder<?>> newBuilder) {
        List<LootPoolEntry> lootEntries = getPrivateValue(CombinedEntry.class, entry, "children");

        boolean found = false;
        for (LootPoolEntry lootEntry : lootEntries) {
            found |= findAndReplaceInLootEntry(lootEntry, newBuilder);
        }

        return found;
    }

    private boolean findAndReplaceInLootEntry(LootPoolEntry entry, Consumer<LootPoolEntry.Builder<?>> newBuilder) {
        List<LootCondition> lootConditions = getPrivateValue(LootPoolEntry.class, entry, "conditions");

        boolean found = false;

        LootPoolEntry.Builder<?> builder;
        if (entry instanceof CombinedEntry compositeEntryBase) {
            Consumer<LootPoolEntry.Builder<?>> consumer;
            if (compositeEntryBase instanceof AlternativeEntry) {
                builder = new AlternativeEntry.Builder();
                consumer = builder::alternatively;
            } else if (compositeEntryBase instanceof SequenceEntry) {
                builder = new SequenceEntry.Builder();
                consumer = builder::groupEntry;
            } else if (compositeEntryBase instanceof GroupEntry) {
                builder = new GroupEntry.Builder();
                consumer = builder::sequenceEntry;
            } else {
                throw new IllegalStateException("Unknown CompositeEntryBase type: " + compositeEntryBase.getClass().getName());
            }
            found |= findAndReplaceInParentedLootEntry(compositeEntryBase, consumer);
        } else if (entry instanceof LeafEntry singleton) {
            if (singleton instanceof DynamicEntry dynamicLoot) {
                Identifier name = getPrivateValue(DynamicEntry.class, dynamicLoot, "name");
                builder = DynamicEntry.builder(name);
            } else if (singleton instanceof EmptyEntry) {
                builder = EmptyEntry.builder();
            } else if (singleton instanceof ItemEntry lootItem) {
                RegistryEntry<Item> item = getPrivateValue(ItemEntry.class, lootItem, "item");
                builder = ItemEntry.builder(item.value());
            } else if (singleton instanceof TagEntry tagEntry) {
                TagKey<Item> tag = getPrivateValue(TagEntry.class, tagEntry, "tag");
                boolean expand = getPrivateValue(TagEntry.class, tagEntry, "expand");
                builder = expand ? TagEntry.expandBuilder(tag) : TagEntry.builder(tag);
            } else if (singleton instanceof LootTableEntry reference) {
                Either<RegistryKey<LootTable>, LootTable> contents = getPrivateValue(LootTableEntry.class, reference, "contents");
                builder = contents.map(LootTableEntry::builder, LootTableEntry::builder);
            } else {
                throw new IllegalStateException("Unknown LootPoolSingletonContainer type: " + singleton.getClass().getName());
            }
            int weight = getPrivateValue(LeafEntry.class, singleton, "weight");
            int quality = getPrivateValue(LeafEntry.class, singleton, "quality");
            List<LootFunction> functions = getPrivateValue(LeafEntry.class, singleton, "functions");
            ((LeafEntry.Builder<?>) builder).weight(weight);
            ((LeafEntry.Builder<?>) builder).quality(quality);
            for (LootFunction function : functions) {
                ((LeafEntry.Builder<?>) builder).apply(() -> function);
            }
        } else {
            throw new IllegalStateException("Unknown LootPoolEntryContainer type: " + entry.getClass().getName());
        }

        for (LootCondition lootCondition : lootConditions) {
            if (lootCondition instanceof AlternativeLootCondition composite && findAndReplaceInComposite(composite, builder::conditionally)) {
                found = true;
            } else {
                found |= replaceCondition(lootCondition, builder::conditionally);
            }
        }

        newBuilder.accept(builder);

        return found;
    }

    private boolean findAndReplaceInComposite(AlternativeLootCondition alternative, Consumer<LootCondition.Builder> poolBuilder) {
        List<LootCondition> lootConditions = getPrivateValue(AlternativeLootCondition.class, alternative, "terms");
        AlternativeLootCondition.Builder builder = alternative instanceof AllOfLootCondition ? new AllOfLootCondition.Builder() : alternative instanceof AnyOfLootCondition ? new AnyOfLootCondition.Builder() : null;
        boolean found = false;

        for (LootCondition lootCondition : lootConditions) {
            found |= replaceCondition(lootCondition, builder::add);
        }

        poolBuilder.accept(builder);

        return found;
    }

    private boolean checkMatchTool(MatchToolLootCondition lootCondition, Item expected) {
        return lootCondition
                .predicate()
                .flatMap(ItemPredicate::items)
                .filter(holders -> holders.contains(expected.getRegistryEntry()))
                .isPresent();
    }

    private boolean replaceCondition(LootCondition lootCondition, Consumer<LootCondition.Builder> poolBuilder) {
        for (Function<LootCondition, LootCondition.Builder> conditionReplacer : conditionReplacers) {
            LootCondition.Builder newCondition = conditionReplacer.apply(lootCondition);
            if (newCondition != null) {
                poolBuilder.accept(newCondition);
                return true;
            }
        }
        poolBuilder.accept(() -> lootCondition);
        return false;
    }

    private <T, C> T getPrivateValue(Class<C> clazz, C inst, String name) {
        T value = ObfuscationReflectionHelper.getPrivateValue(clazz, inst, name);
        if (value == null) {
            throw new IllegalStateException(clazz.getName() + " is missing field " + name);
        }
        return value;
    }
}
