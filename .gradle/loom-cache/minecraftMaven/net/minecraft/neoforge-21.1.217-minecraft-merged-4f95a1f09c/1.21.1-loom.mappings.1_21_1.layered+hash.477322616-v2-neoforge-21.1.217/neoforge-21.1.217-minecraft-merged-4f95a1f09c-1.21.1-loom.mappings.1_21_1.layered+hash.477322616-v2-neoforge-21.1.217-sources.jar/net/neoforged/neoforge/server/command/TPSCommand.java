/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import ;
import D;
import com.google.common.math.Stats;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.text.DecimalFormat;
import net.minecraft.command.argument.DimensionArgumentType;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Colors;
import net.minecraft.util.Formatting;
import net.minecraft.util.TimeHelper;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.tick.TickManager;
import org.jetbrains.annotations.Nullable;
import org.joml.Math;

class TPSCommand {
    private static final DecimalFormat TIME_FORMATTER = new DecimalFormat("########0.000");
    private static final long[] UNLOADED = new long[] { 0 };

    static ArgumentBuilder<ServerCommandSource, ?> register() {
        return CommandManager.literal("tps")
                .then(CommandManager.argument("dimension", DimensionArgumentType.dimension())
                        .executes(ctx -> sendTime(ctx, DimensionArgumentType.getDimensionArgument(ctx, "dimension"))))
                .executes(ctx -> {
                    for (ServerWorld dimension : ctx.getSource().getServer().getWorlds()) {
                        sendTime(ctx, dimension);
                    }

                    sendTime(ctx, null);
                    return Command.SINGLE_SUCCESS;
                });
    }

    private static int sendTime(CommandContext<ServerCommandSource> context, @Nullable ServerWorld dimension) throws CommandSyntaxException {
        var src = context.getSource();
        src.sendFeedback(() -> createComponent(src.getServer(), dimension), false);
        return Command.SINGLE_SUCCESS;
    }

    private static Text createComponent(MinecraftServer server, @Nullable ServerWorld dimension) {
        long[] times;
        TickManager tickRateManager;

        if (dimension == null) {
            times = server.getTickTimes();
            tickRateManager = server.getTickManager();
        } else {
            var dimensionTimes = server.getTickTime(dimension.getRegistryKey());
            times = dimensionTimes == null ? UNLOADED : dimensionTimes;
            tickRateManager = dimension.getTickManager();
        }

        var tickTime = Stats.meanOf(times) / TimeHelper.MILLI_IN_NANOS;
        var tps = TimeHelper.SECOND_IN_MILLIS / Math.max(tickTime, tickRateManager.getMillisPerTick());
        var tickTimeComponent = Text.literal(TIME_FORMATTER.format(tickTime)).withColor(Colors.LIGHT_GRAY);
        var tpsComponent = Text.literal(TIME_FORMATTER.format(tps)).withColor(calculateTPSColor(tickRateManager, tps));

        MutableText component;

        if (dimension == null) {
            component = CommandUtils.makeTranslatableWithFallback("commands.neoforge.tps.overall", tpsComponent, tickTimeComponent);
        } else {
            var dimensionType = dimension.getDimensionEntry();

            var dimensionName = Text.empty().append(dimension.getDescription()).styled(style -> style
                    .withColor(Formatting.GREEN)
                    .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommandUtils.makeTranslatableWithFallback(
                            "commands.neoforge.tps.dimension.tooltip",
                            dimension.getRegistryKey().getValue().toString(),
                            dimensionType.getIdAsString()))));

            component = CommandUtils.makeTranslatableWithFallback("commands.neoforge.tps.dimension", dimensionName, tpsComponent, tickTimeComponent);
        }

        return component.styled(style -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, CommandUtils.makeTranslatableWithFallback("commands.neoforge.tps.tooltip", tickRateManager.getTickRate()))));
    }

    private static int calculateTPSColor(TickManager tickRateManager, double tps) {
        // Improved color blending code thanks to sciwhiz12
        float maxTPS = TimeHelper.SECOND_IN_MILLIS / tickRateManager.getMillisPerTick();
        // 0 degrees (0F) is red, 120 degrees (0.33F) is green
        return MathHelper.hsvToRgb((float) (MathHelper.getLerpProgress(tps, 0, maxTPS) * 0.33F), 1F, 1F);
    }
}
