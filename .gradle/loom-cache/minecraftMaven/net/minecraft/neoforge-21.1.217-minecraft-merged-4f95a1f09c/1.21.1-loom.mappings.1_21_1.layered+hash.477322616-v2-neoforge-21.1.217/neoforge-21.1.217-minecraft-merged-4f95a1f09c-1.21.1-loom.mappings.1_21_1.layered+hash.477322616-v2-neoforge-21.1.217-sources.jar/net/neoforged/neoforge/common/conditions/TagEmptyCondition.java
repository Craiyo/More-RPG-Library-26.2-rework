/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

public record TagEmptyCondition(TagKey<Item> tag) implements ICondition {
    public static final MapCodec<TagEmptyCondition> CODEC = RecordCodecBuilder.mapCodec(
            builder -> builder
                    .group(
                            Identifier.CODEC.xmap(loc -> TagKey.of(RegistryKeys.ITEM, loc), TagKey::id).fieldOf("tag").forGetter(TagEmptyCondition::tag))
                    .apply(builder, TagEmptyCondition::new));

    public TagEmptyCondition(String location) {
        this(Identifier.of(location));
    }

    public TagEmptyCondition(String namespace, String path) {
        this(Identifier.of(namespace, path));
    }

    public TagEmptyCondition(Identifier tag) {
        this(TagKey.of(RegistryKeys.ITEM, tag));
    }

    @Override
    public boolean test(ICondition.IContext context) {
        return context.getTag(tag).isEmpty();
    }

    @Override
    public MapCodec<? extends ICondition> codec() {
        return CODEC;
    }

    @Override
    public String toString() {
        return "tag_empty(\"" + tag.id() + "\")";
    }
}
