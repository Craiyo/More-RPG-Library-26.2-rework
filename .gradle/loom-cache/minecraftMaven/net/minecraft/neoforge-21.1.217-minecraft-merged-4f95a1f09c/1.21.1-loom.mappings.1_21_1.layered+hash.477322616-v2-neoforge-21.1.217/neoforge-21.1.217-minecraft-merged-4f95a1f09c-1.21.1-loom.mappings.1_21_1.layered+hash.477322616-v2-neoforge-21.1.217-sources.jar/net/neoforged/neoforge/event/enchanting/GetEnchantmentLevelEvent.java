/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.enchanting;

import java.util.Optional;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper.Impl;
import net.minecraft.registry.entry.RegistryEntry;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.common.extensions.IItemStackExtension;
import org.jetbrains.annotations.Nullable;

/**
 * This event is fired whenever the enchantment level of a particular item is requested for gameplay purposes.<br>
 * It is called from {@link IItemStackExtension#getEnchantmentLevel(Enchantment)} and {@link IItemStackExtension#getAllEnchantments()}.
 * <p>
 * It is not fired for interactions with NBT, which means these changes will not reflect in the item tooltip.
 */
public class GetEnchantmentLevelEvent extends Event {
    protected final ItemStack stack;
    protected final ItemEnchantmentsComponent.Builder enchantments;
    @Nullable
    protected final RegistryEntry<Enchantment> targetEnchant;
    protected final Impl<Enchantment> lookup;

    public GetEnchantmentLevelEvent(ItemStack stack, ItemEnchantmentsComponent.Builder enchantments, @Nullable RegistryEntry<Enchantment> targetEnchant, Impl<Enchantment> lookup) {
        this.stack = stack;
        this.enchantments = enchantments;
        this.targetEnchant = targetEnchant;
        this.lookup = lookup;
    }

    /**
     * Returns the item stack that is being queried against.
     */
    public ItemStack getStack() {
        return this.stack;
    }

    /**
     * Returns the mutable enchantment->level map.
     */
    public ItemEnchantmentsComponent.Builder getEnchantments() {
        return this.enchantments;
    }

    /**
     * This method returns the specific enchantment being queried from {@link IItemStackExtension#getEnchantmentLevel(Enchantment)}.
     * <p>
     * If this is value is present, you only need to adjust the level of that enchantment.
     * <p>
     * If this value is null, then the event was fired from {@link IItemStackExtension#getAllEnchantments()} and all enchantments should be populated.
     * 
     * @return The specific enchantment being queried, or null, if all enchantments are being requested.
     */
    @Nullable
    public RegistryEntry<Enchantment> getTargetEnchant() {
        return this.targetEnchant;
    }

    /**
     * Helper method around {@link #getTargetEnchant()} that checks if the target is the specified enchantment, or if the target is null.
     * 
     * @param ench The enchantment to check.
     * @return If modifications to the passed enchantment are relevant for this event.
     * @see #getTargetEnchant() for more information about the target enchantment.
     */
    public boolean isTargetting(RegistryEntry<Enchantment> ench) {
        return this.targetEnchant == null || this.targetEnchant.matches(ench);
    }

    /**
     * Helper method around {@link #getTargetEnchant()} that checks if the target is the specified enchantment, or if the target is null.
     *
     * @param ench The enchantment to check.
     * @return If modifications to the passed enchantment are relevant for this event.
     * @see #getTargetEnchant() for more information about the target enchantment.
     */
    public boolean isTargetting(RegistryKey<Enchantment> ench) {
        return this.targetEnchant == null || this.targetEnchant.matchesKey(ench);
    }

    /**
     * Attempts to resolve a {@link RegistryEntry.Reference} for a target enchantment.
     * Since enchantments are data, they are not guaranteed to exist.
     * 
     * @param key The target resource key
     * @return If the holder was available, an Optional containing it; otherwise an empty Optional.
     */
    public Optional<RegistryEntry.Reference<Enchantment>> getHolder(RegistryKey<Enchantment> key) {
        return this.lookup.getOptional(key);
    }

    /**
     * {@return the underlying registry lookup, which can be used to access enchantment Holders}
     */
    public Impl<Enchantment> getLookup() {
        return lookup;
    }
}
