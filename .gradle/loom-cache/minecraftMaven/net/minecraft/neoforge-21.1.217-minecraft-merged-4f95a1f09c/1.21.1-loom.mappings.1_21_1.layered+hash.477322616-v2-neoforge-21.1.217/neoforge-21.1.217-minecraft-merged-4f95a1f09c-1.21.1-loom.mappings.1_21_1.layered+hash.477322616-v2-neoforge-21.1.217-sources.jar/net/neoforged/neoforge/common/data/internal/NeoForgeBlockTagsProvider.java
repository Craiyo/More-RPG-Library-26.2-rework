/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data.internal;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.ValueLookupTagProvider;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.common.data.BlockTagsProvider;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;

public final class NeoForgeBlockTagsProvider extends BlockTagsProvider {
    public NeoForgeBlockTagsProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider, @Nullable ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, "neoforge", existingFileHelper);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void configure(RegistryWrapper.WrapperLookup p_256380_) {
        getOrCreateTagBuilder(Tags.Blocks.BARRELS).addTag(Tags.Blocks.BARRELS_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.BARRELS_WOODEN).add(Blocks.BARREL);
        getOrCreateTagBuilder(Tags.Blocks.BOOKSHELVES).add(Blocks.BOOKSHELF);
        getOrCreateTagBuilder(Tags.Blocks.BUDDING_BLOCKS).add(Blocks.BUDDING_AMETHYST);
        getOrCreateTagBuilder(Tags.Blocks.BUDS).add(Blocks.SMALL_AMETHYST_BUD).add(Blocks.MEDIUM_AMETHYST_BUD).add(Blocks.LARGE_AMETHYST_BUD);
        getOrCreateTagBuilder(Tags.Blocks.CHAINS).add(Blocks.CHAIN);
        getOrCreateTagBuilder(Tags.Blocks.CHESTS).addTags(Tags.Blocks.CHESTS_ENDER, Tags.Blocks.CHESTS_TRAPPED, Tags.Blocks.CHESTS_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.CHESTS_ENDER).add(Blocks.ENDER_CHEST);
        getOrCreateTagBuilder(Tags.Blocks.CHESTS_TRAPPED).add(Blocks.TRAPPED_CHEST);
        getOrCreateTagBuilder(Tags.Blocks.CHESTS_WOODEN).add(Blocks.CHEST, Blocks.TRAPPED_CHEST);
        getOrCreateTagBuilder(Tags.Blocks.CLUSTERS).add(Blocks.AMETHYST_CLUSTER);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES).addTags(Tags.Blocks.COBBLESTONES_NORMAL, Tags.Blocks.COBBLESTONES_INFESTED, Tags.Blocks.COBBLESTONES_MOSSY, Tags.Blocks.COBBLESTONES_DEEPSLATE);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_NORMAL).add(Blocks.COBBLESTONE);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_INFESTED).add(Blocks.INFESTED_COBBLESTONE);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_MOSSY).add(Blocks.MOSSY_COBBLESTONE);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_DEEPSLATE).add(Blocks.COBBLED_DEEPSLATE);
        getOrCreateTagBuilder(Tags.Blocks.CONCRETES).add(Blocks.WHITE_CONCRETE, Blocks.ORANGE_CONCRETE, Blocks.MAGENTA_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.YELLOW_CONCRETE, Blocks.LIME_CONCRETE, Blocks.PINK_CONCRETE, Blocks.GRAY_CONCRETE, Blocks.LIGHT_GRAY_CONCRETE, Blocks.CYAN_CONCRETE, Blocks.PURPLE_CONCRETE, Blocks.BLUE_CONCRETE, Blocks.BROWN_CONCRETE, Blocks.GREEN_CONCRETE, Blocks.RED_CONCRETE, Blocks.BLACK_CONCRETE);
        addColored(Tags.Blocks.DYED, "{color}_banner");
        addColored(Tags.Blocks.DYED, "{color}_bed");
        addColored(Tags.Blocks.DYED, "{color}_candle");
        addColored(Tags.Blocks.DYED, "{color}_carpet");
        addColored(Tags.Blocks.DYED, "{color}_concrete");
        addColored(Tags.Blocks.DYED, "{color}_concrete_powder");
        addColored(Tags.Blocks.DYED, "{color}_glazed_terracotta");
        addColored(Tags.Blocks.DYED, "{color}_shulker_box");
        addColored(Tags.Blocks.DYED, "{color}_stained_glass");
        addColored(Tags.Blocks.DYED, "{color}_stained_glass_pane");
        addColored(Tags.Blocks.DYED, "{color}_terracotta");
        addColored(Tags.Blocks.DYED, "{color}_wall_banner");
        addColored(Tags.Blocks.DYED, "{color}_wool");
        addColoredTags(getOrCreateTagBuilder(Tags.Blocks.DYED)::addTag, Tags.Blocks.DYED);
        getOrCreateTagBuilder(Tags.Blocks.END_STONES).add(Blocks.END_STONE);
        getOrCreateTagBuilder(Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST);
        getOrCreateTagBuilder(Tags.Blocks.FENCE_GATES).addTags(Tags.Blocks.FENCE_GATES_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.FENCE_GATES_WOODEN).add(Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE, Blocks.JUNGLE_FENCE_GATE, Blocks.ACACIA_FENCE_GATE, Blocks.DARK_OAK_FENCE_GATE, Blocks.CRIMSON_FENCE_GATE, Blocks.WARPED_FENCE_GATE, Blocks.MANGROVE_FENCE_GATE, Blocks.BAMBOO_FENCE_GATE, Blocks.CHERRY_FENCE_GATE);
        getOrCreateTagBuilder(Tags.Blocks.FENCES).addTags(Tags.Blocks.FENCES_NETHER_BRICK, Tags.Blocks.FENCES_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.FENCES_NETHER_BRICK).add(Blocks.NETHER_BRICK_FENCE);
        getOrCreateTagBuilder(Tags.Blocks.FENCES_WOODEN).addTag(BlockTags.WOODEN_FENCES);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS).addTags(Tags.Blocks.GLASS_BLOCKS_COLORLESS, Tags.Blocks.GLASS_BLOCKS_CHEAP, Tags.Blocks.GLASS_BLOCKS_TINTED);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_COLORLESS).add(Blocks.GLASS);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_CHEAP).add(Blocks.GLASS, Blocks.WHITE_STAINED_GLASS, Blocks.ORANGE_STAINED_GLASS, Blocks.MAGENTA_STAINED_GLASS, Blocks.LIGHT_BLUE_STAINED_GLASS, Blocks.YELLOW_STAINED_GLASS, Blocks.LIME_STAINED_GLASS, Blocks.PINK_STAINED_GLASS, Blocks.GRAY_STAINED_GLASS, Blocks.LIGHT_GRAY_STAINED_GLASS, Blocks.CYAN_STAINED_GLASS, Blocks.PURPLE_STAINED_GLASS, Blocks.BLUE_STAINED_GLASS, Blocks.BROWN_STAINED_GLASS, Blocks.GREEN_STAINED_GLASS, Blocks.RED_STAINED_GLASS, Blocks.BLACK_STAINED_GLASS);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_TINTED).add(Blocks.TINTED_GLASS);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_PANES).addTags(Tags.Blocks.GLASS_PANES_COLORLESS).add(Blocks.WHITE_STAINED_GLASS_PANE, Blocks.ORANGE_STAINED_GLASS_PANE, Blocks.MAGENTA_STAINED_GLASS_PANE, Blocks.LIGHT_BLUE_STAINED_GLASS_PANE, Blocks.YELLOW_STAINED_GLASS_PANE, Blocks.LIME_STAINED_GLASS_PANE, Blocks.PINK_STAINED_GLASS_PANE, Blocks.GRAY_STAINED_GLASS_PANE, Blocks.LIGHT_GRAY_STAINED_GLASS_PANE, Blocks.CYAN_STAINED_GLASS_PANE, Blocks.PURPLE_STAINED_GLASS_PANE, Blocks.BLUE_STAINED_GLASS_PANE, Blocks.BROWN_STAINED_GLASS_PANE, Blocks.GREEN_STAINED_GLASS_PANE, Blocks.RED_STAINED_GLASS_PANE, Blocks.BLACK_STAINED_GLASS_PANE);
        getOrCreateTagBuilder(Tags.Blocks.GLASS_PANES_COLORLESS).add(Blocks.GLASS_PANE);
        getOrCreateTagBuilder(Tags.Blocks.GLAZED_TERRACOTTAS).add(Blocks.WHITE_GLAZED_TERRACOTTA, Blocks.ORANGE_GLAZED_TERRACOTTA, Blocks.MAGENTA_GLAZED_TERRACOTTA, Blocks.LIGHT_BLUE_GLAZED_TERRACOTTA, Blocks.YELLOW_GLAZED_TERRACOTTA, Blocks.LIME_GLAZED_TERRACOTTA, Blocks.PINK_GLAZED_TERRACOTTA, Blocks.GRAY_GLAZED_TERRACOTTA, Blocks.LIGHT_GRAY_GLAZED_TERRACOTTA, Blocks.CYAN_GLAZED_TERRACOTTA, Blocks.PURPLE_GLAZED_TERRACOTTA, Blocks.BLUE_GLAZED_TERRACOTTA, Blocks.BROWN_GLAZED_TERRACOTTA, Blocks.GREEN_GLAZED_TERRACOTTA, Blocks.RED_GLAZED_TERRACOTTA, Blocks.BLACK_GLAZED_TERRACOTTA);
        getOrCreateTagBuilder(Tags.Blocks.GRAVELS).add(Blocks.GRAVEL);
        getOrCreateTagBuilder(Tags.Blocks.SKULLS).add(Blocks.SKELETON_SKULL, Blocks.SKELETON_WALL_SKULL, Blocks.WITHER_SKELETON_SKULL, Blocks.WITHER_SKELETON_WALL_SKULL, Blocks.PLAYER_HEAD, Blocks.PLAYER_WALL_HEAD, Blocks.ZOMBIE_HEAD, Blocks.ZOMBIE_WALL_HEAD, Blocks.CREEPER_HEAD, Blocks.CREEPER_WALL_HEAD, Blocks.PIGLIN_HEAD, Blocks.PIGLIN_WALL_HEAD, Blocks.DRAGON_HEAD, Blocks.DRAGON_WALL_HEAD);
        getOrCreateTagBuilder(Tags.Blocks.HIDDEN_FROM_RECIPE_VIEWERS);
        getOrCreateTagBuilder(Tags.Blocks.NETHERRACKS).add(Blocks.NETHERRACK);
        getOrCreateTagBuilder(Tags.Blocks.OBSIDIANS_NORMAL).add(Blocks.OBSIDIAN);
        getOrCreateTagBuilder(Tags.Blocks.OBSIDIANS_CRYING).add(Blocks.CRYING_OBSIDIAN);
        getOrCreateTagBuilder(Tags.Blocks.OBSIDIANS).addTags(Tags.Blocks.OBSIDIANS_NORMAL, Tags.Blocks.OBSIDIANS_CRYING);
        getOrCreateTagBuilder(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE).add(Blocks.DEEPSLATE);
        getOrCreateTagBuilder(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK).add(Blocks.NETHERRACK);
        getOrCreateTagBuilder(Tags.Blocks.ORE_BEARING_GROUND_STONE).add(Blocks.STONE);
        getOrCreateTagBuilder(Tags.Blocks.ORE_RATES_DENSE).add(Blocks.COPPER_ORE, Blocks.DEEPSLATE_COPPER_ORE, Blocks.DEEPSLATE_LAPIS_ORE, Blocks.DEEPSLATE_REDSTONE_ORE, Blocks.LAPIS_ORE, Blocks.REDSTONE_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORE_RATES_SINGULAR).add(Blocks.ANCIENT_DEBRIS, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.DEEPSLATE_EMERALD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.DEEPSLATE_IRON_ORE, Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.GOLD_ORE, Blocks.IRON_ORE, Blocks.NETHER_QUARTZ_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORE_RATES_SPARSE).add(Blocks.NETHER_GOLD_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORES).addTags(Tags.Blocks.ORES_COAL, Tags.Blocks.ORES_COPPER, Tags.Blocks.ORES_DIAMOND, Tags.Blocks.ORES_EMERALD, Tags.Blocks.ORES_GOLD, Tags.Blocks.ORES_IRON, Tags.Blocks.ORES_LAPIS, Tags.Blocks.ORES_NETHERITE_SCRAP, Tags.Blocks.ORES_REDSTONE, Tags.Blocks.ORES_QUARTZ);
        getOrCreateTagBuilder(Tags.Blocks.ORES_COAL).addTag(BlockTags.COAL_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_COPPER).addTag(BlockTags.COPPER_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_DIAMOND).addTag(BlockTags.DIAMOND_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_EMERALD).addTag(BlockTags.EMERALD_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_GOLD).addTag(BlockTags.GOLD_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_IRON).addTag(BlockTags.IRON_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_LAPIS).addTag(BlockTags.LAPIS_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_QUARTZ).add(Blocks.NETHER_QUARTZ_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORES_REDSTONE).addTag(BlockTags.REDSTONE_ORES);
        getOrCreateTagBuilder(Tags.Blocks.ORES_NETHERITE_SCRAP).add(Blocks.ANCIENT_DEBRIS);
        getOrCreateTagBuilder(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE).add(Blocks.DEEPSLATE_COAL_ORE, Blocks.DEEPSLATE_COPPER_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.DEEPSLATE_EMERALD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.DEEPSLATE_IRON_ORE, Blocks.DEEPSLATE_LAPIS_ORE, Blocks.DEEPSLATE_REDSTONE_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORES_IN_GROUND_NETHERRACK).add(Blocks.NETHER_GOLD_ORE, Blocks.NETHER_QUARTZ_ORE);
        getOrCreateTagBuilder(Tags.Blocks.ORES_IN_GROUND_STONE).add(Blocks.COAL_ORE, Blocks.COPPER_ORE, Blocks.DIAMOND_ORE, Blocks.EMERALD_ORE, Blocks.GOLD_ORE, Blocks.IRON_ORE, Blocks.LAPIS_ORE, Blocks.REDSTONE_ORE);
        getOrCreateTagBuilder(Tags.Blocks.PUMPKINS).addTags(Tags.Blocks.PUMPKINS_NORMAL, Tags.Blocks.PUMPKINS_CARVED, Tags.Blocks.PUMPKINS_JACK_O_LANTERNS);
        getOrCreateTagBuilder(Tags.Blocks.PUMPKINS_NORMAL).add(Blocks.PUMPKIN);
        getOrCreateTagBuilder(Tags.Blocks.PUMPKINS_CARVED).add(Blocks.CARVED_PUMPKIN);
        getOrCreateTagBuilder(Tags.Blocks.PUMPKINS_JACK_O_LANTERNS).add(Blocks.JACK_O_LANTERN);
        getOrCreateTagBuilder(Tags.Blocks.PLAYER_WORKSTATIONS_CRAFTING_TABLES).add(Blocks.CRAFTING_TABLE);
        getOrCreateTagBuilder(Tags.Blocks.PLAYER_WORKSTATIONS_FURNACES).add(Blocks.FURNACE);
        getOrCreateTagBuilder(Tags.Blocks.RELOCATION_NOT_SUPPORTED);
        getOrCreateTagBuilder(Tags.Blocks.ROPES);
        getOrCreateTagBuilder(Tags.Blocks.SANDS).addTags(Tags.Blocks.SANDS_COLORLESS, Tags.Blocks.SANDS_RED);
        getOrCreateTagBuilder(Tags.Blocks.SANDS_COLORLESS).add(Blocks.SAND);
        getOrCreateTagBuilder(Tags.Blocks.SANDS_RED).add(Blocks.RED_SAND);

        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_RED_BLOCKS).add(Blocks.RED_SANDSTONE, Blocks.CUT_RED_SANDSTONE, Blocks.CHISELED_RED_SANDSTONE, Blocks.SMOOTH_RED_SANDSTONE);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_UNCOLORED_BLOCKS).add(Blocks.SANDSTONE, Blocks.CUT_SANDSTONE, Blocks.CHISELED_SANDSTONE, Blocks.SMOOTH_SANDSTONE);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_BLOCKS).addTags(Tags.Blocks.SANDSTONE_RED_BLOCKS, Tags.Blocks.SANDSTONE_UNCOLORED_BLOCKS);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_RED_SLABS).add(Blocks.RED_SANDSTONE_SLAB, Blocks.CUT_RED_SANDSTONE_SLAB, Blocks.SMOOTH_RED_SANDSTONE_SLAB);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_UNCOLORED_SLABS).add(Blocks.SANDSTONE_SLAB, Blocks.CUT_SANDSTONE_SLAB, Blocks.SMOOTH_SANDSTONE_SLAB);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_SLABS).addTags(Tags.Blocks.SANDSTONE_RED_SLABS, Tags.Blocks.SANDSTONE_UNCOLORED_SLABS);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_RED_STAIRS).add(Blocks.RED_SANDSTONE_STAIRS, Blocks.SMOOTH_RED_SANDSTONE_STAIRS);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_UNCOLORED_STAIRS).add(Blocks.SANDSTONE_STAIRS, Blocks.SMOOTH_SANDSTONE_STAIRS);
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_STAIRS).addTags(Tags.Blocks.SANDSTONE_RED_STAIRS, Tags.Blocks.SANDSTONE_UNCOLORED_STAIRS);

        getOrCreateTagBuilder(Tags.Blocks.STONES).add(Blocks.ANDESITE, Blocks.DIORITE, Blocks.GRANITE, Blocks.STONE, Blocks.DEEPSLATE, Blocks.TUFF);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS).addTags(Tags.Blocks.STORAGE_BLOCKS_BONE_MEAL, Tags.Blocks.STORAGE_BLOCKS_COAL,
                Tags.Blocks.STORAGE_BLOCKS_COPPER, Tags.Blocks.STORAGE_BLOCKS_DIAMOND, Tags.Blocks.STORAGE_BLOCKS_DRIED_KELP,
                Tags.Blocks.STORAGE_BLOCKS_EMERALD, Tags.Blocks.STORAGE_BLOCKS_GOLD, Tags.Blocks.STORAGE_BLOCKS_IRON,
                Tags.Blocks.STORAGE_BLOCKS_LAPIS, Tags.Blocks.STORAGE_BLOCKS_NETHERITE, Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER,
                Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD, Tags.Blocks.STORAGE_BLOCKS_RAW_IRON, Tags.Blocks.STORAGE_BLOCKS_REDSTONE,
                Tags.Blocks.STORAGE_BLOCKS_SLIME, Tags.Blocks.STORAGE_BLOCKS_WHEAT);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_BONE_MEAL).add(Blocks.BONE_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_COAL).add(Blocks.COAL_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_COPPER).add(Blocks.COPPER_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_DIAMOND).add(Blocks.DIAMOND_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_DRIED_KELP).add(Blocks.DRIED_KELP_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_EMERALD).add(Blocks.EMERALD_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_GOLD).add(Blocks.GOLD_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_IRON).add(Blocks.IRON_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_LAPIS).add(Blocks.LAPIS_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_NETHERITE).add(Blocks.NETHERITE_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER).add(Blocks.RAW_COPPER_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD).add(Blocks.RAW_GOLD_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON).add(Blocks.RAW_IRON_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_REDSTONE).add(Blocks.REDSTONE_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_SLIME).add(Blocks.SLIME_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STORAGE_BLOCKS_WHEAT).add(Blocks.HAY_BLOCK);
        getOrCreateTagBuilder(Tags.Blocks.STRIPPED_LOGS).add(
                Blocks.STRIPPED_ACACIA_LOG, Blocks.STRIPPED_BAMBOO_BLOCK, Blocks.STRIPPED_BIRCH_LOG,
                Blocks.STRIPPED_CHERRY_LOG, Blocks.STRIPPED_DARK_OAK_LOG, Blocks.STRIPPED_JUNGLE_LOG,
                Blocks.STRIPPED_MANGROVE_LOG, Blocks.STRIPPED_OAK_LOG, Blocks.STRIPPED_SPRUCE_LOG,
                Blocks.STRIPPED_CRIMSON_STEM, Blocks.STRIPPED_WARPED_STEM);
        getOrCreateTagBuilder(Tags.Blocks.STRIPPED_WOODS).add(
                Blocks.STRIPPED_ACACIA_WOOD, Blocks.STRIPPED_BIRCH_WOOD, Blocks.STRIPPED_CHERRY_WOOD,
                Blocks.STRIPPED_DARK_OAK_WOOD, Blocks.STRIPPED_JUNGLE_WOOD, Blocks.STRIPPED_MANGROVE_WOOD,
                Blocks.STRIPPED_OAK_WOOD, Blocks.STRIPPED_SPRUCE_WOOD, Blocks.STRIPPED_CRIMSON_HYPHAE,
                Blocks.STRIPPED_WARPED_HYPHAE);
        getOrCreateTagBuilder(Tags.Blocks.VILLAGER_JOB_SITES).add(
                Blocks.BARREL, Blocks.BLAST_FURNACE, Blocks.BREWING_STAND, Blocks.CARTOGRAPHY_TABLE,
                Blocks.CAULDRON, Blocks.WATER_CAULDRON, Blocks.LAVA_CAULDRON, Blocks.POWDER_SNOW_CAULDRON,
                Blocks.COMPOSTER, Blocks.FLETCHING_TABLE, Blocks.GRINDSTONE, Blocks.LECTERN,
                Blocks.LOOM, Blocks.SMITHING_TABLE, Blocks.SMOKER, Blocks.STONECUTTER);

        getOrCreateTagBuilder(Tags.Blocks.VILLAGER_FARMLANDS).add(Blocks.FARMLAND);

        // Make our Needs Netherite Tool tag be functional.
        getOrCreateTagBuilder(Tags.Blocks.NEEDS_NETHERITE_TOOL);
        getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_WOODEN_TOOL).addTag(Tags.Blocks.NEEDS_NETHERITE_TOOL);
        getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_STONE_TOOL).addTag(Tags.Blocks.NEEDS_NETHERITE_TOOL);
        getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_IRON_TOOL).addTag(Tags.Blocks.NEEDS_NETHERITE_TOOL);
        getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_GOLD_TOOL).addTag(Tags.Blocks.NEEDS_NETHERITE_TOOL);
        getOrCreateTagBuilder(BlockTags.INCORRECT_FOR_DIAMOND_TOOL).addTag(Tags.Blocks.NEEDS_NETHERITE_TOOL);

        // Backwards compat with pre-1.21 tags. Done after so optional tag is last for better readability.
        // TODO: Remove backwards compat tag entries in 1.22
        tagWithOptionalLegacy(Tags.Blocks.BARRELS);
        tagWithOptionalLegacy(Tags.Blocks.BARRELS_WOODEN);
        tagWithOptionalLegacy(Tags.Blocks.BOOKSHELVES);
        tagWithOptionalLegacy(Tags.Blocks.CHESTS);
        tagWithOptionalLegacy(Tags.Blocks.CHESTS_ENDER);
        tagWithOptionalLegacy(Tags.Blocks.CHESTS_TRAPPED);
        tagWithOptionalLegacy(Tags.Blocks.CHESTS_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES).addOptionalTag(Identifier.of("forge", "cobblestone"));
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_NORMAL).addOptionalTag(Identifier.of("forge", "cobblestone/normal"));
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_INFESTED).addOptionalTag(Identifier.of("forge", "cobblestone/infested"));
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_MOSSY).addOptionalTag(Identifier.of("forge", "cobblestone/mossy"));
        getOrCreateTagBuilder(Tags.Blocks.COBBLESTONES_DEEPSLATE).addOptionalTag(Identifier.of("forge", "cobblestone/deepslate"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_BLACK)
                .addOptionalTag(Identifier.of("forge", "glass/black"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/black"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_BLUE)
                .addOptionalTag(Identifier.of("forge", "glass/blue"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/blue"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_BROWN)
                .addOptionalTag(Identifier.of("forge", "glass/brown"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/brown"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_CYAN)
                .addOptionalTag(Identifier.of("forge", "glass/cyan"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/cyan"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_GRAY)
                .addOptionalTag(Identifier.of("forge", "glass/gray"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/gray"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_GREEN)
                .addOptionalTag(Identifier.of("forge", "glass/green"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/green"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_LIGHT_BLUE)
                .addOptionalTag(Identifier.of("forge", "glass/light_blue"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/light_blue"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_LIGHT_GRAY)
                .addOptionalTag(Identifier.of("forge", "glass/light_gray"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/light_gray"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_LIME)
                .addOptionalTag(Identifier.of("forge", "glass/lime"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/lime"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_MAGENTA)
                .addOptionalTag(Identifier.of("forge", "glass/magenta"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/magenta"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_MAGENTA)
                .addOptionalTag(Identifier.of("forge", "glass/magenta"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/magenta"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_ORANGE)
                .addOptionalTag(Identifier.of("forge", "glass/orange"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/orange"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_PINK)
                .addOptionalTag(Identifier.of("forge", "glass/pink"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/pink"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_PURPLE)
                .addOptionalTag(Identifier.of("forge", "glass/purple"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/purple"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_RED)
                .addOptionalTag(Identifier.of("forge", "glass/red"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/red"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_WHITE)
                .addOptionalTag(Identifier.of("forge", "glass/white"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/white"));
        getOrCreateTagBuilder(Tags.Blocks.DYED_YELLOW)
                .addOptionalTag(Identifier.of("forge", "glass/yellow"))
                .addOptionalTag(Identifier.of("forge", "stained_glass/yellow"));
        tagWithOptionalLegacy(Tags.Blocks.END_STONES);
        tagWithOptionalLegacy(Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST);
        tagWithOptionalLegacy(Tags.Blocks.FENCE_GATES);
        tagWithOptionalLegacy(Tags.Blocks.FENCE_GATES_WOODEN);
        tagWithOptionalLegacy(Tags.Blocks.FENCES);
        tagWithOptionalLegacy(Tags.Blocks.FENCES_NETHER_BRICK);
        tagWithOptionalLegacy(Tags.Blocks.FENCES_WOODEN);
        getOrCreateTagBuilder(Tags.Blocks.GRAVELS).addOptionalTag(Identifier.of("forge", "gravel"));
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS).addOptionalTag(Identifier.of("forge", "glass"));
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_COLORLESS).addOptionalTag(Identifier.of("forge", "glass_colorless"));
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_CHEAP).addOptionalTag(Identifier.of("forge", "glass_silica"));
        getOrCreateTagBuilder(Tags.Blocks.GLASS_BLOCKS_TINTED).addOptionalTag(Identifier.of("forge", "glass_tinted"));
        getOrCreateTagBuilder(Tags.Blocks.GLASS_PANES_COLORLESS).addOptionalTag(Identifier.of("forge", "glass_panes_colorless"));
        getOrCreateTagBuilder(Tags.Blocks.NETHERRACKS).addOptionalTag(Identifier.of("forge", "netherrack"));
        getOrCreateTagBuilder(Tags.Blocks.OBSIDIANS).addOptionalTag(Identifier.of("forge", "obsidian"));
        tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE);
        tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK);
        tagWithOptionalLegacy(Tags.Blocks.ORE_BEARING_GROUND_STONE);
        tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_DENSE);
        tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_SINGULAR);
        tagWithOptionalLegacy(Tags.Blocks.ORE_RATES_SPARSE);
        tagWithOptionalLegacy(Tags.Blocks.ORES);
        tagWithOptionalLegacy(Tags.Blocks.ORES_COAL);
        tagWithOptionalLegacy(Tags.Blocks.ORES_COPPER);
        tagWithOptionalLegacy(Tags.Blocks.ORES_DIAMOND);
        tagWithOptionalLegacy(Tags.Blocks.ORES_EMERALD);
        tagWithOptionalLegacy(Tags.Blocks.ORES_GOLD);
        tagWithOptionalLegacy(Tags.Blocks.ORES_IRON);
        tagWithOptionalLegacy(Tags.Blocks.ORES_LAPIS);
        tagWithOptionalLegacy(Tags.Blocks.ORES_QUARTZ);
        tagWithOptionalLegacy(Tags.Blocks.ORES_REDSTONE);
        tagWithOptionalLegacy(Tags.Blocks.ORES_NETHERITE_SCRAP);
        tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE);
        tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_NETHERRACK);
        tagWithOptionalLegacy(Tags.Blocks.ORES_IN_GROUND_STONE);
        getOrCreateTagBuilder(Tags.Blocks.STONES).addOptionalTag(Identifier.of("forge", "stone"));
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_COAL);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_COPPER);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_DIAMOND);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_EMERALD);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_GOLD);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_IRON);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_LAPIS);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_REDSTONE);
        tagWithOptionalLegacy(Tags.Blocks.STORAGE_BLOCKS_NETHERITE);
        getOrCreateTagBuilder(Tags.Blocks.RELOCATION_NOT_SUPPORTED)
                .addOptionalTag(Identifier.of("forge", "relocation_not_supported"))
                .addOptionalTag(Identifier.of("forge", "immovable"));
        getOrCreateTagBuilder(Tags.Blocks.SANDSTONE_BLOCKS).addOptionalTag(Identifier.of("forge", "sandstone"));
        getOrCreateTagBuilder(Tags.Blocks.SANDS).addOptionalTag(Identifier.of("forge", "sand"));
        getOrCreateTagBuilder(Tags.Blocks.SANDS_COLORLESS).addOptionalTag(Identifier.of("forge", "sand/colorless"));
        getOrCreateTagBuilder(Tags.Blocks.SANDS_RED).addOptionalTag(Identifier.of("forge", "sand/red"));
    }

    private ValueLookupTagProvider.ObjectBuilder<Block> tagWithOptionalLegacy(TagKey<Block> tag) {
        ValueLookupTagProvider.ObjectBuilder<Block> tagAppender = getOrCreateTagBuilder(tag);
        tagAppender.addOptionalTag(Identifier.of("forge", tag.id().getPath()));
        return tagAppender;
    }

    private void addColored(TagKey<Block> group, String pattern) {
        String prefix = group.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
        for (DyeColor color : DyeColor.values()) {
            Identifier key = Identifier.of("minecraft", pattern.replace("{color}", color.getName()));
            TagKey<Block> tag = getForgeTag(prefix + color.getName());
            Block block = Registries.BLOCK.get(key);
            if (block == null || block == Blocks.AIR)
                throw new IllegalStateException("Unknown vanilla block: " + key);
            getOrCreateTagBuilder(tag).add(block);
        }
    }

    private void addColoredTags(Consumer<TagKey<Block>> consumer, TagKey<Block> group) {
        String prefix = group.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
        for (DyeColor color : DyeColor.values()) {
            TagKey<Block> tag = getForgeTag(prefix + color.getName());
            consumer.accept(tag);
        }
    }

    @SuppressWarnings("unchecked")
    private TagKey<Block> getForgeTag(String name) {
        try {
            name = name.toUpperCase(Locale.ENGLISH);
            return (TagKey<Block>) Tags.Blocks.class.getDeclaredField(name).get(null);
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            throw new IllegalStateException(Tags.Blocks.class.getName() + " is missing tag name: " + name);
        }
    }
}
