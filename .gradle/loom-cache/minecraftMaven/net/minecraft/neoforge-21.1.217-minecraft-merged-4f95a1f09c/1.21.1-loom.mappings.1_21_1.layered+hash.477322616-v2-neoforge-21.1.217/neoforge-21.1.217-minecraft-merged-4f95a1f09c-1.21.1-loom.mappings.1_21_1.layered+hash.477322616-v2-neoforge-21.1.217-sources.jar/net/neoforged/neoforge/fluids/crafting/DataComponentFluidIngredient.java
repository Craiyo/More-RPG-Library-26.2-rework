/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.fluids.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.fluid.Fluid;
import net.minecraft.predicate.ComponentPredicate;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.entry.RegistryEntryListCodec;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.common.crafting.DataComponentIngredient;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;

/**
 * Fluid ingredient that matches the given set of fluids, additionally performing either a
 * {@link DataComponentFluidIngredient#isStrict() strict} or partial test on the FluidStack's components.
 * <p>
 * Strict ingredients will only match fluid stacks that have <b>exactly</b> the provided components, while partial ones will
 * match if the stack's components contain all required components for the {@linkplain #components input predicate}.
 *
 * @see DataComponentIngredient DataComponentIngredient, its item equivalent
 */
public class DataComponentFluidIngredient extends FluidIngredient {
    public static final MapCodec<DataComponentFluidIngredient> CODEC = RecordCodecBuilder.mapCodec(
            builder -> builder
                    .group(
                            RegistryEntryListCodec.create(RegistryKeys.FLUID, Registries.FLUID.getEntryCodec(), false).fieldOf("fluids").forGetter(DataComponentFluidIngredient::fluids),
                            ComponentPredicate.CODEC.fieldOf("components").forGetter(DataComponentFluidIngredient::components),
                            Codec.BOOL.optionalFieldOf("strict", false).forGetter(DataComponentFluidIngredient::isStrict))
                    .apply(builder, DataComponentFluidIngredient::new));

    private final RegistryEntryList<Fluid> fluids;
    private final ComponentPredicate components;
    private final boolean strict;
    private final FluidStack[] stacks;

    public DataComponentFluidIngredient(RegistryEntryList<Fluid> fluids, ComponentPredicate components, boolean strict) {
        this.fluids = fluids;
        this.components = components;
        this.strict = strict;
        this.stacks = fluids.stream()
                .map(i -> new FluidStack(i, FluidType.BUCKET_VOLUME, components.toChanges()))
                .toArray(FluidStack[]::new);
    }

    @Override
    public boolean test(FluidStack stack) {
        if (strict) {
            for (FluidStack stack2 : this.stacks) {
                if (FluidStack.isSameFluidSameComponents(stack, stack2)) return true;
            }
            return false;
        } else {
            return this.fluids.contains(stack.getFluidHolder()) && this.components.test(stack);
        }
    }

    public Stream<FluidStack> generateStacks() {
        return Stream.of(stacks);
    }

    @Override
    public boolean isSimple() {
        return false;
    }

    @Override
    public FluidIngredientType<?> getType() {
        return NeoForgeMod.DATA_COMPONENT_FLUID_INGREDIENT_TYPE.get();
    }

    @Override
    public int hashCode() {
        return Objects.hash(fluids, components, strict);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof DataComponentFluidIngredient other)) return false;
        return other.fluids.equals(this.fluids)
                && other.components.equals(this.components)
                && other.strict == this.strict;
    }

    public RegistryEntryList<Fluid> fluids() {
        return fluids;
    }

    public ComponentPredicate components() {
        return components;
    }

    public boolean isStrict() {
        return strict;
    }

    /**
     * Creates a new ingredient matching the given fluid, containing the given components
     */
    public static FluidIngredient of(boolean strict, FluidStack stack) {
        return of(strict, stack.getComponents(), stack.getFluid());
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static <T> FluidIngredient of(boolean strict, ComponentType<? super T> type, T value, Fluid... fluids) {
        return of(strict, ComponentPredicate.builder().add(type, value).build(), fluids);
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static <T> FluidIngredient of(boolean strict, Supplier<? extends ComponentType<? super T>> type, T value, Fluid... fluids) {
        return of(strict, type.get(), value, fluids);
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static FluidIngredient of(boolean strict, ComponentMap map, Fluid... fluids) {
        return of(strict, ComponentPredicate.of(map), fluids);
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    @SafeVarargs
    public static FluidIngredient of(boolean strict, ComponentMap map, RegistryEntry<Fluid>... fluids) {
        return of(strict, ComponentPredicate.of(map), fluids);
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static FluidIngredient of(boolean strict, ComponentMap map, RegistryEntryList<Fluid> fluids) {
        return of(strict, ComponentPredicate.of(map), fluids);
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    @SafeVarargs
    public static FluidIngredient of(boolean strict, ComponentPredicate predicate, RegistryEntry<Fluid>... fluids) {
        return of(strict, predicate, RegistryEntryList.of(fluids));
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static FluidIngredient of(boolean strict, ComponentPredicate predicate, Fluid... fluids) {
        return of(strict, predicate, RegistryEntryList.of(Arrays.stream(fluids).map(Fluid::getRegistryEntry).toList()));
    }

    /**
     * Creates a new ingredient matching any fluid from the list, containing the given components
     */
    public static FluidIngredient of(boolean strict, ComponentPredicate predicate, RegistryEntryList<Fluid> fluids) {
        return new DataComponentFluidIngredient(fluids, predicate, strict);
    }
}
