/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.textures;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.client.texture.atlas.AtlasSource;
import net.minecraft.client.texture.atlas.AtlasSourceType;
import net.minecraft.client.texture.atlas.DirectoryAtlasSource;
import net.minecraft.resource.ResourceFinder;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;

/**
 * Namespace-aware version of {@link DirectoryAtlasSource}. This version should be preferred when several textures from
 * high-traffic directories should be stitched to an atlas without adding assets from other mods that should not be
 * stitched to this atlas
 */
public record NamespacedDirectoryLister(String namespace, String sourcePath, String idPrefix) implements AtlasSource {

    private static final MapCodec<NamespacedDirectoryLister> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            Codec.STRING.fieldOf("namespace").forGetter(lister -> lister.namespace),
            Codec.STRING.fieldOf("source").forGetter(lister -> lister.sourcePath),
            Codec.STRING.fieldOf("prefix").forGetter(lister -> lister.idPrefix)).apply(inst, NamespacedDirectoryLister::new));
    public static final Identifier ID = Identifier.of(NeoForgeVersion.MOD_ID, "namespaced_directory");
    public static final AtlasSourceType TYPE = new AtlasSourceType(CODEC);
    @Override
    public void load(ResourceManager resourceManager, SpriteRegions output) {
        ResourceFinder converter = new ResourceFinder("textures/" + this.sourcePath, ".png");
        converter.listMatchingResourcesFromNamespace(resourceManager, this.namespace).forEach((path, resource) -> {
            Identifier id = converter.toResourceId(path).withPrefixedPath(this.idPrefix);
            output.add(id, resource);
        });
    }

    @Override
    public AtlasSourceType getType() {
        return TYPE;
    }
}
