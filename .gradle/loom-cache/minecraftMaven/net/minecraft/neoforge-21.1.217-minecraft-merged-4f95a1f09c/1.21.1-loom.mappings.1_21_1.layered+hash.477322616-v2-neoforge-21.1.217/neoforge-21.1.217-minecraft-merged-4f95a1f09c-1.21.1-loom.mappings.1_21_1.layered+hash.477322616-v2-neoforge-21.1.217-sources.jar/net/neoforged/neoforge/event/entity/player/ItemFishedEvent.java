/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import com.google.common.base.Preconditions;
import java.util.List;
import javax.annotation.Nonnegative;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import net.neoforged.bus.api.ICancellableEvent;

/**
 * This event is called when a player fishes an item.
 *
 * This event is {@link net.neoforged.bus.api.ICancellableEvent}
 * Canceling the event will cause the player to receive no items at all.
 * The hook will still take the damage specified
 */
public class ItemFishedEvent extends PlayerEvent implements ICancellableEvent {
    private final DefaultedList<ItemStack> stacks = DefaultedList.of();
    private final FishingBobberEntity hook;
    private int rodDamage;

    public ItemFishedEvent(List<ItemStack> stacks, int rodDamage, FishingBobberEntity hook) {
        super(hook.getPlayerOwner());
        this.stacks.addAll(stacks);
        this.rodDamage = rodDamage;
        this.hook = hook;
    }

    /**
     * Get the damage the rod will take.
     * 
     * @return The damage the rod will take
     */
    public int getRodDamage() {
        return rodDamage;
    }

    /**
     * Specifies the amount of damage that the fishing rod should take.
     * This is not added to the pre-existing damage to be taken.
     * 
     * @param rodDamage The damage the rod will take. Must be nonnegative
     */
    public void damageRodBy(@Nonnegative int rodDamage) {
        Preconditions.checkArgument(rodDamage >= 0);
        this.rodDamage = rodDamage;
    }

    /**
     * Use this to get the items the player will receive.
     * You cannot use this to modify the drops the player will get.
     * If you want to affect the loot, you should use LootTables.
     */
    public DefaultedList<ItemStack> getDrops() {
        return stacks;
    }

    /**
     * Use this to stuff related to the hook itself, like the position of the bobber.
     */
    public FishingBobberEntity getHookEntity() {
        return hook;
    }
}
