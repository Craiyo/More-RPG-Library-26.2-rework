/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Fired by {@link InGameHud.HeartType#fromPlayerState} to allow mods to change the heart sprite which is displayed in the player's
 * health bar.
 *
 * <p>
 * This event is fired only on the client.
 */
public class PlayerHeartTypeEvent extends PlayerEvent {
    private final InGameHud.HeartType originalType;
    private InGameHud.HeartType type;

    public PlayerHeartTypeEvent(PlayerEntity player, InGameHud.HeartType type) {
        super(player);
        this.type = type;
        this.originalType = type;
    }

    /**
     * @return The original heart type which would be displayed by vanilla.
     */
    public InGameHud.HeartType getOriginalType() {
        return originalType;
    }

    /**
     * @return The heart type which will be displayed on the health bar.
     */
    public InGameHud.HeartType getType() {
        return type;
    }

    /**
     * Set the heart sprite which will be displayed on the {@link PlayerEntity}'s health bar.
     *
     * @param type The {@link InGameHud.HeartType} to display
     */
    public void setType(InGameHud.HeartType type) {
        this.type = type;
    }
}
