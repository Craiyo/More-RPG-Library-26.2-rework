/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.gui.map;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.MapDecorationsAtlasManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.map.MapDecoration;
import net.minecraft.item.map.MapState;

/**
 * Interface for custom {@link MapDecoration} renderers
 */
public interface IMapDecorationRenderer {
    /**
     * Render the given {@link MapDecoration} on the map. If this method returns true, the vanilla rendering will be
     * canceled. Otherwise, it will render above whatever is rendered in this method, if anything
     *
     * @param decoration         The decoration to be rendered
     * @param poseStack          The {@link MatrixStack} to render the decoration with
     * @param bufferSource       The {@link VertexConsumerProvider} to render the decoration with
     * @param mapData            The data of the map being rendered
     * @param decorationTextures The manager holding map decoration sprites
     * @param inItemFrame        Whether the map is being rendered in an item frame
     * @param packedLight        The packed light value
     * @param index              The z index of the decoration being rendered
     * @return true to cancel vanilla rendering
     */
    boolean render(
            MapDecoration decoration,
            MatrixStack poseStack,
            VertexConsumerProvider bufferSource,
            MapState mapData,
            MapDecorationsAtlasManager decorationTextures,
            boolean inItemFrame,
            int packedLight,
            int index);
}
