/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public final class ExtensibleEnumAcknowledgePayload implements CustomPayload {
    public static final Id<ExtensibleEnumAcknowledgePayload> TYPE = new Id<>(Identifier.of("neoforge", "extensible_enum_ack"));
    public static final ExtensibleEnumAcknowledgePayload INSTANCE = new ExtensibleEnumAcknowledgePayload();
    public static final PacketCodec<ByteBuf, ExtensibleEnumAcknowledgePayload> STREAM_CODEC = PacketCodec.unit(INSTANCE);

    private ExtensibleEnumAcknowledgePayload() {}

    @Override
    public Id<ExtensibleEnumAcknowledgePayload> getId() {
        return TYPE;
    }
}
