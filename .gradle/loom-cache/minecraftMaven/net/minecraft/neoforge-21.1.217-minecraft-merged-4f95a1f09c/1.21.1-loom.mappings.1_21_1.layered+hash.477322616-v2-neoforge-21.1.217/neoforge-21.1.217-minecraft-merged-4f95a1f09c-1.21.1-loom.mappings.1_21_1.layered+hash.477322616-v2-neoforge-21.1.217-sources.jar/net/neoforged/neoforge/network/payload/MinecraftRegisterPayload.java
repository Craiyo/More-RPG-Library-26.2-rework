/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.Set;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record MinecraftRegisterPayload(Set<Identifier> newChannels) implements CustomPayload {
    public static final Identifier ID = Identifier.ofVanilla("register");
    public static final Id<MinecraftRegisterPayload> TYPE = new Id<>(ID);
    public static final PacketCodec<PacketByteBuf, MinecraftRegisterPayload> STREAM_CODEC = DinnerboneProtocolUtils.CHANNELS_CODEC.xmap(MinecraftRegisterPayload::new, MinecraftRegisterPayload::newChannels);

    @Override
    public Id<MinecraftRegisterPayload> getId() {
        return TYPE;
    }
}
