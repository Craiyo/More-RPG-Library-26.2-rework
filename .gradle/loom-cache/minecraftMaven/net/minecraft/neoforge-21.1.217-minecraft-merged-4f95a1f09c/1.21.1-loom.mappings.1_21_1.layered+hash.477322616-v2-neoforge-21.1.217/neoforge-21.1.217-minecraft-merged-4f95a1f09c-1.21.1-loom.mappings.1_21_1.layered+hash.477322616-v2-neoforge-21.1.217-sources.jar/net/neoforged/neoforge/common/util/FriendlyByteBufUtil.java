/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.util;

import io.netty.buffer.Unpooled;
import java.util.function.Consumer;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.registry.DynamicRegistryManager;
import net.neoforged.neoforge.network.connection.ConnectionType;

/**
 * Utility class for working with {@link PacketByteBuf}s.
 */
public class FriendlyByteBufUtil {
    private FriendlyByteBufUtil() {
        throw new IllegalStateException("Tried to create utility class!");
    }

    /**
     * Writes custom data to a {@link RegistryByteBuf}, then returns the written data as a byte array.
     *
     * @param dataWriter     The data writer.
     * @param registryAccess The registry access used by registry dependent writers on the buffer
     * @return The written data.
     */
    public static byte[] writeCustomData(Consumer<RegistryByteBuf> dataWriter, DynamicRegistryManager registryAccess) {
        final RegistryByteBuf buf = new RegistryByteBuf(Unpooled.buffer(), registryAccess, ConnectionType.NEOFORGE);
        try {
            dataWriter.accept(buf);
            buf.readerIndex(0);
            final byte[] data = new byte[buf.readableBytes()];
            buf.readBytes(data);
            return data;
        } finally {
            buf.release();
        }
    }
}
