/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.model;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.neoforged.neoforge.client.extensions.IBakedModelExtension;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.jetbrains.annotations.Nullable;

/**
 * Convenience interface with default implementation of {@link IBakedModelExtension#getQuads(BlockState, Direction, Random, ModelData, RenderLayer)}.
 */
public interface IDynamicBakedModel extends BakedModel {
    @Override
    default List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, Random rand) {
        return getQuads(state, side, rand, ModelData.EMPTY, null);
    }

    // Force this to be overriden otherwise this introduces a default cycle between the two overloads.
    @Override
    List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, Random rand, ModelData extraData, @Nullable RenderLayer renderType);
}
