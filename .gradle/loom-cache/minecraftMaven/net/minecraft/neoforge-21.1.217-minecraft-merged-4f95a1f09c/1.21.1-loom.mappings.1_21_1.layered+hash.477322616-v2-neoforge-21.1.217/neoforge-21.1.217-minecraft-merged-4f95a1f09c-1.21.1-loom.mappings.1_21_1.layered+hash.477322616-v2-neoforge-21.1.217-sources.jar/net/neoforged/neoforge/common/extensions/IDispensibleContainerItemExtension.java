/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FluidModificationItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public interface IDispensibleContainerItemExtension {
    private FluidModificationItem self() {
        return (FluidModificationItem) this;
    }

    /**
     * Empties the contents of the container and returns whether it was successful.
     *
     * @param player    Player who empties the container. May be null for blocks like dispensers.
     * @param level     Level to place the content in
     * @param pos       The position in the level to empty the content
     * @param hitResult Hit result of the interaction. May be null for blocks like dispensers.
     * @param container ItemStack of the container. May be null for backwards compatibility.
     * @return true if emptying the contents of the container was successful, false otherwise
     */
    default boolean emptyContents(@Nullable PlayerEntity player, World level, BlockPos pos, @Nullable BlockHitResult hitResult, @Nullable ItemStack container) {
        return self().placeFluid(player, level, pos, hitResult);
    }
}
