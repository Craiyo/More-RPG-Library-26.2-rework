/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.network.NetworkPhase;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.registration.PayloadRegistration;
import org.jetbrains.annotations.ApiStatus;

/**
 * Payload for the modded network query request.
 * Sent clientbound with no data to ask for the client's channels. The client will then reply with {@link #fromRegistry(Map)}.
 *
 * @param queries The query components
 */
@ApiStatus.Internal
public record ModdedNetworkQueryPayload(Map<NetworkPhase, Set<ModdedNetworkQueryComponent>> queries) implements CustomPayload {
    public static final Identifier ID = Identifier.of(NeoForgeVersion.MOD_ID, "register");
    public static final Id<ModdedNetworkQueryPayload> TYPE = new Id<>(ID);
    public static PacketCodec<PacketByteBuf, ModdedNetworkQueryPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.map(IdentityHashMap::new,
                    PacketCodecs.indexed(b -> NetworkPhase.values()[b], NetworkPhase::ordinal),
                    PacketCodecs.collection(HashSet::new, ModdedNetworkQueryComponent.STREAM_CODEC)),
            ModdedNetworkQueryPayload::queries, ModdedNetworkQueryPayload::new);

    @Override
    public Id<ModdedNetworkQueryPayload> getId() {
        return TYPE;
    }

    public static ModdedNetworkQueryPayload fromRegistry(Map<NetworkPhase, Map<Identifier, PayloadRegistration<?>>> registry) {
        var queries = registry.entrySet().stream()
                .map(entry -> Map.entry(entry.getKey(), entry.getValue().values().stream().map(ModdedNetworkQueryComponent::new).collect(Collectors.toSet())))
                .collect(Collectors.toMap(Entry::getKey, Entry::getValue));
        return new ModdedNetworkQueryPayload(queries);
    }
}
