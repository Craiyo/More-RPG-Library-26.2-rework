/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.util.Map;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.neoforged.neoforge.registries.RegistryManager;
import net.neoforged.neoforge.registries.datamaps.DataMapType;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
@SuppressWarnings({ "unchecked", "rawtypes" })
public record RegistryDataMapSyncPayload<T>(RegistryKey<? extends Registry<T>> registryKey,
        Map<Identifier, Map<RegistryKey<T>, ?>> dataMaps) implements CustomPayload {
    public static final CustomPayload.Id<RegistryDataMapSyncPayload<?>> TYPE = new Id<>(Identifier.of("neoforge", "registry_data_map_sync"));
    public static final PacketCodec<RegistryByteBuf, RegistryDataMapSyncPayload<?>> STREAM_CODEC = PacketCodec.of(
            RegistryDataMapSyncPayload::write, RegistryDataMapSyncPayload::decode);

    public static <T> RegistryDataMapSyncPayload<T> decode(RegistryByteBuf buf) {
        //noinspection RedundantCast javac complains about this cast
        final RegistryKey<Registry<T>> registryKey = (RegistryKey<Registry<T>>) (Object) buf.readRegistryRefKey();
        final Map<Identifier, Map<RegistryKey<T>, ?>> attach = buf.readMap(PacketByteBuf::readIdentifier, (b1, key) -> {
            final DataMapType<T, ?> dataMap = RegistryManager.getDataMap(registryKey, key);
            return b1.readMap(bf -> bf.readRegistryKey(registryKey), bf -> readJsonWithRegistryCodec((RegistryByteBuf) bf, dataMap.networkCodec()));
        });
        return new RegistryDataMapSyncPayload<>(registryKey, attach);
    }

    public void write(RegistryByteBuf buf) {
        buf.writeRegistryKey(registryKey);
        buf.writeMap(dataMaps, PacketByteBuf::writeIdentifier, (b1, key, attach) -> {
            final DataMapType<T, ?> dataMap = RegistryManager.getDataMap(registryKey, key);
            // TODO - make datamaps use stream codecs once datapack registries use them too
            b1.writeMap(attach, PacketByteBuf::writeRegistryKey, (bf, value) -> writeJsonWithRegistryCodec((RegistryByteBuf) bf, (Codec) dataMap.networkCodec(), value));
        });
    }

    @Override
    public Id<RegistryDataMapSyncPayload<?>> getId() {
        return TYPE;
    }

    private static final Gson GSON = new Gson();

    private static <T> T readJsonWithRegistryCodec(RegistryByteBuf buf, Codec<T> codec) {
        JsonElement jsonelement = JsonHelper.deserialize(GSON, buf.readString(), JsonElement.class);
        DataResult<T> dataresult = codec.parse(buf.getRegistryManager().getOps(JsonOps.INSTANCE), jsonelement);
        return dataresult.getOrThrow(name -> new DecoderException("Failed to decode json: " + name));
    }

    private static <T> void writeJsonWithRegistryCodec(RegistryByteBuf buf, Codec<T> codec, T value) {
        DataResult<JsonElement> dataresult = codec.encodeStart(buf.getRegistryManager().getOps(JsonOps.INSTANCE), value);
        buf.writeString(GSON.toJson(dataresult.getOrThrow(message -> new EncoderException("Failed to encode: " + message + " " + value))));
    }
}
