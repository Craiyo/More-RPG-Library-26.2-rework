/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.world.poi;

import com.mojang.logging.LogUtils;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.poi.PointOfInterestType;
import net.neoforged.fml.ModLoader;
import net.neoforged.neoforge.registries.GameData;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.transformer.meta.MixinMerged;

@ApiStatus.Internal
public final class PoiTypeExtender {
    private static final Logger LOGGER = LogUtils.getLogger();

    public static void extendPoiTypes() {
        ModLoader.postEvent(new ExtendPoiTypesEvent(PoiTypeExtender::register));
    }

    private static void register(RegistryKey<PointOfInterestType> typeKey, Set<BlockState> states) {
        Map<BlockState, RegistryEntry<PointOfInterestType>> statePoiMap = GameData.getBlockStatePointOfInterestTypeMap();
        RegistryEntry<PointOfInterestType> type = Registries.POINT_OF_INTEREST_TYPE.entryOf(typeKey);
        for (BlockState state : states) {
            RegistryEntry<PointOfInterestType> prevType = statePoiMap.putIfAbsent(state, type);
            if (prevType != null) {
                throw new IllegalStateException(String.format(
                        Locale.ROOT,
                        "%s is defined in more than one PoI type (old: %s, new: %s)",
                        state,
                        prevType.value(),
                        type.value()));
            }
        }

        if (type.value().blockStates() instanceof PoiStateSet poiStateSet) {
            poiStateSet.addCustomStates(states);
        } else {
            // Detect accessor mixins which may have replaced the set to add additional BlockStates after the PoiType's construction
            List<String> accessors = Arrays.stream(PointOfInterestType.class.getDeclaredMethods())
                    .filter(method -> method.isSynthetic() &&
                            method.isAnnotationPresent(Accessor.class) &&
                            method.getReturnType() == void.class &&
                            method.getParameterCount() == 1 &&
                            method.getParameterTypes()[0] == Set.class)
                    .map(mth -> mth.getAnnotation(MixinMerged.class))
                    .filter(Objects::nonNull)
                    .map(MixinMerged::mixin)
                    .toList();

            String message;
            if (accessors.isEmpty()) {
                message = String.format(
                        Locale.ROOT,
                        "The matchingStates set of PoiType %s was replaced after construction, PoiType cannot be extended",
                        Objects.requireNonNull(type.getKey()).getValue());
            } else {
                StringBuilder accessorList = new StringBuilder();
                for (String accessor : accessors) {
                    accessorList.append("\n").append(accessor);
                }
                message = String.format(
                        Locale.ROOT,
                        "The matchingStates set of PoiType %s was replaced after construction, PoiType cannot be extended. Accessor mixins for mutating the set were found:%s",
                        Objects.requireNonNull(type.getKey()).getValue(),
                        accessorList);
            }
            LOGGER.error(message);
        }
    }

    private PoiTypeExtender() {}
}
