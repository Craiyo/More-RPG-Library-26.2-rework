/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common;

import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.component.ComponentChanges;
import net.minecraft.component.ComponentHolder;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import org.jetbrains.annotations.Nullable;

public interface MutableDataComponentHolder extends ComponentHolder {
    /**
     * Sets a data component.
     */
    @Nullable
    <T> T set(ComponentType<? super T> componentType, @Nullable T value);

    /**
     * Sets a data component.
     */
    @Nullable
    default <T> T set(Supplier<? extends ComponentType<? super T>> componentType, @Nullable T value) {
        return set(componentType.get(), value);
    }

    /**
     * Updates a data component if it exists, using an additional {@code updateContext}.
     */
    @Nullable
    default <T, U> T update(ComponentType<T> componentType, T value, U updateContext, BiFunction<T, U, T> updater) {
        return set(componentType, updater.apply(getOrDefault(componentType, value), updateContext));
    }

    /**
     * Updates a data component if it exists, using an additional {@code updateContext}.
     */
    @Nullable
    default <T, U> T update(Supplier<? extends ComponentType<T>> componentType, T value, U updateContext, BiFunction<T, U, T> updater) {
        return update(componentType.get(), value, updateContext, updater);
    }

    /**
     * Updates a data component if it exists.
     */
    @Nullable
    default <T> T update(ComponentType<T> componentType, T value, UnaryOperator<T> updater) {
        return set(componentType, updater.apply(getOrDefault(componentType, value)));
    }

    /**
     * Updates a data component if it exists.
     */
    @Nullable
    default <T> T update(Supplier<? extends ComponentType<T>> componentType, T value, UnaryOperator<T> updater) {
        return update(componentType.get(), value, updater);
    }

    /**
     * Removes a data component.
     */
    @Nullable
    <T> T remove(ComponentType<? extends T> componentType);

    /**
     * Removes a data component.
     */
    @Nullable
    default <T> T remove(Supplier<? extends ComponentType<? extends T>> componentType) {
        return remove(componentType.get());
    }

    /**
     * Copies all data components from {@code src}
     *
     * @implNote This will clear any components if the requested {@code src} holder does not contain a matching value.
     */
    default void copyFrom(ComponentHolder src, ComponentType<?>... componentTypes) {
        for (var componentType : componentTypes) {
            copyFrom(componentType, src);
        }
    }

    /**
     * Copies all data components from {@code src}
     *
     * @implNote This will clear any components if the requested {@code src} holder does not contain a matching value.
     */
    default void copyFrom(ComponentHolder src, Supplier<? extends ComponentType<?>>... componentTypes) {
        for (var componentType : componentTypes) {
            copyFrom(componentType.get(), src);
        }
    }

    /**
     * Applies a set of component changes to this stack.
     */
    void applyComponents(ComponentChanges patch);

    /**
     * Applies a set of component changes to this stack.
     */
    void applyComponents(ComponentMap components);

    private <T> void copyFrom(ComponentType<T> componentType, ComponentHolder src) {
        set(componentType, src.get(componentType));
    }
}
