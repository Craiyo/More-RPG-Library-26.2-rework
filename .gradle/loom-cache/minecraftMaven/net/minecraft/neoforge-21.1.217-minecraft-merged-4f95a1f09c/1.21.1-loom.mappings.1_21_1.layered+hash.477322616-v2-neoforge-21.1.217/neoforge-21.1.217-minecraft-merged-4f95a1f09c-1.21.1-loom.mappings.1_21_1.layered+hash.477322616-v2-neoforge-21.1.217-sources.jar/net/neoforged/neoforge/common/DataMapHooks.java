/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.HoneycombItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.registries.datamaps.DataMapsUpdatedEvent;
import net.neoforged.neoforge.registries.datamaps.builtin.NeoForgeDataMaps;
import net.neoforged.neoforge.registries.datamaps.builtin.Oxidizable;
import net.neoforged.neoforge.registries.datamaps.builtin.Waxable;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

// TODO: 1.21.2 remove fallback to vanilla map for waxing and oxidizing
public class DataMapHooks {
    // will be removed in 1.21.2
    /** Used in a gametest */
    @ApiStatus.Internal
    public static boolean didHaveToFallbackToVanillaMaps = false;

    private static final Map<Block, Block> INVERSE_OXIDIZABLES_DATAMAP_INTERNAL = new HashMap<>();
    private static final Map<Block, Block> INVERSE_WAXABLES_DATAMAP_INTERNAL = new HashMap<>();

    /** The inverse map of the oxidizables data map, used in vanilla when scraping oxidization off of a block */
    public static final Map<Block, Block> INVERSE_OXIDIZABLES_DATAMAP = Collections.unmodifiableMap(INVERSE_OXIDIZABLES_DATAMAP_INTERNAL);
    /** The inverse map of the waxables data map, used in vanilla when scraping wax off of a block */
    public static final Map<Block, Block> INVERSE_WAXABLES_DATAMAP = Collections.unmodifiableMap(INVERSE_WAXABLES_DATAMAP_INTERNAL);

    @Nullable
    @SuppressWarnings("deprecation")
    public static Block getNextOxidizedStage(Block block) {
        Oxidizable oxidizable = block.getRegistryEntry().getData(NeoForgeDataMaps.OXIDIZABLES);
        return oxidizable != null ? oxidizable.nextOxidationStage() : net.minecraft.block.Oxidizable.OXIDATION_LEVEL_INCREASES.get().get(block);
    }

    @Nullable
    @SuppressWarnings("deprecation")
    public static Block getPreviousOxidizedStage(Block block) {
        return INVERSE_OXIDIZABLES_DATAMAP.containsKey(block) ? INVERSE_OXIDIZABLES_DATAMAP.get(block) : net.minecraft.block.Oxidizable.OXIDATION_LEVEL_DECREASES.get().get(block);
    }

    @Nullable
    @SuppressWarnings("deprecation")
    public static Block getBlockWaxed(Block block) {
        Waxable waxable = block.getRegistryEntry().getData(NeoForgeDataMaps.WAXABLES);
        return waxable != null ? waxable.waxed() : HoneycombItem.UNWAXED_TO_WAXED_BLOCKS.get().get(block);
    }

    @Nullable
    @SuppressWarnings("deprecation")
    public static Block getBlockUnwaxed(Block block) {
        return INVERSE_WAXABLES_DATAMAP.containsKey(block) ? INVERSE_WAXABLES_DATAMAP.get(block) : HoneycombItem.WAXED_TO_UNWAXED_BLOCKS.get().get(block);
    }

    @SubscribeEvent
    static void onDataMapsUpdated(DataMapsUpdatedEvent event) {
        event.ifRegistry(RegistryKeys.BLOCK, registry -> {
            INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.clear();
            INVERSE_WAXABLES_DATAMAP_INTERNAL.clear();

            registry.getDataMap(NeoForgeDataMaps.OXIDIZABLES).forEach((resourceKey, oxidizable) -> {
                var block = Registries.BLOCK.get(resourceKey);

                INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(oxidizable.nextOxidationStage(), block);

                // Rebuild blockstate caches of oxidizables after datamaps are loaded so that they can recompute isRandomlyTicking while having access to the data map value
                // TODO - revisit this in the future if other datamaps will require rebuilding caches to avoid doing it multiple times
                for (BlockState state : block.getStateManager().getStates()) {
                    state.initShapeCache();
                }
            });

            //noinspection deprecation
            net.minecraft.block.Oxidizable.OXIDATION_LEVEL_DECREASES.get().forEach((after, before) -> {
                if (!INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.containsKey(after)) {
                    INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(after, before);
                    didHaveToFallbackToVanillaMaps = true;
                }
            });

            registry.getDataMap(NeoForgeDataMaps.WAXABLES).forEach((resourceKey, waxable) -> {
                INVERSE_WAXABLES_DATAMAP_INTERNAL.put(waxable.waxed(), Registries.BLOCK.get(resourceKey));
            });

            //noinspection deprecation
            HoneycombItem.WAXED_TO_UNWAXED_BLOCKS.get().forEach((after, before) -> {
                if (!INVERSE_WAXABLES_DATAMAP_INTERNAL.containsKey(after)) {
                    INVERSE_OXIDIZABLES_DATAMAP_INTERNAL.put(after, before);
                    didHaveToFallbackToVanillaMaps = true;
                }
            });
        });
    }
}
