/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.conditions;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public class ItemExistsCondition implements ICondition {
    public static MapCodec<ItemExistsCondition> CODEC = RecordCodecBuilder.mapCodec(
            builder -> builder
                    .group(
                            Identifier.CODEC.fieldOf("item").forGetter(ItemExistsCondition::getItem))
                    .apply(builder, ItemExistsCondition::new));

    private final Identifier item;

    public ItemExistsCondition(String location) {
        this(Identifier.of(location));
    }

    public ItemExistsCondition(String namespace, String path) {
        this(Identifier.of(namespace, path));
    }

    public ItemExistsCondition(Identifier item) {
        this.item = item;
    }

    @Override
    public boolean test(IContext context) {
        return Registries.ITEM.containsId(item);
    }

    @Override
    public MapCodec<? extends ICondition> codec() {
        return CODEC;
    }

    public Identifier getItem() {
        return item;
    }

    @Override
    public String toString() {
        return "item_exists(\"" + item + "\")";
    }
}
