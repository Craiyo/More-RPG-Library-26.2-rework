/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.advancements.critereon;

import com.mojang.serialization.MapCodec;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.predicate.entity.EntitySubPredicate;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

public class SnowBootsEntityPredicate implements EntitySubPredicate {
    public static final SnowBootsEntityPredicate INSTANCE = new SnowBootsEntityPredicate();
    public static final MapCodec<SnowBootsEntityPredicate> CODEC = MapCodec.unit(INSTANCE);

    private SnowBootsEntityPredicate() {}

    @Override
    public MapCodec<SnowBootsEntityPredicate> getCodec() {
        return CODEC;
    }

    @Override
    public boolean test(Entity entity, ServerWorld level, @Nullable Vec3d position) {
        return entity instanceof LivingEntity living && living.getEquippedStack(EquipmentSlot.FEET).canWalkOnPowderedSnow(living);
    }
}
