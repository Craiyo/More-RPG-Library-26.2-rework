/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LightningEntity;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.EventHooks;

/**
 * EntityStruckByLightningEvent is fired when an Entity is about to be struck by lightening.<br>
 * This event is fired whenever an EntityLightningBolt is updated to strike an Entity in
 * {@link LightningEntity#tick()} via {@link EventHooks#onEntityStruckByLightning(Entity, LightningEntity)}.<br>
 * <br>
 * {@link #lightning} contains the instance of EntityLightningBolt attempting to strike an entity.<br>
 * <br>
 * This event is {@link ICancellableEvent}.<br>
 * If this event is canceled, the Entity is not struck by the lightening.<br>
 * <br>
 * This event does not have a result. {@link HasResult}<br>
 * <br>
 * This event is fired on the {@link NeoForge#EVENT_BUS}.<br>
 **/
public class EntityStruckByLightningEvent extends EntityEvent implements ICancellableEvent {
    private final LightningEntity lightning;

    public EntityStruckByLightningEvent(Entity entity, LightningEntity lightning) {
        super(entity);
        this.lightning = lightning;
    }

    public LightningEntity getLightning() {
        return lightning;
    }
}
