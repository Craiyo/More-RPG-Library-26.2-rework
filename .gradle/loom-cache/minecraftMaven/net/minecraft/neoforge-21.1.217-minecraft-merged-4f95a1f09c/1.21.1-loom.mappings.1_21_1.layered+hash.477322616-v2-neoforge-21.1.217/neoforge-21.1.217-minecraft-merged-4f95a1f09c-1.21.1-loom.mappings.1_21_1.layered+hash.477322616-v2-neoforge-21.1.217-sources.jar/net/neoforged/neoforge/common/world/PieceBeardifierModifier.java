/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.world;

import net.minecraft.util.math.BlockBox;
import net.minecraft.world.gen.StructureTerrainAdaptation;

/** Implement this interface in a {@link net.minecraft.structure.StructurePiece} class extension to modify its {@link net.minecraft.world.gen.StructureWeightSampler} behavior. */
public interface PieceBeardifierModifier {
    BlockBox getBeardifierBox();

    StructureTerrainAdaptation getTerrainAdjustment();

    int getGroundLevelDelta();
}
