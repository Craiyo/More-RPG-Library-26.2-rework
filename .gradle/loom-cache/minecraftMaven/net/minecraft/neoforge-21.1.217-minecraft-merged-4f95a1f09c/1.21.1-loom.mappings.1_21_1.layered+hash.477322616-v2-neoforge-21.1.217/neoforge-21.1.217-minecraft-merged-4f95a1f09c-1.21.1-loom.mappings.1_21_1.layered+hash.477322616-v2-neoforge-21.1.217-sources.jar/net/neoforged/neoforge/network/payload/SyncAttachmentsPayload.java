/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.List;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.neoforged.neoforge.attachment.AttachmentSync;
import net.neoforged.neoforge.attachment.AttachmentType;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record SyncAttachmentsPayload(
        Target target,
        List<AttachmentType<?>> types,
        byte[] syncPayload)
        implements CustomPayload {

    public static final Id<SyncAttachmentsPayload> TYPE = new Id<>(Identifier.of(NeoForgeVersion.MOD_ID, "sync_attachments"));;
    public static final PacketCodec<RegistryByteBuf, SyncAttachmentsPayload> STREAM_CODEC = PacketCodec.tuple(
            Target.STREAM_CODEC,
            SyncAttachmentsPayload::target,
            PacketCodecs.registryValue(AttachmentSync.SYNCED_ATTACHMENT_TYPES.getKey()).collect(PacketCodecs.toList()),
            SyncAttachmentsPayload::types,
            NeoForgeStreamCodecs.UNBOUNDED_BYTE_ARRAY,
            SyncAttachmentsPayload::syncPayload,
            SyncAttachmentsPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return TYPE;
    }
    public sealed interface Target {
        PacketCodec<RegistryByteBuf, Target> STREAM_CODEC = StreamCodec.of(
                (buf, target) -> {
                    switch (target) {
                        case BlockEntityTarget(var pos) -> {
                            buf.writeByte(0);
                            buf.writeBlockPos(pos);
                        }
                        case ChunkTarget(var pos) -> {
                            buf.writeByte(1);
                            buf.writeChunkPos(pos);
                        }
                        case EntityTarget(var entityId) -> {
                            buf.writeByte(2);
                            buf.writeVarInt(entityId);
                        }
                        case LevelTarget() -> {
                            buf.writeByte(3);
                        }
                    }
                },
                buf -> {
                    int type = buf.readByte();
                    switch (type) {
                        case 0 -> {
                            return new BlockEntityTarget(buf.readBlockPos());
                        }
                        case 1 -> {
                            return new ChunkTarget(buf.readChunkPos());
                        }
                        case 2 -> {
                            return new EntityTarget(buf.readVarInt());
                        }
                        case 3 -> {
                            return new LevelTarget();
                        }
                        default -> throw new IllegalArgumentException("Unknown target type: " + type);
                    }
                });
    }

    public record BlockEntityTarget(BlockPos pos) implements Target {}

    public record ChunkTarget(ChunkPos pos) implements Target {}

    public record EntityTarget(int entity) implements Target {}

    public record LevelTarget() implements Target {}
}
