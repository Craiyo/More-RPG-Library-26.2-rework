/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.brewing;

import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.registry.DynamicRegistryManager;
import net.neoforged.bus.api.Event;
import org.jetbrains.annotations.ApiStatus;

/**
 * Event to register new brewing recipes.
 *
 * <p>Fired on both client and server side, on the main event bus.
 */
public class RegisterBrewingRecipesEvent extends Event {
    private final BrewingRecipeRegistry.Builder builder;
    private final DynamicRegistryManager registryAccess;

    @ApiStatus.Internal
    public RegisterBrewingRecipesEvent(BrewingRecipeRegistry.Builder builder, DynamicRegistryManager registryAccess) {
        this.builder = builder;
        this.registryAccess = registryAccess;
    }

    public BrewingRecipeRegistry.Builder getBuilder() {
        return builder;
    }

    public DynamicRegistryManager getRegistryAccess() {
        return registryAccess;
    }
}
