/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.items.wrapper;

import java.util.function.IntUnaryOperator;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Direction;
import net.neoforged.neoforge.items.IItemHandlerModifiable;
import org.jetbrains.annotations.Nullable;

public class SidedInvWrapper implements IItemHandlerModifiable {
    protected final SidedInventory inv;
    @Nullable
    protected final Direction side;

    private final IntUnaryOperator slotLimit;
    private final InsertLimit newStackInsertLimit;

    private interface InsertLimit {
        int limitInsert(int wrapperSlot, int invSlot, ItemStack stack);
    }

    public SidedInvWrapper(SidedInventory inv, @Nullable Direction side) {
        this.inv = inv;
        this.side = side;

        // A few special cases to account for canPlaceItem implementations attempting to limit specific inputs to 1,
        // by returning false if there's already a contained item. This doesn't work with modded inserted sizes > 1.
        // - Limit buckets to 1 in furnace fuel inputs.
        // - Limit brewing stand "bottle" inputs to 1.
        // Done using lambdas to avoid the overhead of instanceof checks in hot code.
        if (inv instanceof BrewingStandBlockEntity)
            this.slotLimit = wrapperSlot -> getSlot(inv, wrapperSlot, side) < 3 ? 1 : inv.getMaxCountPerStack();
        else
            this.slotLimit = wrapperSlot -> inv.getMaxCountPerStack();
        if (inv instanceof AbstractFurnaceBlockEntity)
            this.newStackInsertLimit = (wrapperSlot, invSlot, stack) -> invSlot == 1 && stack.isOf(Items.BUCKET) ? 1 : Math.min(stack.getMaxCount(), getSlotLimit(wrapperSlot));
        else
            this.newStackInsertLimit = (wrapperSlot, invSlot, stack) -> Math.min(stack.getMaxCount(), getSlotLimit(wrapperSlot));
    }

    public static int getSlot(SidedInventory inv, int slot, @Nullable Direction side) {
        if (side == null) {
            return slot;
        }
        int[] slots = inv.getAvailableSlots(side);
        if (slot < slots.length)
            return slots[slot];
        return -1;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        SidedInvWrapper that = (SidedInvWrapper) o;

        return inv.equals(that.inv) && side == that.side;
    }

    @Override
    public int hashCode() {
        int result = inv.hashCode();
        result = 31 * result + (side == null ? 0 : side.hashCode());
        return result;
    }

    @Override
    public int getSlots() {
        if (side == null) {
            return inv.size();
        }
        return inv.getAvailableSlots(side).length;
    }

    @Override
    public ItemStack getStackInSlot(int slot) {
        int i = getSlot(inv, slot, side);
        return i == -1 ? ItemStack.EMPTY : inv.getStack(i);
    }

    @Override
    public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
        if (stack.isEmpty())
            return ItemStack.EMPTY;

        int slot1 = getSlot(inv, slot, side);

        if (slot1 == -1)
            return stack;

        ItemStack stackInSlot = inv.getStack(slot1);

        int m;
        if (!stackInSlot.isEmpty()) {
            if (stackInSlot.getCount() >= Math.min(stackInSlot.getMaxCount(), getSlotLimit(slot)))
                return stack;

            if (!ItemStack.areItemsAndComponentsEqual(stack, stackInSlot))
                return stack;

            if (!inv.canInsert(slot1, stack, side) || !inv.isValid(slot1, stack))
                return stack;

            m = Math.min(stack.getMaxCount(), getSlotLimit(slot)) - stackInSlot.getCount();

            if (stack.getCount() <= m) {
                if (!simulate) {
                    ItemStack copy = stack.copy();
                    copy.increment(stackInSlot.getCount());
                    setInventorySlotContents(slot1, copy);
                }

                return ItemStack.EMPTY;
            } else {
                // copy the stack to not modify the original one
                stack = stack.copy();
                if (!simulate) {
                    ItemStack copy = stack.split(m);
                    copy.increment(stackInSlot.getCount());
                    setInventorySlotContents(slot1, copy);
                    return stack;
                } else {
                    stack.decrement(m);
                    return stack;
                }
            }
        } else {
            if (!inv.canInsert(slot1, stack, side) || !inv.isValid(slot1, stack))
                return stack;

            m = newStackInsertLimit.limitInsert(slot, slot1, stack);

            if (m < stack.getCount()) {
                // copy the stack to not modify the original one
                stack = stack.copy();
                if (!simulate) {
                    setInventorySlotContents(slot1, stack.split(m));
                    return stack;
                } else {
                    stack.decrement(m);
                    return stack;
                }
            } else {
                if (!simulate)
                    setInventorySlotContents(slot1, stack);
                return ItemStack.EMPTY;
            }
        }
    }

    @Override
    public void setStackInSlot(int slot, ItemStack stack) {
        int slot1 = getSlot(inv, slot, side);

        if (slot1 != -1)
            setInventorySlotContents(slot1, stack);
    }

    private void setInventorySlotContents(int slot, ItemStack stack) {
        inv.markDirty(); //Notify vanilla of updates, We change the handler to be responsible for this instead of the caller. So mimic vanilla behavior
        inv.setStack(slot, stack);
    }

    @Override
    public ItemStack extractItem(int slot, int amount, boolean simulate) {
        if (amount == 0)
            return ItemStack.EMPTY;

        int slot1 = getSlot(inv, slot, side);

        if (slot1 == -1)
            return ItemStack.EMPTY;

        ItemStack stackInSlot = inv.getStack(slot1);

        if (stackInSlot.isEmpty())
            return ItemStack.EMPTY;

        if (side != null && !inv.canExtract(slot1, stackInSlot, side))
            return ItemStack.EMPTY;

        if (simulate) {
            if (stackInSlot.getCount() < amount) {
                return stackInSlot.copy();
            } else {
                ItemStack copy = stackInSlot.copy();
                copy.setCount(amount);
                return copy;
            }
        } else {
            int m = Math.min(stackInSlot.getCount(), amount);
            ItemStack ret = inv.removeStack(slot1, m);
            inv.markDirty();
            return ret;
        }
    }

    @Override
    public int getSlotLimit(int slot) {
        return slotLimit.applyAsInt(slot);
    }

    @Override
    public boolean isItemValid(int slot, ItemStack stack) {
        int slot1 = getSlot(inv, slot, side);
        return slot1 == -1 ? false : inv.isValid(slot1, stack);
    }
}
