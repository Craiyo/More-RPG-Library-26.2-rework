/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event;

import com.google.common.collect.ImmutableList;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.ResourceManager;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.server.DataPackContents;
import net.minecraft.util.profiler.Profiler;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.ModLoader;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.resource.ContextAwareReloadListener;

/**
 * The main ResourceManager is recreated on each reload, just after {@link DataPackContents}'s creation.
 *
 * The event is fired on each reload and lets modders add their own ReloadListeners, for server-side resources.
 * The event is fired on the {@link NeoForge#EVENT_BUS}
 */
public class AddReloadListenerEvent extends Event {
    private final List<ResourceReloader> listeners = new ArrayList<>();
    private final DataPackContents serverResources;
    private final DynamicRegistryManager registryAccess;

    public AddReloadListenerEvent(DataPackContents serverResources, DynamicRegistryManager registryAccess) {
        this.serverResources = serverResources;
        this.registryAccess = registryAccess;
    }

    /**
     * @param listener the listener to add to the ResourceManager on reload
     */
    public void addListener(ResourceReloader listener) {
        listeners.add(new WrappedStateAwareListener(listener));
    }

    public List<ResourceReloader> getListeners() {
        return ImmutableList.copyOf(listeners);
    }

    /**
     * @return The ReloableServerResources being reloaded.
     */
    public DataPackContents getServerResources() {
        return serverResources;
    }

    /**
     * This context object holds data relevant to the current reload, such as staged tags.
     * 
     * @return The condition context for the currently active reload.
     */
    public ICondition.IContext getConditionContext() {
        return serverResources.getConditionContext();
    }

    /**
     * Provides access to the loaded registries associated with these server resources.
     * All built-in and dynamic registries are loaded and frozen by this point.
     * 
     * @return The RegistryAccess context for the currently active reload.
     */
    public DynamicRegistryManager getRegistryAccess() {
        return registryAccess;
    }

    private static class WrappedStateAwareListener extends ContextAwareReloadListener implements ResourceReloader {
        private final ResourceReloader wrapped;

        private WrappedStateAwareListener(final ResourceReloader wrapped) {
            this.wrapped = wrapped;
        }

        @Override
        public void injectContext(ICondition.IContext context, RegistryWrapper.WrapperLookup registryLookup) {
            if (this.wrapped instanceof ContextAwareReloadListener contextAwareListener) {
                contextAwareListener.injectContext(context, registryLookup);
            }
        }

        @Override
        public CompletableFuture<Void> reload(final Synchronizer stage, final ResourceManager resourceManager, final Profiler preparationsProfiler, final Profiler reloadProfiler, final Executor backgroundExecutor, final Executor gameExecutor) {
            if (!ModLoader.hasErrors())
                return wrapped.reload(stage, resourceManager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
            else
                return CompletableFuture.completedFuture(null);
        }
    }
}
