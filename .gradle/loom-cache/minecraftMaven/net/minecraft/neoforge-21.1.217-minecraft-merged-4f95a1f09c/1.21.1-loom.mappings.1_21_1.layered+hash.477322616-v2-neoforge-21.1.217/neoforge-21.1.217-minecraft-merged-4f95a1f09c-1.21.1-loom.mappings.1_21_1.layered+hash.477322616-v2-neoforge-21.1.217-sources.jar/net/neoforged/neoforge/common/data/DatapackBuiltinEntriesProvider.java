/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.DynamicRegistriesProvider;
import net.minecraft.registry.ExperimentalRegistriesValidator;
import net.minecraft.registry.RegistryBuilder;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.neoforged.neoforge.common.conditions.ICondition;

/**
 * An extension of the {@link DynamicRegistriesProvider} which properly handles
 * referencing existing dynamic registry objects within another dynamic registry
 * object.
 */
public class DatapackBuiltinEntriesProvider extends DynamicRegistriesProvider {
    private final CompletableFuture<RegistryWrapper.WrapperLookup> fullRegistries;

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder.
     *
     * @param output     the target directory of the data generator
     * @param registries a future of a lookup for registries and their objects
     * @param modIds     a set of mod ids to generate the dynamic registry objects of
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryBuilder.FullPatchesRegistriesPair> registries, Set<String> modIds) {
        this(output, registries, (b) -> {}, modIds);
    }

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder.
     *
     * @param output            the target directory of the data generator
     * @param registries        a future of a lookup for registries and their objects
     * @param modIds            a set of mod ids to generate the dynamic registry objects of
     * @param conditionsBuilder a builder for conditions to append to registry objects
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryBuilder.FullPatchesRegistriesPair> registries, Consumer<BiConsumer<RegistryKey<?>, ICondition>> conditionsBuilder, Set<String> modIds) {
        this(output, registries, buildConditionsMap(conditionsBuilder), modIds);
    }

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder.
     *
     * @param output     the target directory of the data generator
     * @param registries a future of a lookup for registries and their objects
     * @param modIds     a set of mod ids to generate the dynamic registry objects of
     * @param conditions a map containing conditions to append to registry objects
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryBuilder.FullPatchesRegistriesPair> registries, Map<RegistryKey<?>, List<ICondition>> conditions, Set<String> modIds) {
        super(output, registries.thenApply(RegistryBuilder.FullPatchesRegistriesPair::patches), modIds, conditions);
        this.fullRegistries = registries.thenApply(RegistryBuilder.FullPatchesRegistriesPair::full);
    }

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder. All entries that need to be
     * bootstrapped are provided within the {@link RegistryBuilder}.
     *
     * @param output                 the target directory of the data generator
     * @param registries             a future of a lookup for registries and their objects
     * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
     * @param modIds                 a set of mod ids to generate the dynamic registry objects of
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, RegistryBuilder datapackEntriesBuilder, Set<String> modIds) {
        this(output, ExperimentalRegistriesValidator.validate(registries, datapackEntriesBuilder), modIds);
    }

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder. All entries that need to be
     * bootstrapped are provided within the {@link RegistryBuilder}.
     *
     * @param output                 the target directory of the data generator
     * @param registries             a future of a lookup for registries and their objects
     * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
     * @param conditions             a map containing conditions to append to registry objects
     * @param modIds                 a set of mod ids to generate the dynamic registry objects of
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, RegistryBuilder datapackEntriesBuilder, Map<RegistryKey<?>, List<ICondition>> conditions, Set<String> modIds) {
        this(output, ExperimentalRegistriesValidator.validate(registries, datapackEntriesBuilder), conditions, modIds);
    }

    /**
     * Constructs a new datapack provider which generates all registry objects
     * from the provided mods using the holder. All entries that need to be
     * bootstrapped are provided within the {@link RegistryBuilder}.
     *
     * @param output                 the target directory of the data generator
     * @param registries             a future of a lookup for registries and their objects
     * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
     * @param conditionsBuilder      a builder for conditions to append to registry objects
     * @param modIds                 a set of mod ids to generate the dynamic registry objects of
     */
    public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, RegistryBuilder datapackEntriesBuilder, Consumer<BiConsumer<RegistryKey<?>, ICondition>> conditionsBuilder, Set<String> modIds) {
        this(output, ExperimentalRegistriesValidator.validate(registries, datapackEntriesBuilder), conditionsBuilder, modIds);
    }

    /**
     * Get the registry holder lookup provider that includes elements added from the {@link RegistryBuilder}
     */
    public CompletableFuture<RegistryWrapper.WrapperLookup> getRegistryProvider() {
        return fullRegistries;
    }

    private static Map<RegistryKey<?>, List<ICondition>> buildConditionsMap(Consumer<BiConsumer<RegistryKey<?>, ICondition>> conditionBuilder) {
        Map<RegistryKey<?>, List<ICondition>> conditions = new IdentityHashMap<>();
        conditionBuilder.accept((key, condition) -> conditions.computeIfAbsent(key, k -> new ArrayList<>()).add(condition));
        return conditions;
    }
}
