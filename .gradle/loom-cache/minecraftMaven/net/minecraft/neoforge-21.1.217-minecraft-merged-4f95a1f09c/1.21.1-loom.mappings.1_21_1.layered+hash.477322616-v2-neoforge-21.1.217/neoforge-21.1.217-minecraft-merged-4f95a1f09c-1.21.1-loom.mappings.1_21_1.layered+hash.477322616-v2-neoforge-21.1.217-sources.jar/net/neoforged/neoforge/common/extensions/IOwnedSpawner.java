/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import com.mojang.datafixers.util.Either;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.TrialSpawnerBlockEntity;
import net.minecraft.block.spawner.MobSpawnerLogic;
import net.minecraft.block.spawner.TrialSpawnerLogic;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.SpawnerMinecartEntity;
import org.jetbrains.annotations.Nullable;

public interface IOwnedSpawner {
    /**
     * Returns the block entity or entity which owns this spawner object.
     * <p>
     * For a {@link MobSpawnerLogic}, this is the {@link MobSpawnerBlockEntity} or {@link SpawnerMinecartEntity}.
     * <p>
     * For a {@link TrialSpawnerLogic}, this is the {@link TrialSpawnerBlockEntity}.
     */
    @Nullable
    Either<BlockEntity, Entity> getOwner();
}
