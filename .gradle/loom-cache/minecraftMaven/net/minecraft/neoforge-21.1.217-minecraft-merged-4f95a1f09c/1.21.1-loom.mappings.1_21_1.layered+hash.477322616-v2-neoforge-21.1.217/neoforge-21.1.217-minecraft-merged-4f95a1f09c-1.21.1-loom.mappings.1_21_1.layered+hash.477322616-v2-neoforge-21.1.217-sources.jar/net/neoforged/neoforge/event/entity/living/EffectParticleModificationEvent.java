/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.living;

import java.util.Objects;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.particle.ParticleEffect;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.Nullable;

/**
 * Fires for each effect to allow modification or replacement of the particle options (you can set it to null to reset it to default).
 * <br>
 * This event is not {@link ICancellableEvent}.
 * <br>
 * This event is fired on the {@link NeoForge#EVENT_BUS}.
 */
public class EffectParticleModificationEvent extends LivingEvent {
    private final StatusEffectInstance effect;
    private final ParticleEffect originalOptions;
    private ParticleEffect options;
    private boolean isVisible;

    public EffectParticleModificationEvent(LivingEntity entity, StatusEffectInstance effect) {
        super(entity);
        this.effect = effect;
        this.isVisible = effect.shouldShowParticles();
        this.originalOptions = effect.createParticle();
        this.options = this.originalOptions;
    }

    public StatusEffectInstance getEffect() {
        return effect;
    }

    public ParticleEffect getOriginalParticleOptions() {
        return originalOptions;
    }

    public ParticleEffect getParticleOptions() {
        return options;
    }

    public void setParticleOptions(@Nullable ParticleEffect options) {
        this.options = Objects.requireNonNullElse(options, originalOptions);
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }
}
