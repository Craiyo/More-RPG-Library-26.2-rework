/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Shearable;
import net.minecraft.entity.mob.BoggedEntity;
import net.minecraft.entity.passive.MooshroomEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * This interfaces allows shears (modded & vanilla) and {@linkplain Entity entities} (modded & vanilla) to cooperate
 * without needing advance knowledge of each other.
 * <p>
 * In the future, this system may function for implementations on {@link Block}s as well.
 *
 * TODO: Implement support for {@link Block} or remove default implementations from vanilla block classes.
 */
public interface IShearable {
    /**
     * Checks if this object can be sheared.
     * <p>
     * For example, Sheep return false when they have no wool.
     *
     * @param item  The shear tool that is being used, may be empty.
     * @param level The current level.
     * @param pos   The block position of this object (if this is an entity, the value of {@link Entity#getBlockPos()}.
     * @return If this is shearable, and {@link #onSheared} may be called.
     */
    default boolean isShearable(@Nullable PlayerEntity player, ItemStack item, World level, BlockPos pos) {
        // Default to checking readyForShearing if we are the vanilla shearable interface, and if we aren't assume a default of true
        return !(this instanceof Shearable shearable) || shearable.isShearable();
    }

    /**
     * Shears this object. This function is called on both sides, and is responsible for performing any and all actions that happen when sheared, except spawning drops.
     * <p>
     * Drops that are spawned as a result of being sheared should be returned from this method, and will be spawned on the server using {@link #spawnShearedDrop}.
     * <p>
     * {@linkplain Entity Entities} may respect their internal position values instead of relying on the {@code pos} parameter.
     *
     * @param item  The shear tool that is being used, may be empty.
     * @param level The current level.
     * @param pos   The block position of this object (if this is an entity, the value of {@link Entity#getBlockPos()}.
     * @return A list holding all dropped items resulting from the shear operation, or an empty list if nothing dropped.
     */
    @SuppressWarnings("deprecation") // Expected call to deprecated vanilla Shearable#shear
    default List<ItemStack> onSheared(@Nullable PlayerEntity player, ItemStack item, World level, BlockPos pos) {
        if (this instanceof LivingEntity entity && this instanceof Shearable shearable) {
            if (!level.isClient) {
                Collection<ItemEntity> previous = entity.captureDrops(new ArrayList<>());
                shearable.sheared(player == null ? SoundCategory.BLOCKS : SoundCategory.PLAYERS);
                return entity.captureDrops(previous).stream().map(ItemEntity::getStack).toList();
            }
        }
        return Collections.emptyList();
    }

    /**
     * Performs the logic used to drop a shear result into the world at the correct position and with the proper movement.
     * <br>
     * {@linkplain Entity Entities} may respect their internal position values instead of relying on the {@code pos} parameter.
     *
     * @param level The current level.
     * @param pos   The block position of this object (if this is an entity, the value of {@link Entity#getBlockPos()}.
     * @param drop  The stack to drop, from the list of drops returned by {@link #onSheared}.
     */
    default void spawnShearedDrop(World level, BlockPos pos, ItemStack drop) {
        if (this instanceof SnowGolemEntity golem) {
            // SnowGolem#shear uses spawnAtLocation(..., this.getEyeHeight());
            golem.dropStack(drop, golem.getStandingEyeHeight());
        } else if (this instanceof BoggedEntity bogged) {
            // Bogged#spawnShearedMushrooms uses spawnAtLocation(..., this.getBbHeight());
            bogged.dropStack(drop, bogged.getHeight());
        } else if (this instanceof MooshroomEntity cow) {
            // We patch Mooshrooms from using addFreshEntity to spawnAtLocation to spawnAtLocation to capture the drops.
            // In case a mod is also capturing drops, we also replicate that logic here.
            ItemEntity itemEntity = cow.dropStack(drop, cow.getHeight());
            if (itemEntity != null) {
                itemEntity.resetPickupDelay();
            }
        } else if (this instanceof Entity entity) {
            // Everything else uses the "default" rules invented by Sheep#shear, which uses a y-offset of 1 and these random delta movement values.
            ItemEntity itemEntity = entity.dropStack(drop, 1);
            if (itemEntity != null) {
                Random rand = entity.getRandom();
                Vec3d newDelta = itemEntity.getVelocity().add(
                        (rand.nextFloat() - rand.nextFloat()) * 0.1F,
                        rand.nextFloat() * 0.05F,
                        (rand.nextFloat() - rand.nextFloat()) * 0.1F);
                itemEntity.setVelocity(newDelta);
            }
        } else {
            // If we aren't an entity, fallback to spawning the item at the given position.
            level.spawnEntity(new ItemEntity(level, pos.getX(), pos.getY(), pos.getZ(), drop));
        }
    }
}
