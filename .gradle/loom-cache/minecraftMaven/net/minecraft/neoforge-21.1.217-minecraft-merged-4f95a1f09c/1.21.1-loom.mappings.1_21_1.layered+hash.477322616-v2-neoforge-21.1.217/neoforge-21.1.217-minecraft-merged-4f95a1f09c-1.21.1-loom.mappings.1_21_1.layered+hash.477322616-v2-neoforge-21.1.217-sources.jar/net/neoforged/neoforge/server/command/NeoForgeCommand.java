/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.server.command.ServerCommandSource;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public class NeoForgeCommand {
    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                LiteralArgumentBuilder.<ServerCommandSource>literal("neoforge")
                        .then(TPSCommand.register())
                        .then(TrackCommand.register())
                        .then(EntityCommand.register())
                        .then(GenerateCommand.register())
                        .then(DimensionsCommand.register())
                        .then(ModListCommand.register())
                        .then(TagsCommand.register())
                        .then(DumpCommand.register())
                        .then(TimeSpeedCommand.register())
                        .then(DataComponentCommand.register()));
    }
}
