/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.world;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.biome.GenerationSettings;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.carver.ConfiguredCarver;
import net.minecraft.world.gen.feature.PlacedFeature;

public class BiomeGenerationSettingsBuilder extends GenerationSettings.Builder {
    public BiomeGenerationSettingsBuilder(GenerationSettings orig) {
        orig.getCarvingStages().forEach(k -> {
            carverStepsToCarvers.put(k, new ArrayList<>());
            orig.getCarversForStep(k).forEach(v -> carverStepsToCarvers.get(k).add(v));
        });
        orig.getFeatures().forEach(l -> {
            final ArrayList<RegistryEntry<PlacedFeature>> featureList = new ArrayList<>();
            l.forEach(featureList::add);
            indexedFeaturesList.add(featureList);
        });
    }

    public List<RegistryEntry<PlacedFeature>> getFeatures(GenerationStep.Feature stage) {
        fillFeaturesList(stage.ordinal());
        return indexedFeaturesList.get(stage.ordinal());
    }

    public List<RegistryEntry<ConfiguredCarver<?>>> getCarvers(GenerationStep.Carver stage) {
        return carverStepsToCarvers.computeIfAbsent(stage, key -> new ArrayList<>());
    }
}
