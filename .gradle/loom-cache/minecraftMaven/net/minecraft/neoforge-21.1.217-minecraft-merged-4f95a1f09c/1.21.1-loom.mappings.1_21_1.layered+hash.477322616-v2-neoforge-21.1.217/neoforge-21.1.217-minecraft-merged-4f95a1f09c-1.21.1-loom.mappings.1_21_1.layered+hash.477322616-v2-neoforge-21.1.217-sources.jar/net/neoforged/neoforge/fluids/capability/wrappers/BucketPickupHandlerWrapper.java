/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.fluids.capability.wrappers;

import net.minecraft.block.FluidDrainable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.BucketItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BucketPickupHandlerWrapper implements IFluidHandler {
    private static final Logger LOGGER = LogManager.getLogger();

    protected final PlayerEntity player;
    protected final FluidDrainable bucketPickupHandler;
    protected final World world;
    protected final BlockPos blockPos;

    public BucketPickupHandlerWrapper(PlayerEntity player, FluidDrainable bucketPickupHandler, World world, BlockPos blockPos) {
        this.player = player;
        this.bucketPickupHandler = bucketPickupHandler;
        this.world = world;
        this.blockPos = blockPos;
    }

    @Override
    public int getTanks() {
        return 1;
    }

    @Override
    public FluidStack getFluidInTank(int tank) {
        if (tank == 0) {
            //Best guess at stored fluid
            FluidState fluidState = world.getFluidState(blockPos);
            if (!fluidState.isEmpty()) {
                return new FluidStack(fluidState.getFluid(), FluidType.BUCKET_VOLUME);
            }
        }
        return FluidStack.EMPTY;
    }

    @Override
    public int getTankCapacity(int tank) {
        return FluidType.BUCKET_VOLUME;
    }

    @Override
    public boolean isFluidValid(int tank, FluidStack stack) {
        return true;
    }

    @Override
    public int fill(FluidStack resource, FluidAction action) {
        return 0;
    }

    @Override
    public FluidStack drain(FluidStack resource, FluidAction action) {
        if (!resource.isEmpty() && FluidType.BUCKET_VOLUME <= resource.getAmount()) {
            FluidState fluidState = world.getFluidState(blockPos);
            if (!fluidState.isEmpty() && resource.is(fluidState.getFluid())) {
                if (action.execute()) {
                    ItemStack itemStack = bucketPickupHandler.tryDrainFluid(player, world, blockPos, world.getBlockState(blockPos));
                    if (itemStack != ItemStack.EMPTY && itemStack.getItem() instanceof BucketItem bucket) {
                        FluidStack extracted = new FluidStack(bucket.fluid, FluidType.BUCKET_VOLUME);
                        if (!FluidStack.isSameFluidSameComponents(resource, extracted)) {
                            //Be loud if something went wrong
                            LOGGER.error("Fluid removed without successfully being picked up. Fluid {} at {} in {} matched requested type, but after performing pickup was {}.",
                                    Registries.FLUID.getId(fluidState.getFluid()), blockPos, world.getRegistryKey().getValue(), Registries.FLUID.getId(bucket.fluid));
                            return FluidStack.EMPTY;
                        }
                        return extracted;
                    }
                } else {
                    FluidStack extracted = new FluidStack(fluidState.getFluid(), FluidType.BUCKET_VOLUME);
                    if (FluidStack.isSameFluid(resource, extracted)) {
                        //Validate NBT matches
                        return extracted;
                    }
                }
            }
        }
        return FluidStack.EMPTY;
    }

    @Override
    public FluidStack drain(int maxDrain, FluidAction action) {
        if (FluidType.BUCKET_VOLUME <= maxDrain) {
            FluidState fluidState = world.getFluidState(blockPos);
            if (!fluidState.isEmpty()) {
                if (action.simulate()) {
                    return new FluidStack(fluidState.getFluid(), FluidType.BUCKET_VOLUME);
                }
                ItemStack itemStack = bucketPickupHandler.tryDrainFluid(player, world, blockPos, world.getBlockState(blockPos));
                if (itemStack != ItemStack.EMPTY && itemStack.getItem() instanceof BucketItem bucket) {
                    return new FluidStack(bucket.fluid, FluidType.BUCKET_VOLUME);
                }
            }
        }
        return FluidStack.EMPTY;
    }
}
