/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.configuration;

import java.util.function.Consumer;
import net.minecraft.network.listener.ServerConfigurationPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.ConfigSync;
import org.jetbrains.annotations.ApiStatus;

/**
 * Configuration task that syncs the config files to the client
 * 
 * @param listener the listener to indicate to that the task is complete
 */
@ApiStatus.Internal
public record SyncConfig(ServerConfigurationPacketListener listener) implements ICustomConfigurationTask {
    private static final Identifier ID = Identifier.of(NeoForgeVersion.MOD_ID, "sync_config");
    public static Key TYPE = new Key(ID);

    @Override
    public void run(Consumer<CustomPayload> sender) {
        ConfigSync.syncConfigs().forEach(sender);
        listener().finishCurrentTask(getKey());
    }

    @Override
    public Key getKey() {
        return TYPE;
    }
}
