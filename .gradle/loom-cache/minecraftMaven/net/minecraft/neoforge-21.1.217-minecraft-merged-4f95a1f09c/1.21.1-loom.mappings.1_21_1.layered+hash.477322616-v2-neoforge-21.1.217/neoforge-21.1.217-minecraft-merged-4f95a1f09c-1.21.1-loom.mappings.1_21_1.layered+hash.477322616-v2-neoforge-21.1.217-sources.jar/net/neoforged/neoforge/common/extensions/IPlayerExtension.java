/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import java.util.OptionalInt;
import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.neoforged.neoforge.common.NeoForgeMod;
import net.neoforged.neoforge.common.util.FakePlayer;
import net.neoforged.neoforge.network.IContainerFactory;

public interface IPlayerExtension {
    private PlayerEntity self() {
        return (PlayerEntity) this;
    }

    /**
     * Utility check to see if the player is close enough to a target entity. Uses "eye-to-closest-corner" checks.
     * 
     * @param entity The entity being checked against
     * @param dist   The max distance allowed
     * @return If the eye-to-center distance between this player and the passed entity is less than dist.
     * @implNote This method inflates the bounding box by the pick radius, which differs from vanilla. But vanilla doesn't use the pick radius, the only entity with > 0 is AbstractHurtingProjectile.
     */
    default boolean isCloseEnough(Entity entity, double dist) {
        Vec3d eye = self().getEyePos();
        Box aabb = entity.getBoundingBox().expand(entity.getTargetingMargin());
        return aabb.squaredMagnitude(eye) < dist * dist;
    }

    /**
     * Request to open a GUI on the client, from the server
     * <p>
     * Refer to {@link ScreenHandlerType#create(IContainerFactory)} for creating a {@link ScreenHandlerType} that can consume the
     * extra data sent to the client by this method.
     * <p>
     * Use {@link PacketByteBuf#readBlockPos()} to read the position you pass to this method.
     *
     * @param menuProvider A supplier of container properties including the registry name of the container
     * @param pos          A block pos, which will be encoded into the additional data for this request, after
     *                     data written by {@link IMenuProviderExtension#writeClientSideData(AbstractContainerMenu, RegistryFriendlyByteBuf)}.
     *
     */
    default OptionalInt openMenu(NamedScreenHandlerFactory menuProvider, BlockPos pos) {
        return openMenu(menuProvider, buf -> buf.writeBlockPos(pos));
    }

    /**
     * Request to open a GUI on the client, from the server
     * <p>
     * Refer to {@link ScreenHandlerType#create(IContainerFactory)} for creating a {@link ScreenHandlerType} that can consume the
     * extra data sent to the client by this method.
     * <p>
     * The maximum size for #extraDataWriter is 32600 bytes.
     *
     * @param menuProvider    A supplier of container properties including the registry name of the container
     * @param extraDataWriter Consumer to write any additional data the GUI needs.
     *                        This data is written after {@link IMenuProviderExtension#writeClientSideData(AbstractContainerMenu, RegistryFriendlyByteBuf)}.
     * @return The window ID of the opened GUI, or empty if the GUI could not be opened
     */
    default OptionalInt openMenu(NamedScreenHandlerFactory menuProvider, Consumer<RegistryByteBuf> extraDataWriter) {
        return OptionalInt.empty();
    }

    /**
     * Determine whether a player is allowed creative flight via game mode or attribute.
     * <p>
     * Modders are discouraged from setting {@link PlayerAbilities#allowFlying} directly.
     *
     * @return true when creative flight is available
     * @see NeoForgeMod#CREATIVE_FLIGHT
     */
    @SuppressWarnings("deprecation")
    default boolean mayFly() {
        // TODO 1.20.5: consider forcing mods to use the attribute
        return self().getAbilities().allowFlying || self().getAttributeValue(NeoForgeMod.CREATIVE_FLIGHT) > 0;
    }

    /**
     * {@return whether this player is a fake player, such as {@link FakePlayer}}
     */
    default boolean isFakePlayer() {
        return false;
    }
}
