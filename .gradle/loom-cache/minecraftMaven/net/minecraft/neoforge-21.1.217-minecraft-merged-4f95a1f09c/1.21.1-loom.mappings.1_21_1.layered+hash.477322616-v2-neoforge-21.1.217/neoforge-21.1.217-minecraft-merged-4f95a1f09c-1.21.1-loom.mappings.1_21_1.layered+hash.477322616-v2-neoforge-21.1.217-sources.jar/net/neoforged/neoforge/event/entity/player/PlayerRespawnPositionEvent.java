/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import java.util.Objects;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.TeleportTarget;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;

/**
 * Fired by {@link PlayerManager#respawnPlayer(ServerPlayerEntity, boolean)} before the server respawns a player.
 * This may be used to change the {@link ServerWorld} the player respawns in, as well as their respawn position.
 * This event is fired after {@link BlockState#getRespawnPosition(EntityType, WorldView, BlockPos, float, LivingEntity)} is called.
 * <p>
 * This event is only fired on the logical server.
 */
public class PlayerRespawnPositionEvent extends PlayerEvent {
    private TeleportTarget dimensionTransition;
    private final TeleportTarget originalDimensionTransition;
    private final boolean fromEndFight;
    private boolean copyOriginalSpawnPosition;

    public PlayerRespawnPositionEvent(ServerPlayerEntity player, TeleportTarget dimensionTransition, boolean fromEndFight) {
        super(player);
        this.dimensionTransition = dimensionTransition;
        this.originalDimensionTransition = dimensionTransition;
        this.fromEndFight = fromEndFight;
        this.copyOriginalSpawnPosition = !this.originalDimensionTransition.missingRespawnBlock();
    }

    /**
     * @return The dimension transition for where the player will respawn
     */
    public TeleportTarget getDimensionTransition() {
        return dimensionTransition;
    }

    /**
     * Set the dimension transition for where the player will respawn
     * 
     * @param dimensionTransition The new dimension transition.
     */
    public void setDimensionTransition(TeleportTarget dimensionTransition) {
        this.dimensionTransition = dimensionTransition;
    }

    /**
     * Set the level the player will respawn into using a {@link RegistryKey}.
     * 
     * @param respawnLevelResourceKey The {@link RegistryKey} of the level to respawn into.
     */
    public void setRespawnLevel(RegistryKey<World> respawnLevelResourceKey) {
        MinecraftServer server = Objects.requireNonNull(
                getEntity().getServer(), "The player is not in a ServerLevel somehow?");
        ServerWorld level = Objects.requireNonNull(
                server.getWorld(respawnLevelResourceKey), "Level " + respawnLevelResourceKey + " does not exist!");
        TeleportTarget dt = getDimensionTransition();
        setDimensionTransition(new TeleportTarget(level, dt.pos(), dt.velocity(), dt.yaw(), dt.pitch(), dt.postDimensionTransition()));
    }

    /**
     * @return The dimension transition the server originally intended to respawn the player to.
     */
    public TeleportTarget getOriginalDimensionTransition() {
        return originalDimensionTransition;
    }

    /**
     * If the respawn position of the original player will be copied to the fresh player via {@link ServerPlayerEntity#setSpawnPointFrom(ServerPlayerEntity)}.
     * <p>
     * This defaults to true if the {@linkplain #getOriginalDimensionTransition() original dimension transition}
     * was not {@linkplain TeleportTarget#missingRespawnBlock() missing a respawn block}.
     * <p>
     * This has no impact on the selected position for the current respawn, but controls if the player will (for example) retain their bed as their set respawn position.
     */
    public boolean copyOriginalSpawnPosition() {
        return copyOriginalSpawnPosition;
    }

    /**
     * Changes if the original player's respawn position will be copied to the fresh player via {@link ServerPlayerEntity#setSpawnPointFrom(ServerPlayerEntity)}.
     * <p>
     * If you wish to modify the set respawn position of the fresh player (for future respawns, not the current respawn), you can
     * change the respawn position of the {@linkplain #getEntity() current player} and set this value to true.
     * 
     * @see #copyOriginalSpawnPosition()
     */
    public void setCopyOriginalSpawnPosition(boolean copyOriginalSpawnPosition) {
        this.copyOriginalSpawnPosition = copyOriginalSpawnPosition;
    }

    /**
     * @return Whether the respawn was triggered by the player jumping into the End return portal.
     * @see ServerPlayerEntity#notInAnyWorld
     */
    public boolean isFromEndFight() {
        return fromEndFight;
    }
}
