/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item.TooltipContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

public class ItemTooltipEvent extends PlayerEvent {
    private final TooltipType flags;
    private final ItemStack itemStack;
    private final List<Text> toolTip;
    private final TooltipContext context;

    /**
     * This event is fired in {@link ItemStack#getTooltip(TooltipContext, PlayerEntity, TooltipType)}, which in turn is called from its respective GUIContainer.
     * Tooltips are also gathered with a null player during startup by {@link MinecraftClient#createSearchTrees()}.
     */
    public ItemTooltipEvent(ItemStack itemStack, @Nullable PlayerEntity player, List<Text> list, TooltipType flags, TooltipContext context) {
        super(player);
        this.itemStack = itemStack;
        this.toolTip = list;
        this.flags = flags;
        this.context = context;
    }

    /**
     * Use to determine if the advanced information on item tooltips is being shown, toggled by F3+H.
     */
    public TooltipType getFlags() {
        return flags;
    }

    /**
     * The {@link ItemStack} with the tooltip.
     */
    public ItemStack getItemStack() {
        return itemStack;
    }

    /**
     * The {@link ItemStack} tooltip.
     */
    public List<Text> getToolTip() {
        return toolTip;
    }

    /**
     * This event is fired with a null player during startup when populating search trees for tooltips.
     */
    @Override
    @Nullable
    public PlayerEntity getEntity() {
        return super.getEntity();
    }

    /**
     * The {@link TooltipContext tooltip context}.
     */
    public TooltipContext getContext() {
        return context;
    }
}
