/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.registration;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

/**
 * Represents a complete negotiated network payload type, which is stored on the client and server.
 *
 * @param id            The payload id.
 * @param chosenVersion The chosen version, if any.
 */
@ApiStatus.Internal
public record NetworkChannel(Identifier id, String chosenVersion) {
    public static final PacketCodec<PacketByteBuf, NetworkChannel> STREAM_CODEC = PacketCodec.tuple(
            Identifier.PACKET_CODEC, NetworkChannel::id,
            PacketCodecs.STRING, NetworkChannel::chosenVersion,
            NetworkChannel::new);
}
