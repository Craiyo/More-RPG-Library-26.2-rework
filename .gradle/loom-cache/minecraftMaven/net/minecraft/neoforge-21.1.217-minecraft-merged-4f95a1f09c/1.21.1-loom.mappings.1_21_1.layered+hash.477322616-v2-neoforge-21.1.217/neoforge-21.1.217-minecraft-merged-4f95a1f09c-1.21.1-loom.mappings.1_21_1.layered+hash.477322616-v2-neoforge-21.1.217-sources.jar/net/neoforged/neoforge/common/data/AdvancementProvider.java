/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.advancement.AdvancementTabGenerator;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.extensions.IAdvancementBuilderExtension;

/**
 * An extension of the vanilla {@code AdvancementProvider} to provide a feature-complete
 * experience to generate modded advancements.
 */
public class AdvancementProvider extends net.minecraft.data.server.advancement.AdvancementProvider {
    /**
     * Constructs an advancement provider using the generators to write the
     * advancements to a file.
     *
     * @param output             the target directory of the data generator
     * @param registries         a future of a lookup for registries and their objects
     * @param existingFileHelper a helper used to find whether a file exists
     * @param subProviders       the generators used to create the advancements
     */
    public AdvancementProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, ExistingFileHelper existingFileHelper, List<AdvancementGenerator> subProviders) {
        super(output, registries, subProviders.stream().map(generator -> generator.toSubProvider(existingFileHelper)).toList());
    }

    /**
     * An interface used to generated modded advancements. This is parallel to
     * vanilla's {@link AdvancementTabGenerator} with access to the {@link ExistingFileHelper}.
     *
     * @see AdvancementTabGenerator
     */
    public interface AdvancementGenerator {
        /**
         * A method used to generate advancements for a mod. Advancements should be
         * built via {@link IAdvancementBuilderExtension#save(Consumer, Identifier, ExistingFileHelper)}.
         *
         * @param registries         a lookup for registries and their objects
         * @param saver              a consumer used to write advancements to a file
         * @param existingFileHelper a helper used to find whether a file exists
         */
        void generate(RegistryWrapper.WrapperLookup registries, Consumer<AdvancementEntry> saver, ExistingFileHelper existingFileHelper);

        /**
         * Creates an {@link AdvancementTabGenerator} from this generator.
         *
         * @param existingFileHelper a helper used to find whether a file exists
         * @return a sub provider wrapping this generator
         */
        default AdvancementTabGenerator toSubProvider(ExistingFileHelper existingFileHelper) {
            return (registries, saver) -> this.generate(registries, saver, existingFileHelper);
        }
    }
}
