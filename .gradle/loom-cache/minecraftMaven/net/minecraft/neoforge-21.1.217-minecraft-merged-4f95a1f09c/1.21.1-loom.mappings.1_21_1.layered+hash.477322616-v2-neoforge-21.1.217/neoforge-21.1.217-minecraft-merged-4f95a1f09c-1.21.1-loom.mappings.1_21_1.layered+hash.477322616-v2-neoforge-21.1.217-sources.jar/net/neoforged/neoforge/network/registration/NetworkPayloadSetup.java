/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.registration;

import com.google.common.collect.ImmutableMap;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.network.NetworkPhase;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.network.negotiation.NegotiationResult;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Represents a complete negotiated network, which is stored on the client and server.
 *
 * @param configuration The configuration channels.
 * @param play          The play channels.
 */
@ApiStatus.Internal
public record NetworkPayloadSetup(Map<NetworkPhase, Map<Identifier, NetworkChannel>> channels) {
    public static PacketCodec<PacketByteBuf, NetworkPayloadSetup> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.map(IdentityHashMap::new,
                    PacketCodecs.indexed(b -> NetworkPhase.values()[b], NetworkPhase::ordinal),
                    PacketCodecs.map(HashMap::new, Identifier.PACKET_CODEC, NetworkChannel.STREAM_CODEC)),
            NetworkPayloadSetup::channels, NetworkPayloadSetup::new);

    public Map<Identifier, NetworkChannel> getChannels(NetworkPhase protocol) {
        return this.channels().getOrDefault(protocol, Collections.emptyMap());
    }

    @Nullable
    public NetworkChannel getChannel(NetworkPhase protocol, Identifier id) {
        return getChannels(protocol).get(id);
    }

    /**
     * {@return An empty modded network.}
     */
    public static NetworkPayloadSetup empty() {
        return new NetworkPayloadSetup(Collections.emptyMap());
    }

    /**
     * {@return A modded network with the given configuration and play channels.}
     */
    public static NetworkPayloadSetup from(Map<NetworkPhase, NegotiationResult> results) {
        ImmutableMap.Builder<NetworkPhase, Map<Identifier, NetworkChannel>> channels = ImmutableMap.builder();

        for (Map.Entry<NetworkPhase, NegotiationResult> result : results.entrySet()) {
            ImmutableMap.Builder<Identifier, NetworkChannel> protocolChannels = ImmutableMap.builder();
            result.getValue().components().forEach(component -> {
                protocolChannels.put(component.id(), new NetworkChannel(component.id(), component.version()));
            });
            channels.put(result.getKey(), protocolChannels.build());
        }

        return new NetworkPayloadSetup(channels.build());
    }
}
