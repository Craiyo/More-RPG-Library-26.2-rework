/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.s2c.common.CustomPayloadS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.PlayerManager;
import net.minecraft.world.World;

/**
 * Extension class for {@link PlayerManager}
 * <p>
 * This interface with its default methods allows for easy sending of payloads to all, or specific, players on the server.
 * </p>
 */
public interface IPlayerListExtension {
    /**
     * {@return the PlayerList instance that this extension is attached to}
     */
    default PlayerManager self() {
        return (PlayerManager) this;
    }

    /**
     * Sends a payload to all players on the server
     *
     * @param payload the payload to send
     */
    default void broadcastAll(CustomPayload payload) {
        self().sendToAll(new CustomPayloadS2CPacket(payload));
    }

    /**
     * Sends a payload to all players within the specific level.
     *
     * @param payload     the payload to send
     * @param targetLevel the level to send the payload to.
     */
    default void broadcastAll(CustomPayload payload, RegistryKey<World> targetLevel) {
        self().sendToDimension(new CustomPayloadS2CPacket(payload), targetLevel);
    }

    /**
     * Sends a payload to all players within the specific level, within a given range around the target point
     *
     * @param x       the x coordinate of the target point
     * @param y       the y coordinate of the target point
     * @param z       the z coordinate of the target point
     * @param range   the range around the target point to send the payload to
     * @param level   the level to send the payload to
     * @param payload the payload to send
     */
    default void broadcast(
            double x, double y, double z, double range, RegistryKey<World> level, CustomPayload payload) {
        self().sendToAround(null, x, y, z, range, level, new CustomPayloadS2CPacket(payload));
    }

    /**
     * Sends a payload to all players within the specific level, within a given range around the target point, excluding the specified player.
     *
     * @param excludedPlayer the player to exclude from the broadcast, when null all players will receive the payload.
     * @param x              the x coordinate of the target point
     * @param y              the y coordinate of the target point
     * @param z              the z coordinate of the target point
     * @param range          the range around the target point to send the payload to
     * @param level          the level to send the payload to
     * @param payload        the payload to send
     */
    default void broadcast(
            PlayerEntity excludedPlayer, double x, double y, double z, double range, RegistryKey<World> level, CustomPayload payload) {
        self().sendToAround(excludedPlayer, x, y, z, range, level, new CustomPayloadS2CPacket(payload));
    }
}
