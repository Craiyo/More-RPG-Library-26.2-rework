/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.model;

import ;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.render.VertexFormatElement;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.model.BakedQuad;

/**
 * Transformer for {@link BakedQuad baked quads}.
 *
 * @see QuadTransformers
 */
public interface IQuadTransformer {
    int STRIDE = VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL.getVertexSizeByte() / 4;
    int POSITION = findOffset(VertexFormatElement.POSITION);
    int COLOR = findOffset(VertexFormatElement.COLOR);
    int UV0 = findOffset(VertexFormatElement.UV_0);
    int UV1 = findOffset(VertexFormatElement.UV_1);
    int UV2 = findOffset(VertexFormatElement.UV_2);
    int NORMAL = findOffset(VertexFormatElement.NORMAL);

    void processInPlace(BakedQuad quad);

    default void processInPlace(List<BakedQuad> quads) {
        for (BakedQuad quad : quads)
            processInPlace(quad);
    }

    default BakedQuad process(BakedQuad quad) {
        var copy = copy(quad);
        processInPlace(copy);
        return copy;
    }

    default List<BakedQuad> process(List<BakedQuad> inputs) {
        return inputs.stream().map(IQuadTransformer::copy).peek(this::processInPlace).toList();
    }

    default IQuadTransformer andThen(IQuadTransformer other) {
        return quad -> {
            processInPlace(quad);
            other.processInPlace(quad);
        };
    }

    private static BakedQuad copy(BakedQuad quad) {
        var vertices = quad.getVertexData();
        return new BakedQuad(Arrays.copyOf(vertices, vertices.length), quad.getColorIndex(), quad.getFace(), quad.getSprite(), quad.hasShade(), quad.hasAmbientOcclusion());
    }

    private static int findOffset(VertexFormatElement element) {
        if (VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL.has(element)) {
            // Divide by 4 because we want the int offset
            return VertexFormats.POSITION_COLOR_TEXTURE_LIGHT_NORMAL.getOffset(element) / 4;
        }
        return -1;
    }
}
