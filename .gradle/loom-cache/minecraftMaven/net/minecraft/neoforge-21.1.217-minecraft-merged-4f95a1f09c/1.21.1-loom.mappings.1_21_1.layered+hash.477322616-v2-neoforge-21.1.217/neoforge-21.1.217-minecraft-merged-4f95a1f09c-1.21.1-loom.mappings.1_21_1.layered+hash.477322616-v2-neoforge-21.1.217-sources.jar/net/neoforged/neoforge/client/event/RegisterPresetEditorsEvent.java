/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import java.util.Map;
import net.minecraft.client.gui.screen.world.LevelScreenProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.gen.WorldPreset;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.fml.ModLoadingContext;
import net.neoforged.fml.event.IModBusEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.ApiStatus;

/**
 * <p>Event for registering {@link LevelScreenProvider} screen factories for world presets.</p>
 *
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.
 *
 * <p>This event is fired on the mod-specific event bus, only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 */
public class RegisterPresetEditorsEvent extends Event implements IModBusEvent {
    private static final Logger LOGGER = LogManager.getLogger();

    private final Map<RegistryKey<WorldPreset>, LevelScreenProvider> editors;

    @ApiStatus.Internal
    public RegisterPresetEditorsEvent(Map<RegistryKey<WorldPreset>, LevelScreenProvider> editors) {
        this.editors = editors;
    }

    /**
     * Registers a PresetEditor for a given world preset key.
     */
    public void register(RegistryKey<WorldPreset> key, LevelScreenProvider editor) {
        LevelScreenProvider old = this.editors.put(key, editor);
        if (old != null) {
            LOGGER.debug("PresetEditor {} overridden by mod {}", key.getValue(), ModLoadingContext.get().getActiveNamespace());
        }
    }
}
