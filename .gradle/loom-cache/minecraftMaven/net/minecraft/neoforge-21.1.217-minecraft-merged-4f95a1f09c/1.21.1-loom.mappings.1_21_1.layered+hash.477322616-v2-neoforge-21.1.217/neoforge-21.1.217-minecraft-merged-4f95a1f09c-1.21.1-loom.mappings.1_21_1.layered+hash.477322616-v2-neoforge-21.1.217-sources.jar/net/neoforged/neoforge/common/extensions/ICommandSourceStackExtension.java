/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;

/**
 * Additional methods for {@link ServerCommandSource} so that commands and arguments can access various things without directly referencing using server specific classes
 */
public interface ICommandSourceStackExtension {
    private ServerCommandSource self() {
        return (ServerCommandSource) this;
    }

    /**
     * @return the scoreboard
     */
    default Scoreboard getScoreboard() {
        return self().getServer().getScoreboard();
    }

    /**
     * @return the advancement from the id
     */
    default AdvancementEntry getAdvancement(Identifier id) {
        return self().getServer().getAdvancementLoader().get(id);
    }

    /**
     * @return the recipe manager
     */
    default RecipeManager getRecipeManager() {
        return self().getServer().getRecipeManager();
    }

    /**
     * @return the level but without being specifically the server side level
     */
    default World getUnsidedLevel() {
        return self().getWorld();
    }
}
