/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import com.mojang.datafixers.util.Pair;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import net.minecraft.client.gui.screen.DownloadingTerrainScreen;
import net.minecraft.registry.RegistryKey;
import net.minecraft.world.World;
import net.neoforged.fml.ModLoader;
import net.neoforged.neoforge.client.event.RegisterDimensionTransitionScreenEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

public class DimensionTransitionScreenManager {
    private static final Map<Pair<RegistryKey<World>, RegistryKey<World>>, ReceivingLevelScreenFactory> conditionalDimensionEffects = new HashMap<>();
    private static final Map<RegistryKey<World>, ReceivingLevelScreenFactory> toDimensionTransitions = new HashMap<>();
    private static final Map<RegistryKey<World>, ReceivingLevelScreenFactory> fromDimensionTransitions = new HashMap<>();

    @ApiStatus.Internal
    static void init() {
        ModLoader.postEventWrapContainerInModOrder(new RegisterDimensionTransitionScreenEvent(conditionalDimensionEffects, toDimensionTransitions, fromDimensionTransitions));
    }

    public static ReceivingLevelScreenFactory getScreenFromLevel(@Nullable World target, @Nullable World source) {
        if (source == null) { //source level is null on login: transition screen should not appear in this case
            return getScreen(null, null);
        } else if (target == null) { //the target level shouldn't ever be null, but anyone could call Minecraft.setLevel and pass null in
            return getScreen(null, source.getRegistryKey());
        }
        return getScreen(target.getRegistryKey(), source.getRegistryKey());
    }

    public static ReceivingLevelScreenFactory getScreen(@Nullable RegistryKey<World> toDimension, @Nullable RegistryKey<World> fromDimension) {
        var conditionalScreen = conditionalDimensionEffects.get(Pair.of(toDimension, fromDimension));
        if (conditionalScreen != null) {
            return conditionalScreen;
        }
        var toDim = toDimensionTransitions.get(toDimension);
        if (toDim != null) {
            return toDim;
        }
        var fromDim = fromDimensionTransitions.get(fromDimension);
        if (fromDim != null) {
            return fromDim;
        }
        return DownloadingTerrainScreen::new;
    }

    public interface ReceivingLevelScreenFactory {
        DownloadingTerrainScreen create(BooleanSupplier supplier, DownloadingTerrainScreen.WorldEntryReason reason);
    }
}
