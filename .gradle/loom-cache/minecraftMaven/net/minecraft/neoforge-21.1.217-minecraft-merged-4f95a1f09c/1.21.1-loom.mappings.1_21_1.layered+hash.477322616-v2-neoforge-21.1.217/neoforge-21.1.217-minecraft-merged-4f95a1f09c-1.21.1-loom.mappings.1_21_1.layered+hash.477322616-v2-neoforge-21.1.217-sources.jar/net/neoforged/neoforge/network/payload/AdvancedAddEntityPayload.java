/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.util.FriendlyByteBufUtil;
import net.neoforged.neoforge.entity.IEntityWithComplexSpawn;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import org.jetbrains.annotations.ApiStatus;

/**
 * Payload that can be sent from the server to the client to add an entity to the world, with custom data.
 *
 * @param entityId      The id of the entity to add.
 * @param customPayload The custom data of the entity to add.
 */
@ApiStatus.Internal
public record AdvancedAddEntityPayload(int entityId, byte[] customPayload) implements CustomPayload {
    public static final Id<AdvancedAddEntityPayload> TYPE = new Id<>(Identifier.of(NeoForgeVersion.MOD_ID, "advanced_add_entity"));
    public static final PacketCodec<PacketByteBuf, AdvancedAddEntityPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT,
            AdvancedAddEntityPayload::entityId,
            NeoForgeStreamCodecs.UNBOUNDED_BYTE_ARRAY,
            AdvancedAddEntityPayload::customPayload,
            AdvancedAddEntityPayload::new);

    public AdvancedAddEntityPayload(Entity e) {
        this(e.getId(), writeCustomData(e));
    }

    private static byte[] writeCustomData(final Entity entity) {
        if (!(entity instanceof IEntityWithComplexSpawn additionalSpawnData)) {
            return new byte[0];
        }

        return FriendlyByteBufUtil.writeCustomData(additionalSpawnData::writeSpawnData, entity.getRegistryManager());
    }

    @Override
    public Id<AdvancedAddEntityPayload> getId() {
        return TYPE;
    }
}
