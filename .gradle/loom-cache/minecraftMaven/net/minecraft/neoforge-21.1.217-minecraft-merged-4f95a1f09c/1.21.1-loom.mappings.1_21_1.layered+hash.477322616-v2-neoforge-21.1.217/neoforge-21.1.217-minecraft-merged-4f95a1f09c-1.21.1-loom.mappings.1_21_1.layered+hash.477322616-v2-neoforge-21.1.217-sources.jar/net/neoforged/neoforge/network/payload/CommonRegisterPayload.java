/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.network.NetworkPhase;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Common Register, used to send play-phase channels during the configuration phase.
 * 
 * @param version  Declared version of all contained channels. Currently unused by NeoForge.
 * @param protocol The {@link NetworkPhase} of the contained channels. One of "play" or "configuration". Currently NeoForge only expects and sends "play" channels via this payload.
 * @param channels A list of all named channels available for the declared phase.
 */
@ApiStatus.Internal
public record CommonRegisterPayload(int version, NetworkPhase protocol, Set<Identifier> channels) implements CustomPayload {

    public static final Identifier ID = Identifier.of("c", "register");
    public static final CustomPayload.Id<CommonRegisterPayload> TYPE = new CustomPayload.Id<>(ID);
    public static final PacketCodec<PacketByteBuf, CommonRegisterPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, CommonRegisterPayload::version,
            PacketCodecs.STRING.xmap(CommonRegisterPayload::protocolById, NetworkPhase::getId), CommonRegisterPayload::protocol,
            PacketCodecs.collection(HashSet::new, Identifier.PACKET_CODEC), CommonRegisterPayload::channels,
            CommonRegisterPayload::new);
    @Override
    public Id<CommonRegisterPayload> getId() {
        return TYPE;
    }

    @Nullable
    private static NetworkPhase protocolById(String id) {
        for (NetworkPhase p : NetworkPhase.values()) {
            if (p.getId().equals(id)) {
                return p;
            }
        }
        return null;
    }
}
