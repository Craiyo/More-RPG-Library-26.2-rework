/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.textures;

import java.util.Map;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.block.FluidRenderer;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import org.jetbrains.annotations.ApiStatus;

/**
 * Helper class for safely accessing fluid textures on a render worker (such as in {@link FluidRenderer})
 * to avoid potential issues when a chunk gets re-batched while resources are being reloaded.
 */
public final class FluidSpriteCache {
    private static Map<Identifier, Sprite> textureLookup = Map.of();
    private static Sprite missingSprite = null;

    /**
     * {@return an array holding the still sprite, the flowing sprite and the overlay sprite (if specified,
     * otherwise null) of the given fluid at the given position}
     */
    public static Sprite[] getFluidSprites(BlockRenderView level, BlockPos pos, FluidState fluid) {
        IClientFluidTypeExtensions props = IClientFluidTypeExtensions.of(fluid);
        Identifier overlay = props.getOverlayTexture(fluid, level, pos);
        Map<Identifier, Sprite> textures = textureLookup;

        return new Sprite[] {
                textures.getOrDefault(props.getStillTexture(fluid, level, pos), missingSprite),
                textures.getOrDefault(props.getFlowingTexture(fluid, level, pos), missingSprite),
                overlay == null ? null : textures.getOrDefault(overlay, missingSprite),
        };
    }

    /**
     * {@return a specified sprite or a missing sprite texture if sprite is not found}
     */
    public static Sprite getSprite(Identifier texture) {
        return textureLookup.getOrDefault(texture, missingSprite);
    }

    @ApiStatus.Internal
    @SuppressWarnings("deprecation")
    public static void reload() {
        SpriteAtlasTexture atlas = MinecraftClient.getInstance().getBakedModelManager().getAtlas(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE);
        textureLookup = atlas.getTextures();
        missingSprite = textureLookup.get(MissingSprite.getMissingSpriteId());
    }

    private FluidSpriteCache() {}
}
