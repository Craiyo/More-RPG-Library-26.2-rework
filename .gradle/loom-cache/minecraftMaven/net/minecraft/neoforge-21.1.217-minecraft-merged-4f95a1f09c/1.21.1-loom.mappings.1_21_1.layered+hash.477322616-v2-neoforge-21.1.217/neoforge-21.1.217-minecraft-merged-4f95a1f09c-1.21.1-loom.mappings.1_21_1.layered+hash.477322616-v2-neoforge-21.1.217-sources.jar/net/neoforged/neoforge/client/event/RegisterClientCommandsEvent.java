/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.argument.IdentifierArgumentType;
import net.minecraft.command.argument.ScoreboardObjectiveArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.neoforged.bus.api.Event;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import org.jetbrains.annotations.ApiStatus;

/**
 * Fired to allow mods to register client commands.
 *
 * <p>Some command arguments behave differently for the client commands dispatcher:</p>
 * <ul>
 * <li>{@link IdentifierArgumentType#getAdvancementArgument(com.mojang.brigadier.context.CommandContext, String)} only returns
 * advancements that are shown on the advancements screen.
 * <li>{@link ScoreboardObjectiveArgumentType#getObjective(com.mojang.brigadier.context.CommandContext, String)} only returns
 * objectives that are displayed to the player.
 * </ul>
 *
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
 *
 * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 *
 * @see RegisterCommandsEvent
 */
public class RegisterClientCommandsEvent extends Event {
    private final CommandDispatcher<ServerCommandSource> dispatcher;
    private final CommandRegistryAccess context;

    @ApiStatus.Internal
    public RegisterClientCommandsEvent(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess context) {
        this.dispatcher = dispatcher;
        this.context = context;
    }

    /**
     * {@return the command dispatcher for registering commands to be executed on the client}
     */
    public CommandDispatcher<ServerCommandSource> getDispatcher() {
        return dispatcher;
    }

    /**
     * {@return the context to build the commands for}
     */
    public CommandRegistryAccess getBuildContext() {
        return context;
    }
}
