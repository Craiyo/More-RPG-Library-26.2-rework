/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event;

import java.util.Objects;
import net.minecraft.loot.LootTable;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Fired when a {@link LootTable} is loaded from JSON.
 * Can be used to modify the loot table, cancel loading it, or outright replace it.
 * This event is currently fired for all loot tables coming from vanilla, mods, and user datapacks.
 * This event is fired whenever server resources are loaded or reloaded.
 *
 * <p>This event is {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.
 * If the event is cancelled, the loot table will be made empty.</p>
 *
 * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#SERVER logical server}.</p>
 */
public class LootTableLoadEvent extends Event implements ICancellableEvent {
    private final RegistryWrapper.WrapperLookup registries;
    private final Identifier name;
    private LootTable table;

    @Nullable
    private RegistryKey<LootTable> key;

    /**
     * @deprecated Neo: use the constructor {@link #LootTableLoadEvent(RegistryWrapper.WrapperLookup, Identifier, LootTable) with a lookup provider}
     */
    @Deprecated
    public LootTableLoadEvent(Identifier name, LootTable table) {
        this(DynamicRegistryManager.EMPTY, name, table);
    }

    @ApiStatus.Internal
    public LootTableLoadEvent(RegistryWrapper.WrapperLookup registries, Identifier name, LootTable table) {
        this.registries = registries;
        this.name = name;
        this.table = table;
    }

    /**
     * {@return a lookup provider that can be used to access registries}
     */
    public RegistryWrapper.WrapperLookup getRegistries() {
        return this.registries;
    }

    public Identifier getName() {
        return this.name;
    }

    public RegistryKey<LootTable> getKey() {
        if (this.key == null) {
            this.key = RegistryKey.of(RegistryKeys.LOOT_TABLE, name);
        }
        return this.key;
    }

    public LootTable getTable() {
        return this.table;
    }

    public void setTable(LootTable table) {
        Objects.requireNonNull(table);
        this.table = table;
    }
}
