/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record AuxiliaryLightDataPayload(ChunkPos pos, Map<BlockPos, Byte> entries) implements CustomPayload {
    public static final Id<AuxiliaryLightDataPayload> TYPE = new Id<>(Identifier.of(NeoForgeVersion.MOD_ID, "auxiliary_light_data"));
    public static final PacketCodec<RegistryByteBuf, AuxiliaryLightDataPayload> STREAM_CODEC = PacketCodec.tuple(
            NeoForgeStreamCodecs.CHUNK_POS,
            AuxiliaryLightDataPayload::pos,
            PacketCodecs.map(HashMap::new, BlockPos.PACKET_CODEC, PacketCodecs.BYTE),
            AuxiliaryLightDataPayload::entries,
            AuxiliaryLightDataPayload::new);

    @Override
    public Id<AuxiliaryLightDataPayload> getId() {
        return TYPE;
    }
}
