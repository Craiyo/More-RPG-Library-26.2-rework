/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.recipebook.RecipeBookGroup;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.book.RecipeBookCategory;
import net.neoforged.fml.ModLoader;
import net.neoforged.neoforge.client.event.RegisterRecipeBookCategoriesEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Manager for {@link RecipeBookCategory recipe book types} and {@link RecipeBookGroup categories}.
 * <p>
 * Provides a recipe category lookup.
 */
public final class RecipeBookManager {
    // Not using ConcurrentHashMap here because it's slower for lookups, so we only use it during init
    private static final Map<RecipeBookGroup, List<RecipeBookGroup>> AGGREGATE_CATEGORIES = new HashMap<>();
    private static final Map<RecipeBookCategory, List<RecipeBookGroup>> TYPE_CATEGORIES = new HashMap<>();
    private static final Map<RecipeType<?>, Function<RecipeEntry<?>, RecipeBookGroup>> RECIPE_CATEGORY_LOOKUPS = new HashMap<>();
    private static final Map<RecipeBookGroup, List<RecipeBookGroup>> AGGREGATE_CATEGORIES_VIEW = Collections.unmodifiableMap(AGGREGATE_CATEGORIES);

    /**
     * Finds the category the specified recipe should display in, or null if none.
     */
    @Nullable
    public static <T extends Recipe<?>> RecipeBookGroup findCategories(RecipeType<T> type, RecipeEntry<T> recipe) {
        var lookup = RECIPE_CATEGORY_LOOKUPS.get(type);
        return lookup != null ? lookup.apply(recipe) : null;
    }

    @ApiStatus.Internal
    public static Map<RecipeBookGroup, List<RecipeBookGroup>> getAggregateCategories() {
        return AGGREGATE_CATEGORIES_VIEW;
    }

    @ApiStatus.Internal
    public static List<RecipeBookGroup> getCustomCategoriesOrEmpty(RecipeBookCategory recipeBookType) {
        return TYPE_CATEGORIES.getOrDefault(recipeBookType, List.of());
    }

    @ApiStatus.Internal
    public static void init() {
        // The ImmutableMap is the patched out value of AGGREGATE_CATEGORIES
        var aggregateCategories = new HashMap<>(ImmutableMap.of(
                RecipeBookGroup.CRAFTING_SEARCH, ImmutableList.of(RecipeBookGroup.CRAFTING_EQUIPMENT, RecipeBookGroup.CRAFTING_BUILDING_BLOCKS, RecipeBookGroup.CRAFTING_MISC, RecipeBookGroup.CRAFTING_REDSTONE),
                RecipeBookGroup.FURNACE_SEARCH, ImmutableList.of(RecipeBookGroup.FURNACE_FOOD, RecipeBookGroup.FURNACE_BLOCKS, RecipeBookGroup.FURNACE_MISC),
                RecipeBookGroup.BLAST_FURNACE_SEARCH, ImmutableList.of(RecipeBookGroup.BLAST_FURNACE_BLOCKS, RecipeBookGroup.BLAST_FURNACE_MISC),
                RecipeBookGroup.SMOKER_SEARCH, ImmutableList.of(RecipeBookGroup.SMOKER_FOOD)));

        var typeCategories = new HashMap<RecipeBookCategory, ImmutableList<RecipeBookGroup>>();
        var recipeCategoryLookups = new HashMap<RecipeType<?>, Function<RecipeEntry<?>, RecipeBookGroup>>();
        var event = new RegisterRecipeBookCategoriesEvent(aggregateCategories, typeCategories, recipeCategoryLookups);
        ModLoader.postEventWrapContainerInModOrder(event);
        AGGREGATE_CATEGORIES.putAll(aggregateCategories);
        TYPE_CATEGORIES.putAll(typeCategories);
        RECIPE_CATEGORY_LOOKUPS.putAll(recipeCategoryLookups);
    }
}
