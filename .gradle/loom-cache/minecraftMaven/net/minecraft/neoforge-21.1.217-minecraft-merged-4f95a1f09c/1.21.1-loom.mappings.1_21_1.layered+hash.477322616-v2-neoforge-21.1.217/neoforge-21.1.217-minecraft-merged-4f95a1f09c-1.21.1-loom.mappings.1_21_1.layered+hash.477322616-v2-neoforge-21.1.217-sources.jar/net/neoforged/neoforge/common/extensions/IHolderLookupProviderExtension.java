/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import java.util.Optional;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;

public interface IHolderLookupProviderExtension {
    private RegistryWrapper.WrapperLookup self() {
        return (RegistryWrapper.WrapperLookup) this;
    }

    /**
     * Shortcut method to get a holder from a ResourceKey.
     * 
     * @throws IllegalStateException if the registry or key is not found.
     */
    default <T> RegistryEntry<T> holderOrThrow(RegistryKey<T> key) {
        return this.self().getWrapperOrThrow(key.getRegistryRef()).getOrThrow(key);
    }

    /**
     * Shortcut method to get an optional holder from a ResourceKey.
     */
    default <T> Optional<RegistryEntry.Reference<T>> holder(RegistryKey<T> key) {
        Optional<RegistryWrapper.Impl<T>> registry = this.self().getOptionalWrapper(key.getRegistryRef());
        return registry.flatMap(tRegistryLookup -> tRegistryLookup.getOptional(key));
    }
}
