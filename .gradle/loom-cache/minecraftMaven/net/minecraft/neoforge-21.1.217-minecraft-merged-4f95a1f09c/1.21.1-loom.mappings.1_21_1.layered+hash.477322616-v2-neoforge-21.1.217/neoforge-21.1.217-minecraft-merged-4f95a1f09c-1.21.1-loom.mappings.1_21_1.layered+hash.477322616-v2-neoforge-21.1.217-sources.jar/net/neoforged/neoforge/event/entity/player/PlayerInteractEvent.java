/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.event.entity.player;

import com.google.common.base.Preconditions;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.util.TriState;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * PlayerInteractEvent is fired when a player interacts in some way.
 * All subclasses are fired on {@link NeoForge#EVENT_BUS}.
 * See the individual documentation on each subevent for more details.
 **/
public abstract class PlayerInteractEvent extends PlayerEvent {
    private final Hand hand;
    private final BlockPos pos;
    @Nullable
    private final Direction face;

    protected PlayerInteractEvent(PlayerEntity player, Hand hand, BlockPos pos, @Nullable Direction face) {
        super(Preconditions.checkNotNull(player, "Null player in PlayerInteractEvent!"));
        this.hand = Preconditions.checkNotNull(hand, "Null hand in PlayerInteractEvent!");
        this.pos = Preconditions.checkNotNull(pos, "Null position in PlayerInteractEvent!");
        this.face = face;
    }

    /**
     * This event is fired on both sides whenever a player right clicks an entity.
     *
     * "Interact at" is an interact where the local vector (which part of the entity you clicked) is known.
     * The state of this event affects whether {@link Entity#interactAt(PlayerEntity, Vec3d, Hand)} is called.
     *
     * Let result be the return value of {@link Entity#interactAt(PlayerEntity, Vec3d, Hand)}, or {@link #cancellationResult} if the event is cancelled.
     * If we are on the client and result is not {@link ActionResult#SUCCESS}, the client will then try {@link EntityInteract}.
     */
    public static class EntityInteractSpecific extends PlayerInteractEvent implements ICancellableEvent {
        private ActionResult cancellationResult = ActionResult.PASS;

        private final Vec3d localPos;
        private final Entity target;

        public EntityInteractSpecific(PlayerEntity player, Hand hand, Entity target, Vec3d localPos) {
            super(player, hand, target.getBlockPos(), null);
            this.localPos = localPos;
            this.target = target;
        }

        /**
         * Returns the local interaction position. This is a 3D vector, where (0, 0, 0) is centered exactly at the
         * center of the entity's bounding box at their feet. This means the X and Z values will be in the range
         * [-width / 2, width / 2] while Y values will be in the range [0, height]
         * 
         * @return The local position
         */
        public Vec3d getLocalPos() {
            return localPos;
        }

        public Entity getTarget() {
            return target;
        }

        /**
         * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         *         method of the event. By default, this is {@link ActionResult#PASS}, meaning cancelled events will cause
         *         the client to keep trying more interactions until something works.
         */
        public ActionResult getCancellationResult() {
            return cancellationResult;
        }

        /**
         * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         * method of the event.
         */
        public void setCancellationResult(ActionResult result) {
            this.cancellationResult = result;
        }
    }

    /**
     * This event is fired on both sides when the player right clicks an entity.
     * It is responsible for all general entity interactions.
     *
     * This event is fired only if the result of the above {@link EntityInteractSpecific} is not {@link ActionResult#SUCCESS}.
     * This event's state affects whether {@link Entity#interact(PlayerEntity, Hand)} and
     * {@link Item#useOnEntity(ItemStack, PlayerEntity, LivingEntity, Hand)} are called.
     *
     * Let result be {@link ActionResult#SUCCESS} if {@link Entity#interact(PlayerEntity, Hand)} or
     * {@link Item#useOnEntity(ItemStack, PlayerEntity, LivingEntity, Hand)} return true,
     * or {@link #cancellationResult} if the event is cancelled.
     * If we are on the client and result is not {@link ActionResult#SUCCESS}, the client will then try {@link RightClickItem}.
     */
    public static class EntityInteract extends PlayerInteractEvent implements ICancellableEvent {
        private ActionResult cancellationResult = ActionResult.PASS;

        private final Entity target;

        public EntityInteract(PlayerEntity player, Hand hand, Entity target) {
            super(player, hand, target.getBlockPos(), null);
            this.target = target;
        }

        public Entity getTarget() {
            return target;
        }

        /**
         * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         *         method of the event. By default, this is {@link ActionResult#PASS}, meaning cancelled events will cause
         *         the client to keep trying more interactions until something works.
         */
        public ActionResult getCancellationResult() {
            return cancellationResult;
        }

        /**
         * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         * method of the event.
         */
        public void setCancellationResult(ActionResult result) {
            this.cancellationResult = result;
        }
    }

    /**
     * This event is fired on both sides whenever the player right clicks while targeting a block. <br>
     * This event controls which of {@link Item#onItemUseFirst}, {@link Block#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)},
     * and {@link Item#useOnBlock(ItemUsageContext)} will be called. <br>
     * Canceling the event will cause none of the above three to be called. <br>
     * <br>
     * Let result be the first non-pass return value of the above three methods, or pass, if they all pass. <br>
     * Or {@link #cancellationResult} if the event is cancelled. <br>
     * If result equals {@link ActionResult#PASS}, we proceed to {@link RightClickItem}. <br>
     * <br>
     * There are various results to this event, see the getters below. <br>
     * Note that handling things differently on the client vs server may cause desynchronizations!
     */
    public static class RightClickBlock extends PlayerInteractEvent implements ICancellableEvent {
        private ActionResult cancellationResult = ActionResult.PASS;

        private TriState useBlock = TriState.DEFAULT;
        private TriState useItem = TriState.DEFAULT;
        private BlockHitResult hitVec;

        public RightClickBlock(PlayerEntity player, Hand hand, BlockPos pos, BlockHitResult hitVec) {
            super(player, hand, pos, hitVec.getSide());
            this.hitVec = hitVec;
        }

        /**
         * @return If {@link Block#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} should be called
         */
        public TriState getUseBlock() {
            return useBlock;
        }

        /**
         * @return If {@link Item#onItemUseFirst} and {@link Item#useOnBlock(ItemUsageContext)} should be called
         */
        public TriState getUseItem() {
            return useItem;
        }

        /**
         * @return The ray trace result targeting the block.
         */
        public BlockHitResult getHitVec() {
            return hitVec;
        }

        /**
         * FALSE: {@link Block#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} will never be called. <br>
         * DEFAULT: {@link Block#use(BlockState, Level, BlockPos, Player, InteractionHand, BlockHitResult)} will be called if {@link Item#onItemUseFirst} passes. <br>
         * Note that default activation can be blocked if the user is sneaking and holding an item that does not return true to {@link Item#doesSneakBypassUse}. <br>
         * TRUE: {@link Block#replace(BlockState, BlockState, WorldAccess, BlockPos, int, int)} will always be called, unless {@link Item#onItemUseFirst} does not pass. <br>
         */
        public void setUseBlock(TriState triggerBlock) {
            this.useBlock = triggerBlock;
        }

        /**
         * FALSE: Neither {@link Item#useOnBlock(ItemUsageContext)} or {@link Item#onItemUseFirst} will be called. <br>
         * DEFAULT: {@link Item#onItemUseFirst} will always be called, and {@link Item#useOnBlock(ItemUsageContext)} will be called if the block passes. <br>
         * TRUE: {@link Item#onItemUseFirst} will always be called, and {@link Item#useOnBlock(ItemUsageContext)} will be called if the block passes, regardless of cooldowns or emptiness. <br>
         */
        public void setUseItem(TriState triggerItem) {
            this.useItem = triggerItem;
        }

        @Override
        public void setCanceled(boolean canceled) {
            ICancellableEvent.super.setCanceled(canceled);
            if (canceled) {
                useBlock = TriState.FALSE;
                useItem = TriState.FALSE;
            }
        }

        /**
         * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         *         method of the event. By default, this is {@link ActionResult#PASS}, meaning cancelled events will cause
         *         the client to keep trying more interactions until something works.
         */
        public ActionResult getCancellationResult() {
            return cancellationResult;
        }

        /**
         * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         * method of the event.
         */
        public void setCancellationResult(ActionResult result) {
            this.cancellationResult = result;
        }
    }

    /**
     * This event is fired on both sides before the player triggers {@link Item#use(World, PlayerEntity, Hand)}.
     * Note that this is NOT fired if the player is targeting a block {@link RightClickBlock} or entity {@link EntityInteract} {@link EntityInteractSpecific}.
     *
     * Let result be the return value of {@link Item#use(World, PlayerEntity, Hand)}, or {@link #cancellationResult} if the event is cancelled.
     * If we are on the client and result is not {@link ActionResult#SUCCESS}, the client will then continue to other hands.
     */
    public static class RightClickItem extends PlayerInteractEvent implements ICancellableEvent {
        private ActionResult cancellationResult = ActionResult.PASS;

        public RightClickItem(PlayerEntity player, Hand hand) {
            super(player, hand, player.getBlockPos(), null);
        }

        /**
         * @return The InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         *         method of the event. By default, this is {@link ActionResult#PASS}, meaning cancelled events will cause
         *         the client to keep trying more interactions until something works.
         */
        public ActionResult getCancellationResult() {
            return cancellationResult;
        }

        /**
         * Set the InteractionResult that will be returned to vanilla if the event is cancelled, instead of calling the relevant
         * method of the event.
         */
        public void setCancellationResult(ActionResult result) {
            this.cancellationResult = result;
        }
    }

    /**
     * This event is fired on the client side when the player right clicks empty space with an empty hand.
     * The server is not aware of when the client right clicks empty space with an empty hand, you will need to tell the server yourself.
     * This event cannot be canceled.
     */
    public static class RightClickEmpty extends PlayerInteractEvent {
        public RightClickEmpty(PlayerEntity player, Hand hand) {
            super(player, hand, player.getBlockPos(), null);
        }
    }

    /**
     * This event is fired when a player left clicks while targeting a block.
     * This event controls which of {@link Block#onBlockBreakStart(BlockState, World, BlockPos, PlayerEntity)} and/or the item harvesting methods will be called
     * Canceling the event will cause none of the above noted methods to be called.
     * There are various results to this event, see the getters below.
     *
     * This event is fired at various points during left clicking on blocks, at both the start and end on the server, and at the start and while held down on the client.
     * Use {@link #getAction()} to check which type of action triggered this event.
     *
     * Note that if the event is canceled and the player holds down left mouse, the event will continue to fire.
     * This is due to how vanilla calls the left click handler methods.
     *
     * Also note that creative mode directly breaks the block without running any other logic.
     * Therefore, in creative mode, {@link #setUseBlock} and {@link #setUseItem} have no effect.
     */
    public static class LeftClickBlock extends PlayerInteractEvent implements ICancellableEvent {
        private TriState useBlock = TriState.DEFAULT;
        private TriState useItem = TriState.DEFAULT;
        private final Action action;

        @ApiStatus.Internal
        public LeftClickBlock(PlayerEntity player, BlockPos pos, Direction face, Action action) {
            super(player, Hand.MAIN_HAND, pos, face);
            this.action = action;
        }

        /**
         * @return If {@link Block#onBlockBreakStart(BlockState, World, BlockPos, PlayerEntity)} should be called. Changing this has no effect in creative mode
         */
        public TriState getUseBlock() {
            return useBlock;
        }

        /**
         * @return If the block should be attempted to be mined with the current item. Changing this has no effect in creative mode
         */
        public TriState getUseItem() {
            return useItem;
        }

        /**
         * @return The action type for this interaction. Will never be null.
         */
        public Action getAction() {
            return this.action;
        }

        public void setUseBlock(TriState triggerBlock) {
            this.useBlock = triggerBlock;
        }

        public void setUseItem(TriState triggerItem) {
            this.useItem = triggerItem;
        }

        @Override
        public void setCanceled(boolean canceled) {
            ICancellableEvent.super.setCanceled(canceled);
            if (canceled) {
                useBlock = TriState.FALSE;
                useItem = TriState.FALSE;
            }
        }

        public enum Action {
            /**
             * When the player first left clicks a block
             */
            START,
            /**
             * When the player stops left clicking a block by completely breaking it
             */
            STOP,
            /**
             * When the player stops left clicking a block by releasing the button, or no longer targeting the same block before it breaks.
             */
            ABORT,
            /**
             * When the player is actively mining a block on the client side
             * Warning: The event is fired every tick on the client
             */
            CLIENT_HOLD;

            public static Action convert(PlayerActionC2SPacket.Action action) {
                return switch (action) {
                    default -> START;
                    case START_DESTROY_BLOCK -> START;
                    case STOP_DESTROY_BLOCK -> STOP;
                    case ABORT_DESTROY_BLOCK -> ABORT;
                };
            }
        }
    }

    /**
     * This event is fired on the client side when the player left clicks empty space with any ItemStack.
     * The server is not aware of when the client left clicks empty space, you will need to tell the server yourself.
     * This event cannot be canceled.
     */
    public static class LeftClickEmpty extends PlayerInteractEvent {
        public LeftClickEmpty(PlayerEntity player) {
            super(player, Hand.MAIN_HAND, player.getBlockPos(), null);
        }
    }

    /**
     * @return The hand involved in this interaction. Will never be null.
     */
    public Hand getHand() {
        return hand;
    }

    /**
     * @return The itemstack involved in this interaction, {@code ItemStack.EMPTY} if the hand was empty.
     */
    public ItemStack getItemStack() {
        return getEntity().getStackInHand(hand);
    }

    /**
     * If the interaction was on an entity, will be a BlockPos centered on the entity.
     * If the interaction was on a block, will be the position of that block.
     * Otherwise, will be a BlockPos centered on the player.
     * Will never be null.
     * 
     * @return The position involved in this interaction.
     */
    public BlockPos getPos() {
        return pos;
    }

    /**
     * @return The face involved in this interaction. For all non-block interactions, this will return null.
     */
    @Nullable
    public Direction getFace() {
        return face;
    }

    /**
     * @return Convenience method to get the level of this interaction.
     */
    public World getLevel() {
        return getEntity().getWorld();
    }

    /**
     * @return The effective, i.e. logical, side of this interaction. This will be {@link LogicalSide#CLIENT} on the client thread, and {@link LogicalSide#SERVER} on the server thread.
     */
    public LogicalSide getSide() {
        return getLevel().isClient ? LogicalSide.CLIENT : LogicalSide.SERVER;
    }
}
