/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.ClientCommonPacketListener;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.listener.ServerCommonPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.thread.ReentrantThreadExecutor;
import net.neoforged.neoforge.network.connection.ConnectionType;
import net.neoforged.neoforge.network.registration.NetworkRegistry;

/**
 * Extension interface and functionality hoist for both {@link ServerCommonPacketListener}
 * and {@link ClientCommonPacketListener}.
 */
public interface ICommonPacketListener extends PacketListener {
    /**
     * Sends a packet to the target of this listener.
     */
    void send(Packet<?> packet);

    /**
     * Sends a payload to the target of this listener.
     */
    void send(CustomPayload payload);

    /**
     * Triggers a disconnection with the given reason.
     *
     * @param reason The reason for the disconnection
     */
    void disconnect(Text reason);

    /**
     * {@return the connection this listener is attached to}
     */
    ClientConnection getConnection();

    /**
     * {@return the main thread event loop}
     */
    ReentrantThreadExecutor<?> getMainThreadEventLoop();

    /**
     * Checks if the connection has negotiated and opened a channel for the payload.
     *
     * @param payloadId The payload id to check
     * @returns true if a payload with this id may be sent over this connection.
     */
    default boolean hasChannel(final Identifier payloadId) {
        return NetworkRegistry.hasChannel(this.getConnection(), this.getPhase(), payloadId);
    }

    /**
     * @see {@link #hasChannel(Identifier)}
     */
    default boolean hasChannel(final CustomPayload.Id<?> type) {
        return hasChannel(type.id());
    }

    /**
     * @see {@link #hasChannel(Identifier)}
     */
    default boolean hasChannel(final CustomPayload payload) {
        return hasChannel(payload.getId());
    }

    /**
     * {@return the connection type of this packet listener}
     */
    ConnectionType getConnectionType();
}
