/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.crafting;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Arrays;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.component.ComponentMap;
import net.minecraft.component.ComponentType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.predicate.ComponentPredicate;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.entry.RegistryEntryListCodec;
import net.neoforged.neoforge.common.NeoForgeMod;

/**
 * Ingredient that matches the given items, performing either a {@link DataComponentIngredient#isStrict() strict} or a partial NBT test.
 * <p>
 * Strict NBT ingredients will only match items that have <b>exactly</b> the provided tag, while partial ones will
 * match if the item's tags contain all of the elements of the provided one, while allowing for additional elements to exist.
 */
public class DataComponentIngredient implements ICustomIngredient {
    public static final MapCodec<DataComponentIngredient> CODEC = RecordCodecBuilder.mapCodec(
            builder -> builder
                    .group(
                            RegistryEntryListCodec.create(RegistryKeys.ITEM, Registries.ITEM.getEntryCodec(), false).fieldOf("items").forGetter(DataComponentIngredient::items),
                            ComponentPredicate.CODEC.fieldOf("components").forGetter(DataComponentIngredient::components),
                            Codec.BOOL.optionalFieldOf("strict", false).forGetter(DataComponentIngredient::isStrict))
                    .apply(builder, DataComponentIngredient::new));

    private final RegistryEntryList<Item> items;
    private final ComponentPredicate components;
    private final boolean strict;
    private final ItemStack[] stacks;

    public DataComponentIngredient(RegistryEntryList<Item> items, ComponentPredicate components, boolean strict) {
        this.items = items;
        this.components = components;
        this.strict = strict;
        this.stacks = items.stream()
                .map(i -> new ItemStack(i, 1, components.toChanges()))
                .toArray(ItemStack[]::new);
    }

    @Override
    public boolean test(ItemStack stack) {
        if (strict) {
            for (ItemStack stack2 : this.stacks) {
                if (ItemStack.areItemsAndComponentsEqual(stack, stack2)) return true;
            }
            return false;
        } else {
            return this.items.contains(stack.getRegistryEntry()) && this.components.test(stack);
        }
    }

    @Override
    public Stream<ItemStack> getItems() {
        return Stream.of(stacks);
    }

    @Override
    public boolean isSimple() {
        return false;
    }

    @Override
    public IngredientType<?> getType() {
        return NeoForgeMod.DATA_COMPONENT_INGREDIENT_TYPE.get();
    }

    public RegistryEntryList<Item> items() {
        return items;
    }

    public ComponentPredicate components() {
        return components;
    }

    public boolean isStrict() {
        return strict;
    }

    /**
     * Creates a new ingredient matching the given item, containing the given components
     */
    public static Ingredient of(boolean strict, ItemStack stack) {
        return of(strict, stack.getComponents(), stack.getItem());
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static <T> Ingredient of(boolean strict, ComponentType<? super T> type, T value, ItemConvertible... items) {
        return of(strict, ComponentPredicate.builder().add(type, value).build(), items);
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static <T> Ingredient of(boolean strict, Supplier<? extends ComponentType<? super T>> type, T value, ItemConvertible... items) {
        return of(strict, type.get(), value, items);
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static Ingredient of(boolean strict, ComponentMap map, ItemConvertible... items) {
        return of(strict, ComponentPredicate.of(map), items);
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    @SafeVarargs
    public static Ingredient of(boolean strict, ComponentMap map, RegistryEntry<Item>... items) {
        return of(strict, ComponentPredicate.of(map), items);
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static Ingredient of(boolean strict, ComponentMap map, RegistryEntryList<Item> items) {
        return of(strict, ComponentPredicate.of(map), items);
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    @SafeVarargs
    public static Ingredient of(boolean strict, ComponentPredicate predicate, RegistryEntry<Item>... items) {
        return of(strict, predicate, RegistryEntryList.of(items));
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static Ingredient of(boolean strict, ComponentPredicate predicate, ItemConvertible... items) {
        return of(strict, predicate, RegistryEntryList.of(Arrays.stream(items).map(ItemConvertible::asItem).map(Item::getRegistryEntry).toList()));
    }

    /**
     * Creates a new ingredient matching any item from the list, containing the given components
     */
    public static Ingredient of(boolean strict, ComponentPredicate predicate, RegistryEntryList<Item> items) {
        return new DataComponentIngredient(items, predicate, strict).toVanilla();
    }
}
