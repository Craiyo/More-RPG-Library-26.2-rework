/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.server.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.io.File;
import java.util.List;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.config.ModConfigs;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.StringUtils;
import net.neoforged.neoforge.client.command.ClientConfigCommand;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.internal.versions.neoforge.NeoForgeVersion;

@EventBusSubscriber(value = Dist.CLIENT, modid = NeoForgeVersion.MOD_ID)
public class ConfigCommand {
    @SubscribeEvent
    public static void onClientCommandsRegister(RegisterClientCommandsEvent event) {
        ClientConfigCommand.register(event.getDispatcher());
    }

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(
                CommandManager.literal("config").then(ShowFile.register()));
    }

    public enum ServerModConfigType {
        COMMON,
        SERVER;

        public String extension() {
            return StringUtils.toLowerCase(name());
        }
    }

    public static class ShowFile {
        static ArgumentBuilder<ServerCommandSource, ?> register() {
            return CommandManager.literal("showfile").requires(cs -> cs.hasPermissionLevel(0)).then(CommandManager.argument("mod", ModIdArgument.modIdArgument()).then(CommandManager.argument("type", EnumArgument.enumArgument(ServerModConfigType.class)).executes(ShowFile::showFile)));
        }

        private static int showFile(final CommandContext<ServerCommandSource> context) {
            final String modId = context.getArgument("mod", String.class);
            final ModConfig.Type type = ModConfig.Type.valueOf(context.getArgument("type", ServerModConfigType.class).toString()); // Convert it back to ModConfig to grab the configs
            var configFileNames = ModConfigs.getConfigFileNames(modId, type);
            for (var configFileName : configFileNames) {
                File f = new File(configFileName);
                MutableText fileComponent = Text.literal(f.getName()).formatted(Formatting.UNDERLINE);

                // Click action not allowed on dedicated servers or connected LAN players as neither cannot click a link to a file on the server/LAN owner.
                // Only provide click action for single player world owners calling this command from in-game.
                ServerPlayerEntity caller = context.getSource().getPlayer();
                if (FMLLoader.getDist().isClient() && caller != null && caller.networkHandler.getConnection().isLocal()) {
                    fileComponent.styled((style) -> style.withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_FILE, f.getAbsolutePath())));
                }

                context.getSource().sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.config.getwithtype",
                        modId, type.toString(), fileComponent), true);
            }
            if (configFileNames.isEmpty()) {
                context.getSource().sendFeedback(() -> CommandUtils.makeTranslatableWithFallback("commands.config.noconfig", modId, type.toString()),
                        true);
            }
            return 0;
        }
    }
}
