/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemFrameEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.item.ItemStack;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.ApiStatus;

/**
 * Fired before an item stack is rendered in an item frame.
 * This can be used to prevent normal rendering or add custom rendering.
 *
 * <p>This event is {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.
 * If the event is cancelled, then the item stack will not be rendered</p>
 *
 * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 *
 * @see ItemFrameEntityRenderer
 */
public class RenderItemInFrameEvent extends Event implements ICancellableEvent {
    private final ItemStack itemStack;
    private final ItemFrameEntity itemFrameEntity;
    private final ItemFrameEntityRenderer<?> renderer;
    private final MatrixStack poseStack;
    private final VertexConsumerProvider multiBufferSource;
    private final int packedLight;

    @ApiStatus.Internal
    public RenderItemInFrameEvent(ItemFrameEntity itemFrame, ItemFrameEntityRenderer<?> renderItemFrame, MatrixStack poseStack,
            VertexConsumerProvider multiBufferSource, int packedLight) {
        itemStack = itemFrame.getHeldItemStack();
        itemFrameEntity = itemFrame;
        renderer = renderItemFrame;
        this.poseStack = poseStack;
        this.multiBufferSource = multiBufferSource;
        this.packedLight = packedLight;
    }

    /**
     * {@return the item stack being rendered}
     */
    public ItemStack getItemStack() {
        return itemStack;
    }

    /**
     * {@return the item frame entity}
     */
    public ItemFrameEntity getItemFrameEntity() {
        return itemFrameEntity;
    }

    /**
     * {@return the renderer for the item frame entity}
     */
    public ItemFrameEntityRenderer<?> getRenderer() {
        return renderer;
    }

    /**
     * {@return the pose stack used for rendering}
     */
    public MatrixStack getPoseStack() {
        return poseStack;
    }

    /**
     * {@return the source of rendering buffers}
     */
    public VertexConsumerProvider getMultiBufferSource() {
        return multiBufferSource;
    }

    /**
     * {@return the amount of packed (sky and block) light for rendering}
     *
     * @see LightmapTextureManager
     */
    public int getPackedLight() {
        return packedLight;
    }
}
