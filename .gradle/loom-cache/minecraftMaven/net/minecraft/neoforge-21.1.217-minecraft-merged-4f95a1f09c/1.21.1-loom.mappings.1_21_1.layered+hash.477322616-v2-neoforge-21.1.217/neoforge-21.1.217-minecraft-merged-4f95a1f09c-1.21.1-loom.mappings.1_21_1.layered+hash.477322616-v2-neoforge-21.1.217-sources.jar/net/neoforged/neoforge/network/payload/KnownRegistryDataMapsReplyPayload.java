/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.network.payload;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.network.codec.NeoForgeStreamCodecs;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public record KnownRegistryDataMapsReplyPayload(
        Map<RegistryKey<? extends Registry<?>>, Collection<Identifier>> dataMaps) implements CustomPayload {
    public static final Id<KnownRegistryDataMapsReplyPayload> TYPE = new Id<>(Identifier.of("neoforge", "known_registry_data_maps_reply"));
    public static final PacketCodec<PacketByteBuf, KnownRegistryDataMapsReplyPayload> STREAM_CODEC = PacketCodec.tuple(
            PacketCodecs.map(
                    Maps::newHashMapWithExpectedSize,
                    NeoForgeStreamCodecs.registryKey(),
                    Identifier.PACKET_CODEC.collect(PacketCodecs.toCollection(ArrayList::new))),
            KnownRegistryDataMapsReplyPayload::dataMaps,
            KnownRegistryDataMapsReplyPayload::new);

    @Override
    public Id<KnownRegistryDataMapsReplyPayload> getId() {
        return TYPE;
    }
}
