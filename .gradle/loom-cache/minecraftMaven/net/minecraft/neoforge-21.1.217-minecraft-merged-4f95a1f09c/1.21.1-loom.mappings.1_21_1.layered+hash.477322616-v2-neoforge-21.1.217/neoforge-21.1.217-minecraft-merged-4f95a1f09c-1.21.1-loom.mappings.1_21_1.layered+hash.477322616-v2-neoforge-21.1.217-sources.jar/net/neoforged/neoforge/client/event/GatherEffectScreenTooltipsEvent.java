/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.screen.ingame.AbstractInventoryScreen;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.Event;

/**
 * This event is called when an {@link AbstractInventoryScreen} draws the tooltip lines for a hovered {@link StatusEffectInstance}.
 * It can be used to modify the tooltip.
 * <p>
 * This event is only fired on the {@linkplain Dist#CLIENT physical client}.
 */
public class GatherEffectScreenTooltipsEvent extends Event {
    protected final AbstractInventoryScreen<?> screen;
    protected final StatusEffectInstance effectInst;
    protected final List<Text> tooltip;

    public GatherEffectScreenTooltipsEvent(AbstractInventoryScreen<?> screen, StatusEffectInstance effectInst, List<Text> tooltip) {
        this.screen = screen;
        this.effectInst = effectInst;
        this.tooltip = new ArrayList<>(tooltip);
    }

    /**
     * @return The screen which will be rendering the tooltip lines.
     */
    public AbstractInventoryScreen<?> getScreen() {
        return this.screen;
    }

    /**
     * @return The effect whose tooltip is being drawn.
     */
    public StatusEffectInstance getEffectInstance() {
        return this.effectInst;
    }

    /**
     * @return A mutable list of tooltip lines.
     */
    public List<Text> getTooltip() {
        return this.tooltip;
    }
}
