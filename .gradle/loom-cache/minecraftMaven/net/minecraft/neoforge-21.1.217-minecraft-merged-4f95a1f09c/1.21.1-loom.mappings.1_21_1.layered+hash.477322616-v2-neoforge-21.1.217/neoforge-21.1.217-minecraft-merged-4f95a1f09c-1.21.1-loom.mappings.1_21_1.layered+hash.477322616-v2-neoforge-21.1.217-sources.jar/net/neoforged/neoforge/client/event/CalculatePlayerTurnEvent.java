/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.event;

import net.minecraft.client.Mouse;
import net.minecraft.client.option.GameOptions;
import net.neoforged.bus.api.Event;
import net.neoforged.bus.api.ICancellableEvent;
import net.neoforged.fml.LogicalSide;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.ApiStatus;

/**
 * Fired in {@linkplain Mouse#updateMouse() MouseHandler#turnPlayer()} when retrieving the values of {@linkplain GameOptions#getMouseSensitivity() mouse sensitivity} and {@linkplain GameOptions#smoothCameraEnabled cinematic camera}, prior to running calculations on these values.
 * 
 * <p>This event is not {@linkplain ICancellableEvent cancellable}, and does not {@linkplain HasResult have a result}.</p>
 *
 * <p>This event is fired on the {@linkplain NeoForge#EVENT_BUS main Forge event bus},
 * only on the {@linkplain LogicalSide#CLIENT logical client}.</p>
 */
public class CalculatePlayerTurnEvent extends Event {
    private double mouseSensitivity;
    private boolean cinematicCameraEnabled;

    @ApiStatus.Internal
    public CalculatePlayerTurnEvent(double mouseSensitivity, boolean cinematicCameraEnabled) {
        setMouseSensitivity(mouseSensitivity);
        setCinematicCameraEnabled(cinematicCameraEnabled);
    }

    /**
     * Returns the raw {@linkplain GameOptions#getMouseSensitivity() mouse sensitivity} value
     */
    public double getMouseSensitivity() {
        return mouseSensitivity;
    }

    /**
     * Sets the {@linkplain GameOptions#getMouseSensitivity() mouse sensitivity} value.
     * 
     * @param mouseSensitivity the new {@linkplain GameOptions#getMouseSensitivity() mouse sensitivity} value
     */
    public void setMouseSensitivity(double mouseSensitivity) {
        this.mouseSensitivity = mouseSensitivity;
    }

    /**
     * Returns the raw {@linkplain GameOptions#smoothCameraEnabled cinematic camera} value
     */
    public boolean getCinematicCameraEnabled() {
        return cinematicCameraEnabled;
    }

    /**
     * Sets the {@linkplain GameOptions#smoothCameraEnabled cinematic camera} value.
     *
     * @param cinematicCameraEnabled the new {@linkplain GameOptions#smoothCameraEnabled cinematic camera} value
     */
    public void setCinematicCameraEnabled(boolean cinematicCameraEnabled) {
        this.cinematicCameraEnabled = cinematicCameraEnabled;
    }
}
