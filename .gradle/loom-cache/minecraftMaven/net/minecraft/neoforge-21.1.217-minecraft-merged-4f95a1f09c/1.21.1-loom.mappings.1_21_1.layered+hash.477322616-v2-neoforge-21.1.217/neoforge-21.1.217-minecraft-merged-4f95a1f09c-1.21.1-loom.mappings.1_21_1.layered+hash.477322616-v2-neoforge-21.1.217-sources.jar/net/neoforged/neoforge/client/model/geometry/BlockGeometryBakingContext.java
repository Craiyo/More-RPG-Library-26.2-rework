/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.model.geometry;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.AffineTransformation;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * A {@linkplain IGeometryBakingContext geometry baking context} that is bound to a {@link JsonUnbakedModel}.
 * <p>
 * Users should not be instantiating this themselves.
 */
public class BlockGeometryBakingContext implements IGeometryBakingContext {
    public final JsonUnbakedModel owner;
    public final VisibilityData visibilityData = new VisibilityData();
    @Nullable
    private IUnbakedGeometry<?> customGeometry;
    @Nullable
    private AffineTransformation rootTransform;
    @Nullable
    private Identifier renderTypeHint;
    private boolean gui3d = true;

    @ApiStatus.Internal
    public BlockGeometryBakingContext(JsonUnbakedModel owner) {
        this.owner = owner;
    }

    @Override
    public String getModelName() {
        return owner.id;
    }

    public boolean hasCustomGeometry() {
        return getCustomGeometry() != null;
    }

    @Nullable
    public IUnbakedGeometry<?> getCustomGeometry() {
        return owner.parent != null && customGeometry == null ? owner.parent.customData.getCustomGeometry() : customGeometry;
    }

    public void setCustomGeometry(IUnbakedGeometry<?> geometry) {
        this.customGeometry = geometry;
    }

    @Override
    public boolean isComponentVisible(String part, boolean fallback) {
        return owner.parent != null && !visibilityData.hasCustomVisibility(part) ? owner.parent.customData.isComponentVisible(part, fallback) : visibilityData.isVisible(part, fallback);
    }

    @Override
    public boolean hasMaterial(String name) {
        return owner.textureExists(name);
    }

    @Override
    public SpriteIdentifier getMaterial(String name) {
        return owner.resolveSprite(name);
    }

    @Override
    public boolean isGui3d() {
        return gui3d;
    }

    @Override
    public boolean useBlockLight() {
        return owner.getGuiLight().isSide();
    }

    @Override
    public boolean useAmbientOcclusion() {
        return owner.useAmbientOcclusion();
    }

    @Override
    public ModelTransformation getTransforms() {
        return owner.getTransformations();
    }

    @Override
    public AffineTransformation getRootTransform() {
        if (rootTransform != null)
            return rootTransform;
        return owner.parent != null ? owner.parent.customData.getRootTransform() : AffineTransformation.identity();
    }

    public void setRootTransform(AffineTransformation rootTransform) {
        this.rootTransform = rootTransform;
    }

    @Nullable
    @Override
    public Identifier getRenderTypeHint() {
        if (renderTypeHint != null)
            return renderTypeHint;
        return owner.parent != null ? owner.parent.customData.getRenderTypeHint() : null;
    }

    public void setRenderTypeHint(Identifier renderTypeHint) {
        this.renderTypeHint = renderTypeHint;
    }

    public void setGui3d(boolean gui3d) {
        this.gui3d = gui3d;
    }

    public void copyFrom(BlockGeometryBakingContext other) {
        this.customGeometry = other.customGeometry;
        this.rootTransform = other.rootTransform;
        this.visibilityData.copyFrom(other.visibilityData);
        this.renderTypeHint = other.renderTypeHint;
        this.gui3d = other.gui3d;
    }

    public BakedModel bake(Baker baker, Function<SpriteIdentifier, Sprite> bakedTextureGetter, ModelBakeSettings modelTransform, ModelOverrideList overrides) {
        IUnbakedGeometry<?> geometry = getCustomGeometry();
        if (geometry == null)
            throw new IllegalStateException("Can not use custom baking without custom geometry");
        return geometry.bake(this, baker, bakedTextureGetter, modelTransform, overrides);
    }

    public static class VisibilityData {
        private final Map<String, Boolean> data = new HashMap<>();

        public boolean hasCustomVisibility(String part) {
            return data.containsKey(part);
        }

        public boolean isVisible(String part, boolean fallback) {
            return data.getOrDefault(part, fallback);
        }

        public void setVisibilityState(String partName, boolean type) {
            data.put(partName, type);
        }

        public void copyFrom(VisibilityData visibilityData) {
            data.clear();
            data.putAll(visibilityData.data);
        }
    }
}
