/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.crafting;

import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.data.server.recipe.RecipeExporter;
import net.minecraft.recipe.Recipe;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.conditions.ICondition;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Wrapper around a {@link RecipeExporter} that adds conditions to all received recipes.
 * Do not use directly, obtain via {@link RecipeExporter#withConditions(ICondition...)}.
 */
@ApiStatus.Internal
public class ConditionalRecipeOutput implements RecipeExporter {
    private final RecipeExporter inner;
    private final ICondition[] conditions;

    public ConditionalRecipeOutput(RecipeExporter inner, ICondition[] conditions) {
        this.inner = inner;
        this.conditions = conditions;
    }

    @Override
    public Advancement.Builder getAdvancementBuilder() {
        return inner.getAdvancementBuilder();
    }

    @Override
    public void accept(Identifier id, Recipe<?> recipe, @Nullable AdvancementEntry advancement, ICondition... conditions) {
        ICondition[] innerConditions;
        if (conditions.length == 0) {
            innerConditions = this.conditions;
        } else if (this.conditions.length == 0) {
            innerConditions = conditions;
        } else {
            innerConditions = ArrayUtils.addAll(this.conditions, conditions);
        }
        inner.accept(id, recipe, advancement, innerConditions);
    }
}
