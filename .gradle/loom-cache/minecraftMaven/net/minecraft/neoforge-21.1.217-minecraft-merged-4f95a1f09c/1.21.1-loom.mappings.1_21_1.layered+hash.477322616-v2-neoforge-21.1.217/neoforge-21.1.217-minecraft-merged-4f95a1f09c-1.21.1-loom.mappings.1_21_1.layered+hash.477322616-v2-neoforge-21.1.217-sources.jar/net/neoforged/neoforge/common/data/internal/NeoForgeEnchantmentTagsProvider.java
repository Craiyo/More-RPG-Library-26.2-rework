/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.data.internal;

import java.util.concurrent.CompletableFuture;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.EnchantmentTagProvider;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.registry.RegistryWrapper;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

public final class NeoForgeEnchantmentTagsProvider extends EnchantmentTagProvider {
    public NeoForgeEnchantmentTagsProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> lookupProvider, ExistingFileHelper existingFileHelper) {
        super(output, lookupProvider, "neoforge", existingFileHelper);
    }

    @Override
    public void configure(RegistryWrapper.WrapperLookup lookupProvider) {
        getOrCreateTagBuilder(Tags.Enchantments.INCREASE_BLOCK_DROPS)
                .add(Enchantments.FORTUNE);
        getOrCreateTagBuilder(Tags.Enchantments.INCREASE_ENTITY_DROPS)
                .add(Enchantments.LOOTING);
        getOrCreateTagBuilder(Tags.Enchantments.WEAPON_DAMAGE_ENHANCEMENTS)
                .add(Enchantments.SHARPNESS)
                .add(Enchantments.SMITE)
                .add(Enchantments.BANE_OF_ARTHROPODS)
                .add(Enchantments.POWER)
                .add(Enchantments.IMPALING);
        getOrCreateTagBuilder(Tags.Enchantments.ENTITY_SPEED_ENHANCEMENTS)
                .add(Enchantments.SOUL_SPEED)
                .add(Enchantments.SWIFT_SNEAK)
                .add(Enchantments.DEPTH_STRIDER);
        getOrCreateTagBuilder(Tags.Enchantments.ENTITY_AUXILIARY_MOVEMENT_ENHANCEMENTS)
                .add(Enchantments.FEATHER_FALLING)
                .add(Enchantments.FROST_WALKER);
        getOrCreateTagBuilder(Tags.Enchantments.ENTITY_DEFENSE_ENHANCEMENTS)
                .add(Enchantments.PROTECTION)
                .add(Enchantments.BLAST_PROTECTION)
                .add(Enchantments.PROJECTILE_PROTECTION)
                .add(Enchantments.FIRE_PROTECTION)
                .add(Enchantments.RESPIRATION)
                .add(Enchantments.FEATHER_FALLING);
    }
}
