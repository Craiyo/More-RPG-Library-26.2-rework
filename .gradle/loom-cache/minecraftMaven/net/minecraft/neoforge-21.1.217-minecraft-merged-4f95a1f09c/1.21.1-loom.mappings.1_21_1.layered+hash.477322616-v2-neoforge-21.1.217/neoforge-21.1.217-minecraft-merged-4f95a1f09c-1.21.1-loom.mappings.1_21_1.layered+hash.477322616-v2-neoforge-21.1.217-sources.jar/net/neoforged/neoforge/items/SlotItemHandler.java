/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.items;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

public class SlotItemHandler extends Slot {
    private static Inventory emptyInventory = new SimpleInventory(0);
    private final IItemHandler itemHandler;
    protected final int id;

    public SlotItemHandler(IItemHandler itemHandler, int index, int xPosition, int yPosition) {
        super(emptyInventory, index, xPosition, yPosition);
        this.itemHandler = itemHandler;
        this.id = index;
    }

    @Override
    public boolean canInsert(ItemStack stack) {
        if (stack.isEmpty())
            return false;
        return itemHandler.isItemValid(id, stack);
    }

    @Override
    public ItemStack getStack() {
        return this.getItemHandler().getStackInSlot(id);
    }

    // Override if your IItemHandler does not implement IItemHandlerModifiable
    @Override
    public void setStackNoCallbacks(ItemStack stack) {
        ((IItemHandlerModifiable) this.getItemHandler()).setStackInSlot(id, stack);
        this.markDirty();
    }

    // Override if your IItemHandler does not implement IItemHandlerModifiable
    // @Override
    public void initialize(ItemStack stack) {
        ((IItemHandlerModifiable) this.getItemHandler()).setStackInSlot(id, stack);
        this.markDirty();
    }

    @Override
    public void onQuickTransfer(ItemStack oldStackIn, ItemStack newStackIn) {}

    @Override
    public int getMaxItemCount() {
        return this.itemHandler.getSlotLimit(this.id);
    }

    @Override
    public int getMaxItemCount(ItemStack stack) {
        return Math.min(stack.getMaxCount(), this.itemHandler.getSlotLimit(this.id));
    }

    @Override
    public boolean canTakeItems(PlayerEntity playerIn) {
        return !this.getItemHandler().extractItem(id, 1, true).isEmpty();
    }

    @Override
    public ItemStack takeStack(int amount) {
        return this.getItemHandler().extractItem(id, amount, false);
    }

    public IItemHandler getItemHandler() {
        return itemHandler;
    }
/* TODO Slot patches
@Override
public boolean isSameInventory(Slot other)
{
return other instanceof SlotItemHandler && ((SlotItemHandler) other).getItemHandler() == this.itemHandler;
}*/
}
