/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries.datamaps;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.dynamic.Codecs;
import net.neoforged.neoforge.common.conditions.ConditionalOps;
import net.neoforged.neoforge.common.conditions.WithConditions;
import net.neoforged.neoforge.common.util.NeoForgeExtraCodecs;

public record DataMapFile<T, R>(
        boolean replace,
        Map<Either<TagKey<R>, RegistryKey<R>>, Optional<WithConditions<DataMapEntry<T>>>> values,
        List<DataMapEntry.Removal<T, R>> removals) {
    public static <T, R> Codec<DataMapFile<T, R>> codec(RegistryKey<Registry<R>> registryKey, DataMapType<R, T> dataMap) {
        final Codec<Either<TagKey<R>, RegistryKey<R>>> tagOrValue = Codecs.TAG_ENTRY_ID.xmap(
                l -> l.tag() ? Either.left(TagKey.of(registryKey, l.id())) : Either.right(RegistryKey.of(registryKey, l.id())),
                e -> e.map(t -> new Codecs.TagEntryId(t.id(), true), r -> new Codecs.TagEntryId(r.getValue(), false)));

        final Codec<List<DataMapEntry.Removal<T, R>>> removalsCodec;
        if (dataMap instanceof AdvancedDataMapType<R, T, ?>) {
            final var removalCodec = DataMapEntry.Removal.codec(tagOrValue, dataMap);
            final AdvancedDataMapType<R, T, DataMapValueRemover<R, T>> advanced = (AdvancedDataMapType<R, T, DataMapValueRemover<R, T>>) dataMap;
            removalsCodec = NeoForgeExtraCodecs.withAlternative(
                    NeoForgeExtraCodecs.withAlternative(removalCodec.listOf(), NeoForgeExtraCodecs.decodeOnly(tagOrValue.listOf()
                            .map(l -> l.stream().map(k -> new DataMapEntry.Removal<T, R>(k, Optional.empty())).toList()))),
                    NeoForgeExtraCodecs.decodeOnly(Codecs.strictUnboundedMap(tagOrValue, advanced.remover())
                            .map(map -> map.entrySet().stream()
                                    .map(entry -> new DataMapEntry.Removal<>(entry.getKey(), Optional.of(entry.getValue()))).toList())));
        } else {
            removalsCodec = tagOrValue.listOf()
                    .xmap(l -> l.stream().map(k -> new DataMapEntry.Removal<T, R>(k, Optional.empty())).toList(),
                            rm -> rm.stream().map(DataMapEntry.Removal::key).toList());
        }

        return RecordCodecBuilder.create(in -> in.group(
                Codec.BOOL.optionalFieldOf("replace", false).forGetter(DataMapFile::replace),
                Codecs.strictUnboundedMap(tagOrValue, ConditionalOps.createConditionalCodecWithConditions(DataMapEntry.codec(dataMap))).fieldOf("values").forGetter(DataMapFile::values),
                removalsCodec.optionalFieldOf("remove", List.of()).forGetter(DataMapFile::removals))
                .apply(in, DataMapFile::new));
    }
}
