/*
 * Copyright (c) NeoForged and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.common.extensions;

import net.minecraft.network.listener.ServerConfigurationPacketListener;
import net.minecraft.server.network.ServerConfigurationNetworkHandler;
import net.minecraft.server.network.ServerPlayerConfigurationTask;

/**
 * Extension class for {@link ServerConfigurationPacketListener}
 */
public interface IServerConfigurationPacketListenerExtension extends IServerCommonPacketListenerExtension {
    /**
     * Call when a configuration task is finished
     *
     * @param task The task that was finished
     * @implNote This forces the normally private method implementation in {@link ServerConfigurationNetworkHandler#onTaskFinished(ServerPlayerConfigurationTask.Key)} to become public, and adds this to the signature of {@link ServerConfigurationPacketListener}
     */
    void finishCurrentTask(ServerPlayerConfigurationTask.Key task);
}
