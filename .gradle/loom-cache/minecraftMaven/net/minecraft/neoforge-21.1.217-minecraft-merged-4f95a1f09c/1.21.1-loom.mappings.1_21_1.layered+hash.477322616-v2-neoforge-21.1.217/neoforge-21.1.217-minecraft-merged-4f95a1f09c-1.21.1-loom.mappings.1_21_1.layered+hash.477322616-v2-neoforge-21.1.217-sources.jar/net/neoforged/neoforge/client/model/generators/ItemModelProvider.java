/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.client.model.generators;

import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.data.DataOutput;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.neoforged.neoforge.common.data.ExistingFileHelper;

/**
 * Stub class to extend for item model data providers, eliminates some
 * boilerplate constructor parameters.
 */
public abstract class ItemModelProvider extends ModelProvider<ItemModelBuilder> {
    public ItemModelProvider(DataOutput output, String modid, ExistingFileHelper existingFileHelper) {
        super(output, modid, ITEM_FOLDER, ItemModelBuilder::new, existingFileHelper);
    }

    public ItemModelBuilder basicItem(Item item) {
        return basicItem(Objects.requireNonNull(Registries.ITEM.getId(item)));
    }

    public ItemModelBuilder basicItem(Identifier item) {
        return getBuilder(item.toString())
                .parent(new ModelFile.UncheckedModelFile("item/generated"))
                .texture("layer0", Identifier.of(item.getNamespace(), "item/" + item.getPath()));
    }

    public ItemModelBuilder handheldItem(Item item) {
        return handheldItem(Objects.requireNonNull(Registries.ITEM.getId(item)));
    }

    public ItemModelBuilder handheldItem(Identifier item) {
        return getBuilder(item.toString())
                .parent(new ModelFile.UncheckedModelFile("item/handheld"))
                .texture("layer0", Identifier.of(item.getNamespace(), "item/" + item.getPath()));
    }

    public ItemModelBuilder spawnEggItem(Item item) {
        return spawnEggItem(Objects.requireNonNull(Registries.ITEM.getId(item)));
    }

    public ItemModelBuilder spawnEggItem(Identifier item) {
        return getBuilder(item.toString())
                .parent(new ModelFile.UncheckedModelFile("item/template_spawn_egg"));
    }

    public ItemModelBuilder simpleBlockItem(Block block) {
        return simpleBlockItem(Objects.requireNonNull(Registries.BLOCK.getId(block)));
    }

    public ItemModelBuilder simpleBlockItem(Identifier block) {
        return withExistingParent(block.toString(), Identifier.of(block.getNamespace(), "block/" + block.getPath()));
    }

    @Override
    public String getName() {
        return "Item Models: " + modid;
    }
}
