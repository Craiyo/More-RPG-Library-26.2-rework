package io.wispforest.owo.mixin.ui;

import io.wispforest.owo.ui.core.Component;
import io.wispforest.owo.ui.inject.GreedyInputComponent;
import net.minecraft.client.gui.widget.EditBoxWidget;
import net.minecraft.client.gui.widget.ScrollableWidget;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(EditBoxWidget.class)
public abstract class EditBoxWidgetMixin extends ScrollableWidget implements GreedyInputComponent {

    public EditBoxWidgetMixin(int i, int j, int k, int l, net.minecraft.text.Text text) {
        super(i, j, k, l, text);
    }

    @Override
    public void onFocusGained(Component.FocusSource source) {
        super.onFocusGained(source);
        this.setFocused(true);
    }

}
