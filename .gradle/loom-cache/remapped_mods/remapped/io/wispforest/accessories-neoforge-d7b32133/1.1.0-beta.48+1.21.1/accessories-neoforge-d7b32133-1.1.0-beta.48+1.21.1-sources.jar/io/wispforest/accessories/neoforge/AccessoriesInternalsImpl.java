package io.wispforest.accessories.neoforge;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import io.wispforest.accessories.api.AccessoriesHolder;
import io.wispforest.accessories.menu.variants.AccessoriesMenuBase;
import io.wispforest.accessories.utils.ManagedEndecDataLoader;
import io.wispforest.owo.serialization.RegistriesAttribute;
import io.wispforest.accessories.impl.AccessoriesHolderImpl;
import io.wispforest.accessories.menu.AccessoriesMenuData;
import io.wispforest.accessories.menu.AccessoriesMenuVariant;
import io.wispforest.endec.Endec;
import io.wispforest.endec.SerializationContext;
import io.wispforest.endec.format.bytebuf.ByteBufDeserializer;
import io.wispforest.endec.format.bytebuf.ByteBufSerializer;
import net.minecraft.command.argument.ArgumentTypes;
import net.minecraft.command.argument.serialize.ArgumentSerializer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.neoforge.client.event.GatherSkippedAttributeTooltipsEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.common.util.AttributeTooltipContext;
import net.neoforged.neoforge.common.util.AttributeUtil;
import net.neoforged.neoforge.items.ItemHandlerHelper;
import org.apache.commons.lang3.function.TriFunction;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

public class AccessoriesInternalsImpl {

    public static boolean isDevelopmentEnv() {
        return !FMLLoader.isProduction();
    }

    public static AccessoriesHolder getHolder(LivingEntity livingEntity){
        return livingEntity.getData(AccessoriesForge.HOLDER_ATTACHMENT_TYPE);
    }

    public static void modifyHolder(LivingEntity livingEntity, UnaryOperator<AccessoriesHolderImpl> modifier){
        var holder = (AccessoriesHolderImpl) getHolder(livingEntity);

        holder = modifier.apply(holder);

        livingEntity.setData(AccessoriesForge.HOLDER_ATTACHMENT_TYPE, holder);
    }

    public static <T> Optional<Collection<RegistryEntry<T>>> getHolder(TagKey<T> tagKey){
        return currentContext.map(iContext -> iContext.getTag(tagKey));
    }

    private static Optional<ICondition.IContext> currentContext = Optional.empty();

    public static void setContext(@Nullable ICondition.IContext context){
        currentContext = Optional.ofNullable(context);
    }

    //--

    public static void giveItemToPlayer(ServerPlayerEntity player, ItemStack stack) {
        ItemHandlerHelper.giveItemToPlayer(player, stack);
    }

    public static boolean isValidOnConditions(JsonObject object, String dataType, Identifier key, @Nullable RegistryWrapper.WrapperLookup registryLookup) {
        DynamicOps<JsonElement> ops = JsonOps.INSTANCE;

        if(registryLookup != null) ops = registryLookup.getOps(ops);

        return ICondition.conditionsMatched(ops, object);
    }

    public static <T extends ScreenHandler, D> ScreenHandlerType<T> registerMenuType(Identifier location, Endec<D> endec, TriFunction<Integer, PlayerInventory, D, T> func) {
        return Registry.register(Registries.SCREEN_HANDLER, location, IMenuTypeExtension.create((i, arg, arg2) -> {
            return func.apply(i, arg, endec.decodeFully(SerializationContext.attributes(RegistriesAttribute.of(arg2.registryAccess())), ByteBufDeserializer::of, arg2));
        }));
    }

    public static <A extends ArgumentType<?>, T extends ArgumentSerializer.ArgumentTypeProperties<A>, I extends ArgumentSerializer<A, T>> I registerCommandArgumentType(Identifier location, Class<A> clazz, I info) {
        ArgumentTypes.registerByClass(clazz, info);

        return Registry.register(Registries.COMMAND_ARGUMENT_TYPE, location, info);
    }

    public static void openAccessoriesMenu(PlayerEntity player, AccessoriesMenuVariant variant, @Nullable LivingEntity targetEntity, @Nullable ItemStack carriedStack) {
        player.openMenu(
                new SimpleNamedScreenHandlerFactory((i, inventory, arg2) -> {
                    var menu = AccessoriesMenuVariant.openMenu(i, inventory, variant, targetEntity, carriedStack);

                    // Hacky work around for getting menu info in encoding
                    inventory.player.currentScreenHandler = menu;

                    return menu;
                }, Text.empty()),
                buf -> {
                    AccessoriesMenuData.ENDEC.encode(SerializationContext.attributes(RegistriesAttribute.of(buf.registryAccess())), ByteBufSerializer.of(buf), AccessoriesMenuData.of(targetEntity, ((AccessoriesMenuBase) player.containerMenu)));
                });
    }

    public static void addAttributeTooltips(@Nullable PlayerEntity player, ItemStack stack, Multimap<RegistryEntry<EntityAttribute>, EntityAttributeModifier> multimap, Consumer<Text> tooltipAddCallback, Item.TooltipContext context, TooltipType flag) {
        var neoTooltipCtx = AttributeTooltipContext.of(player, context, flag);

        var event = NeoForge.EVENT_BUS.post(new GatherSkippedAttributeTooltipsEvent(stack, neoTooltipCtx));

        if (event.isSkippingAll()) return;

        var modifiers = HashMultimap.create(multimap);

        modifiers.values().removeIf(m -> event.isSkipped(m.id()));

        if (modifiers.isEmpty()) return;

        AttributeUtil.applyTextFor(stack, tooltipAddCallback, modifiers, neoTooltipCtx);
    }

    public static final Map<ManagedEndecDataLoader<?>, Consumer<RegistryWrapper.WrapperLookup>> TO_BE_LOADED = new HashMap<>();

    public static void registerLoader(ManagedEndecDataLoader<?> loader, Consumer<RegistryWrapper.WrapperLookup> registrySetCall) {
        TO_BE_LOADED.put(loader, registrySetCall);
    }
}
