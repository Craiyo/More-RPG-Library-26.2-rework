package io.wispforest.accessories.pond;

import ArmorSlot;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public interface ArmorSlotExtension {

    default ArmorSlot setAtlasLocation(Identifier atlasLocation) {
        throw new IllegalStateException("Extension method not implemented!");
    }

    @Nullable
    default Identifier getAtlasLocation(){
        throw new IllegalStateException("Extension method not implemented!");
    }
}
