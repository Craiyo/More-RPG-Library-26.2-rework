package io.wispforest.accessories.neoforge.mixin.client;

import io.wispforest.accessories.client.PostEffectBuffer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = PostEffectBuffer.class)
public class PostEffectBufferMixin {

    private Framebuffer framebuffer;

    @Inject(method = "ensureInitialized", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/pipeline/RenderTarget;setClearColor(FFFF)V"))
    private void adjustBuffer(CallbackInfo ci) {
        var mainTarget = MinecraftClient.getInstance().getFramebuffer();

        if (mainTarget.isStencilEnabled()) {
            framebuffer.enableStencil();
        }
    }
}
