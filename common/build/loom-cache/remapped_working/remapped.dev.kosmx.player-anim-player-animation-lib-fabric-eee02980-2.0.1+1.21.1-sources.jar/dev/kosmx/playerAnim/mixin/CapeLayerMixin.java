package dev.kosmx.playerAnim.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import dev.kosmx.playerAnim.core.util.Pair;
import dev.kosmx.playerAnim.impl.IAnimatedPlayer;
import dev.kosmx.playerAnim.impl.animation.AnimationApplier;
import dev.kosmx.playerAnim.impl.animation.IBendHelper;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CapeFeatureRenderer.class)
public abstract class CapeLayerMixin extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
    public CapeLayerMixin(FeatureRendererContext<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> renderLayerParent) {
        super(renderLayerParent);
    }

    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;FFFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/PlayerModel;renderCloak(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;II)V"))
    private void render(MatrixStack poseStack, VertexConsumerProvider multiBufferSource, int i, AbstractClientPlayerEntity abstractClientPlayer, float f, float g, float h, float j, float k, float l, CallbackInfo ci) {
        AnimationApplier emote = ((IAnimatedPlayer) abstractClientPlayer).playerAnimator_getAnimation();
        if (emote.isActive()) {
            ModelPart torso = this.getContextModel().body;
            Pair<Float, Float> torsoBend = emote.getBend("torso");
            Pair<Float, Float> bodyBend = emote.getBend("body");
            Pair<Float, Float> bend = new Pair<>(torsoBend.getLeft() + bodyBend.getLeft(), torsoBend.getRight() + bodyBend.getRight());

            poseStack.translate(torso.pivotX / 16, torso.pivotY / 16, torso.pivotZ / 16);
            poseStack.multiply((new Quaternionf()).rotateXYZ(torso.pitch, torso.yaw, torso.roll));
            IBendHelper.rotateMatrixStack(poseStack, torsoBend);
            poseStack.translate(0.0F, 0.0F, 0.125F);
            poseStack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));

            ModelPart cape = ((PlayerModelAccessor)this.getContextModel()).getCloak();
            cape.pivotX = 0;
            cape.pivotY = 0;
            cape.pivotZ = 0;
            cape.pitch = 0;
            cape.yaw = 0;
            cape.roll = 0;

            IBendHelper.INSTANCE.bend(cape, bend);
        }
        else {
            IBendHelper.INSTANCE.bend(((PlayerModelAccessor)this.getContextModel()).getCloak(), null);
        }
    }

    @WrapWithCondition(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;FFFFFF)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;mulPose(Lorg/joml/Quaternionf;)V"))
    private boolean mulPose(MatrixStack instance, Quaternionf quaternionf, @Local(argsOnly = true) AbstractClientPlayerEntity abstractClientPlayer) {
        AnimationApplier emote = ((IAnimatedPlayer) abstractClientPlayer).playerAnimator_getAnimation();
        return !emote.isActive();
    }

    @WrapWithCondition(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;FFFFFF)V", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"))
    private boolean translate(MatrixStack instance, float f, float g, float h, @Local(argsOnly = true) AbstractClientPlayerEntity abstractClientPlayer) {
        AnimationApplier emote = ((IAnimatedPlayer) abstractClientPlayer).playerAnimator_getAnimation();
        return !emote.isActive();
    }
}
