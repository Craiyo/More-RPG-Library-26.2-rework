package dev.kosmx.playerAnim.minecraftApi.codec;

import dev.kosmx.playerAnim.api.IPlayable;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.io.OutputStream;
import net.minecraft.util.Identifier;

@FunctionalInterface
public interface AnimationEncoder<T extends IPlayable> {
    void encode(@NotNull OutputStream output, @NotNull Identifier location, @NotNull T animation) throws IOException;
}
